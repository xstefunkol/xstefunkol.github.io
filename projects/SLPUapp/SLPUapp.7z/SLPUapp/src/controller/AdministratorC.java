package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import model.Administrator;
import model.Likvidator;
import model.RegistrovanaOsoba;
import model.Zaznam;
import view.AdministratorV;
import view.Prihlasenie;

/**
 * Trieda AdministratorC reprezentuje prepojenie medzi triedou AdministratorV (view) a met�dami v package model.
 */
public class AdministratorC {
	private AdministratorV administratorV;
	private ArrayList<RegistrovanaOsoba> osoby;
	private ArrayList<Zaznam> zoznam;
	private RegistrovanaOsoba admin;
	private Likvidator likvid;

	/**
	 * Kon�truktor triedy AdministratorC
	 * @param administratorV Okno vytvoren� triedou AdministratorV.
	 * @param osoby Zoznam registrovan�ch os�b.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach.
	 * @param admin In�tancia triedy RegistrovanaOsoba - pou��vanie prekonanej met�dy.
	 * @param likvid In�tancia triedy Likvidator - pou��vanie prekonanej met�dy.
	 */
	public AdministratorC(ArrayList<RegistrovanaOsoba> osoby, ArrayList<Zaznam> zoznam, AdministratorV administratorV, RegistrovanaOsoba admin, Likvidator likvid) {
		this.admin = admin;
		this.likvid = likvid;
		this.administratorV = administratorV;
		this.zoznam = zoznam;
		this.osoby = osoby;
		this.administratorV.addVypisRegOsobAListener(new VypisRegOsobAListener());
		this.administratorV.addRegistrujNovehoPouzAListener(new RegistrujNovehoPouzAListener());
		this.administratorV.addZmazPouzAListener(new ZmazPouzAListener());
		this.administratorV.addVypisZoznamuAListener(new VypisZoznamuAListener());
		this.administratorV.addZmazZaznamAListener(new ZmazZaznamAListener());
		this.administratorV.addVytvorZaznamAListener(new VytvorZaznamAListener());
		this.administratorV.addZmenaUPouzAListener(new ZmenaUPouzAListener());
		this.administratorV.addZmenaUZaznamAListener(new ZmenaUZaznamAListener());
		this.administratorV.addVypisAdminovAListener(new VypisAdminovAListener());
		this.administratorV.addVycistiAListener(new VycistiAListener());
		this.administratorV.addOdhlasitAListener(new OdhlasitAListener());
	}

	/**
	 * Vhniezden� trieda VypisRegOsobAListener reprezentuje situ�ciu po stla�en� tla��tka V�pis registrovan�ch os�b.
	 */
	class VypisRegOsobAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.Administrator#vypisRegOsob(ArrayList<RegistrovanaOsoba> osoby)
			 */
			pole = Administrator.vypisRegOsob(osoby);
			if (pole.get(0).equals("0")) administratorV.neexistujucaOsobaAError();
			else for (String i: pole) administratorV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda RegistrujNovehoPouzAListener reprezentuje situ�ciu po stla�en� tla��tka Registr�cia nov�ho pou��vate�a.
	 */
	class RegistrujNovehoPouzAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			String heslo;
			int q;
			int pridaj;
			meno = administratorV.getMenoA();
			heslo = administratorV.getHesloA();
			q = administratorV.getOpravnenieA();
			/**
			 * @see model.Administrator#zaregistrovanie(ArrayList<RegistrovanaOsoba> osoby, String meno, String heslo, int q)
			 */
			pridaj = Administrator.zaregistrovanie(osoby, meno, heslo, q);
			if (pridaj == 0) administratorV.nezadanyParameterAError();
			if (pridaj == 1) administratorV.uspesnaRegA();
			if (pridaj == 2) administratorV.zhodneMenaAError();
		}
	}
	
	/**
	 * Vhniezden� trieda ZmazPouzAListener reprezentuje situ�ciu po stla�en� tla��tka Vymazanie pou��vate�a.
	 */
	class ZmazPouzAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			int zmazPouz;
			meno = administratorV.getMenoA();
			/**
			 * @see model.Administrator#vymazaniePouzivatela(ArrayList<RegistrovanaOsoba> osoby, String meno)
			 */
			zmazPouz = Administrator.vymazaniePouzivatela(osoby, meno);
			if (zmazPouz == 0) administratorV.nezadanyParameterAError();
			if (zmazPouz == 1) administratorV.neexistujucaOsobaAError();
			if (zmazPouz == 2) administratorV.nezhodneMenaAError();
			if (zmazPouz == 3) administratorV.vymazanyPouzivatelA();
		}
	}
	
	/**
	 * Vhniezden� trieda VypisZoznamuAListener reprezentuje situ�ciu po stla�en� tla��tka V�pis z�znamov.
	 */
	class VypisZoznamuAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.Administrator#vypisZoznamu(ArrayList<Zaznam> zoznam)
			 */
			pole = Administrator.vypisZoznamu(zoznam);
			if (pole.get(0).equals("0")) administratorV.neexistujuciZoznamAError();
			else for (String i: pole) administratorV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda ZmazZaznamAListener reprezentuje situ�ciu po stla�en� tla��tka Vymazanie z�znamu.
	 */
	class ZmazZaznamAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			int zmazZaznam;
			meno = administratorV.getMenoA();
			/**
			 * @see model.Administrator#vymazanieZaznamu(ArrayList<Zaznam> zoznam, String meno)
			 */
			zmazZaznam = Administrator.vymazanieZaznamu(zoznam, meno);
			if (zmazZaznam == 0) administratorV.nezadanyParameterAError();
			if (zmazZaznam == 1) administratorV.neexistujuciZoznamAError();
			if (zmazZaznam == 2) administratorV.neexistujuciZaznamAError();
			if (zmazZaznam == 3) administratorV.vymazanyZaznamA();
		}
	}
	
	/**
	 * Vhniezden� trieda VytvorZaznamAListener reprezentuje situ�ciu po stla�en� tla��tka Vytvorenie z�znamu.
	 */
	class VytvorZaznamAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			String miesto;
			int rok;
			int mesiac;
			int den;
			String email;
			String adresa;
			int vytvorenie;
			meno = administratorV.getMenoA();
			miesto = administratorV.getMiestoA();
			rok = administratorV.getRokA();
			mesiac = administratorV.getMesiacA();
			den = administratorV.getDenA();
			email = administratorV.getEmailA();
			adresa = administratorV.getAdresaA();
			/**
			 * @see model.Administrator#vytvorenieZaznamu(ArrayList<Zaznam> zoznam, String meno, String zmiesto, int zrok, int zmesiac, int zden, String zemail, String zadresa)
			 */
			vytvorenie = Administrator.vytvorenieZaznamu(zoznam, meno, miesto, rok, mesiac, den, email, adresa);
			if (vytvorenie == 0) administratorV.nezadanyParameterAError();
			if (vytvorenie == 1) administratorV.vytvorenyZaznamA();
			if (vytvorenie == 2) administratorV.uzExistujeZaznamA();
		}
	}
	
	/**
	 * Vhniezden� trieda ZmenaUPouzAListener reprezentuje situ�ciu po stla�en� tla��tka Zmena �dajov (Reg. osoba).
	 */
	class ZmenaUPouzAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			String heslo;
			int q;
			int zmenPouz;
			meno = administratorV.getMenoA();
			heslo = administratorV.getHesloA();
			q = administratorV.getOpravnenieA();
			/**
			 * @see model.Administrator#zmenaUdajovVRegOsob(ArrayList<RegistrovanaOsoba> osoby, String meno, String heslo, int q)
			 */
			zmenPouz = Administrator.zmenaUdajovVRegOsob(osoby, meno, heslo, q);
			if (zmenPouz == 0) administratorV.nezadanyParameterAError();
			if (zmenPouz == 1) administratorV.neexistujucaOsobaAError();
			if (zmenPouz == 2) administratorV.nezhodneMenaAError();
			if (zmenPouz == 3) administratorV.aktualizovanaOsobaA();
		}
	}
	
	/**
	 * Vhniezden� trieda ZmenaUZaznamAListener reprezentuje situ�ciu po stla�en� tla��tka Zmena �dajov (Z�znam).
	 */
	class ZmenaUZaznamAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			String miesto;
			int rok;
			int mesiac;
			int den;
			String email;
			String adresa;
			int zmenZaznam;
			meno = administratorV.getMenoA();
			miesto = administratorV.getMiestoA();
			rok = administratorV.getRokA();
			mesiac = administratorV.getMesiacA();
			den = administratorV.getDenA();
			email = administratorV.getEmailA();
			adresa = administratorV.getAdresaA();
			/**
			 * @see model.Administrator#zmenaUdajovVZoznam(ArrayList<Zaznam> zoznam, String meno, String zmiesto, int zrok, int zmesiac, int zden, String zemail, String zadresa)
			 */
			zmenZaznam = Administrator.zmenaUdajovVZoznam(zoznam, meno, miesto, rok, mesiac, den, email, adresa);
			if (zmenZaznam == 0) administratorV.nezadanyParameterAError();
			if (zmenZaznam == 1) administratorV.neexistujuciZoznamAError();
			if (zmenZaznam == 2) administratorV.neexistujuciZaznamAError();
			if (zmenZaznam == 3) administratorV.aktualizovanyZaznamA();
		}
	}
	
	/**
	 * Vhniezden� trieda VypisAdminovAListener reprezentuje situ�ciu po stla�en� tla��tka V�pis administr�torov.
	 */
	class VypisAdminovAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.RegistrovanaOsoba#funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby)
			 */
			pole = admin.funkciaVypisuBossov(osoby);
			if (pole.get(0).equals("0")) administratorV.neexistujucaOsobaAError();
			else if (pole.get(0).equals("1")) administratorV.neexistujuciAdminAError();
			else for (String i: pole) administratorV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda VycistiAListener reprezentuje situ�ciu po stla�en� tla��tka Clear.
	 */
	class VycistiAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			administratorV.vycisti();
		}
	}
	
	/**
	 * Vhniezden� trieda OdhlasitAListener reprezentuje situ�ciu po stla�en� tla��tka Odhl�si�.
	 */
	class OdhlasitAListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Prihlasenie prihlasenie = new Prihlasenie();
			administratorV.dispose();
			prihlasenie.setVisible(true);
			@SuppressWarnings("unused")
			PrihlasenieC prihlasenieCont = new PrihlasenieC(prihlasenie, osoby, zoznam, admin, likvid);
		}
	}
}