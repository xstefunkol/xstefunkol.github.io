package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import model.Likvidator;
import model.RegistrovanaOsoba;
import model.Zaznam;
import view.AdministratorV;
import view.HlavnyLikvidatorV;
import view.KlientV;
import view.LikvidatorV;
import view.Prihlasenie;
import view.ReferentSpravyPoisteniaV;
import view.Spustenie;

/**
 * Trieda PrihlasenieC reprezentuje prepojenie medzi triedou Prihlasenie (view) a met�dami v package model.
 */
public class PrihlasenieC {
	private ArrayList<RegistrovanaOsoba> osoby;
	private Prihlasenie prihlasenie;
	private ArrayList<Zaznam> zoznam;
	private RegistrovanaOsoba admin;
	private Likvidator likvid;

	/**
	 * Kon�truktor triedy PrihlasenieC
	 * @param prihlasenie Okno vytvoren� triedou Prihlasenie.
	 * @param osoby Zoznam registrovan�ch os�b.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach.
	 * @param admin In�tancia triedy RegistrovanaOsoba - pou��vanie prekonanej met�dy.
	 * @param likvid In�tancia triedy Likvidator - pou��vanie prekonanej met�dy.
	 */
	public PrihlasenieC(Prihlasenie prihlasenie, ArrayList<RegistrovanaOsoba> osoby, ArrayList<Zaznam> zoznam, RegistrovanaOsoba admin, Likvidator likvid) {
		this.admin = admin;
		this.likvid = likvid;
		this.zoznam = zoznam;
		this.osoby = osoby;
		this.prihlasenie = prihlasenie;
		this.prihlasenie.addPrihlaseniePListener(new PrihlasitPListener());
		this.prihlasenie.addBackPListener(new BackPListener());
	}
	
	/**
	 * Vhniezden� trieda PrihlasitPListener reprezentuje situ�ciu po stla�en� tla�idla Prihl�si�.
	 */
	class PrihlasitPListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			String heslo;
			String opravnenie;
			meno = prihlasenie.getMenoP();
			heslo = prihlasenie.getHesloP();
			/**
			 * @see model.RegistrovanaOsoba#prihlasenie(ArrayList<RegistrovanaOsoba> osoby, String lmeno, String lheslo)
			 */
			opravnenie = RegistrovanaOsoba.prihlasenie(osoby, meno, heslo);
			if (opravnenie == "1") prihlasenie.neplatneMenoPError();
			else if (opravnenie == "2") prihlasenie.neplatneHesloPError();
			else if (opravnenie == "3") prihlasenie.nedostatokParametrovPError();
			else if (opravnenie.equals("Administr�tor") && opravnenie.equals(prihlasenie.getOpravnenieP())) { // Vytvorenie jednotliv�ch okien pod�a prihl�sen�ch �dajov.
				AdministratorV administratorV = new AdministratorV();
				prihlasenie.dispose();
				administratorV.setVisible(true);
				@SuppressWarnings("unused")
				AdministratorC administratorCont = new AdministratorC(osoby, zoznam, administratorV, admin ,likvid);
			}
			else if (opravnenie.equals("Hlavn� likvid�tor") && opravnenie.equals(prihlasenie.getOpravnenieP())) {
				HlavnyLikvidatorV hlavnylikvidatorV = new HlavnyLikvidatorV();
				prihlasenie.dispose();
				hlavnylikvidatorV.setVisible(true);
				@SuppressWarnings("unused")
				HlavnyLikvidatorC hlavnylikvidatorCont = new HlavnyLikvidatorC(osoby, zoznam, hlavnylikvidatorV, admin ,likvid);
			}
			else if (opravnenie.equals("Likvid�tor") && opravnenie.equals(prihlasenie.getOpravnenieP())) {
				LikvidatorV likvidatorV = new LikvidatorV();
				prihlasenie.dispose();
				likvidatorV.setVisible(true);
				@SuppressWarnings("unused")
				LikvidatorC likvidatorCont = new LikvidatorC(osoby, zoznam, likvidatorV, admin ,likvid);
			}
			else if (opravnenie.equals("Referent spr�vy poistenia") && opravnenie.equals(prihlasenie.getOpravnenieP())) {
				ReferentSpravyPoisteniaV referentV = new ReferentSpravyPoisteniaV();
				prihlasenie.dispose();
				referentV.setVisible(true);
				@SuppressWarnings("unused")
				ReferentSpravyPoisteniaC referentCont = new ReferentSpravyPoisteniaC(osoby, zoznam, referentV, admin ,likvid);
			}
			else if (opravnenie.equals("Klient") && opravnenie.equals(prihlasenie.getOpravnenieP())) {
				KlientV klientV = new KlientV();
				prihlasenie.dispose();
				klientV.setVisible(true);
				@SuppressWarnings("unused")
				KlientC klientCont = new KlientC(osoby, zoznam, klientV, meno, admin ,likvid);
			}
			else prihlasenie.neplatneOpravneniePError();
		}
	}
	
	/**
	 * Vhniezden� trieda BackPListener reprezentuje situ�ciu po stla�en� tla�idla Sp�.
	 */
	class BackPListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Spustenie spustenie = new Spustenie();
			prihlasenie.dispose();
			spustenie.setVisible(true);
			@SuppressWarnings("unused")
			SpustenieC spustenieCont = new SpustenieC(spustenie, osoby, zoznam, admin, likvid);
		}
	}
}