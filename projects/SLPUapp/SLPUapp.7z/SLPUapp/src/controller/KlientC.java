package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import model.Klient;
import model.Likvidator;
import model.RegistrovanaOsoba;
import model.Zaznam;
import view.KlientV;
import view.Prihlasenie;

/**
 * Trieda KlientC reprezentuje prepojenie medzi triedou KlientV (view) a met�dami v package model.
 */
public class KlientC {
	private KlientV klientV;
	private ArrayList<RegistrovanaOsoba> osoby;
	private ArrayList<Zaznam> zoznam;
	private String meno;
	private RegistrovanaOsoba admin;
	private Likvidator likvid;

	/**
	 * Kon�truktor triedy KlientC
	 * @param klientV Okno vytvoren� triedou KlientV.
	 * @param osoby Zoznam registrovan�ch os�b.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach.
	 * @param admin In�tancia triedy RegistrovanaOsoba - pou��vanie prekonanej met�dy.
	 * @param likvid In�tancia triedy Likvidator - pou��vanie prekonanej met�dy.
	 */
	public KlientC(ArrayList<RegistrovanaOsoba> osoby, ArrayList<Zaznam> zoznam, KlientV klientV, String meno, RegistrovanaOsoba admin, Likvidator likvid) {
		this.admin = admin;
		this.likvid = likvid;
		this.klientV = klientV;
		this.meno = meno;
		this.zoznam = zoznam;
		this.osoby = osoby;
		this.klientV.addVypisZaznamuKListener(new VypisZaznamuKListener());
		this.klientV.addZmazanieZaznamuKListener(new ZmazanieZaznamuKListener());
		this.klientV.addVytvorenieZaznamuKListener(new VytvorenieZaznamuKListener());
		this.klientV.addVypisAdminovKListener(new VypisAdminovKListener());
		this.klientV.addVycistiKListener(new VycistiKListener());
		this.klientV.addOdhlasitKListener(new OdhlasitKListener());
	}
	
	/**
	 * Vhniezden� trieda VypisZaznamuKListener reprezentuje situ�ciu po stla�en� tla��tka V�pis z�znamu.
	 */
	class VypisZaznamuKListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String vypis;
			/**
			 * @see model.Klient#vypisanieZaznamuKlient(ArrayList<Zaznam> zoznam, String meno)
			 */
			vypis = Klient.vypisanieZaznamuKlient(zoznam, meno);
			if (vypis.equals("0")) klientV.neexistujuciZaznamKError();
			else klientV.vypisuj(vypis);
		}
	}
	
	/**
	 * Vhniezden� trieda ZmazanieZaznamuKListener reprezentuje situ�ciu po stla�en� tla��tka Zmazanie z�znamu.
	 */
	class ZmazanieZaznamuKListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			int zmaz;
			/**
			 * @see model.Klient#zmazanieZaznamuKlient(ArrayList<Zaznam> zoznam, String meno)
			 */
			zmaz = Klient.zmazanieZaznamuKlient(zoznam, meno);
			if (zmaz == 0) klientV.neexistujuciZaznamKError();
			if (zmaz == 1) klientV.vymazanyZaznamK();
		}
	}
	
	/**
	 * Vhniezden� trieda VytvorenieZaznamuKListener reprezentuje situ�ciu po stla�en� tla��tka Vytvorenie z�znamu.
	 */
	class VytvorenieZaznamuKListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String miesto;
			int rok = 2010;
			int mesiac;
			int den;
			String email;
			String adresa;
			int vytvorenie;
			
			miesto = klientV.getMiestoK();
			rok = klientV.getRokK();
			mesiac = klientV.getMesiacK();
			den = klientV.getDenK();
			email = klientV.getEmailK();
			adresa = klientV.getAdresaK();
			/**
			 * @see model.Klient#vytvorenieZaznamuKlient(ArrayList<Zaznam> zoznam, String meno, String zmiesto, int zrok, int zmesiac, int zden, String zemail, String zadresa)
			 */
			vytvorenie = Klient.vytvorenieZaznamuKlient(zoznam, meno, miesto, rok, mesiac, den, email, adresa);
			if (vytvorenie == 3) klientV.existujeZaznamKError();
			if (vytvorenie == 1) klientV.vytvorenyZaznamK();
			if (vytvorenie == 2) klientV.nezadanyParameterKError();
			if (vytvorenie == 4) {
				klientV.nekorektnyDenKError();
				klientV.vytvorenyZaznamK();
			}
		}
	}
	
	/**
	 * Vhniezden� trieda VypisAdminovKListener reprezentuje situ�ciu po stla�en� tla��tka V�pis administr�torov.
	 */
	class VypisAdminovKListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.RegistrovanaOsoba#funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby)
			 */
			pole = admin.funkciaVypisuBossov(osoby);
			if (pole.get(0).equals("0")) klientV.neexistujucaOsobaKError();
			else if (pole.get(0).equals("1")) klientV.neexistujuciAdminKError();
			else for (String i: pole) klientV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda VycistiKListener reprezentuje situ�ciu po stla�en� tla��tka Clear.
	 */
	class VycistiKListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			klientV.vycisti();
		}
	}
	
	/**
	 * Vhniezden� trieda OdhlasitKListener reprezentuje situ�ciu po stla�en� tla��tka Odhl�si�.
	 */
	class OdhlasitKListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Prihlasenie prihlasenie = new Prihlasenie();
			klientV.dispose();
			prihlasenie.setVisible(true);
			@SuppressWarnings("unused")
			PrihlasenieC prihlasenieCont = new PrihlasenieC(prihlasenie, osoby, zoznam, admin, likvid);
		}
	}
}