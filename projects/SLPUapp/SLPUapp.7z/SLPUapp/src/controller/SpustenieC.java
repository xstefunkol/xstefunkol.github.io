package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import model.Likvidator;
import model.RegistrovanaOsoba;
import model.Zaznam;
import view.Prihlasenie;
import view.RegistrovanieKlienta;
import view.Spustenie;

/**
 * Trieda SpustenieC reprezentuje prepojenie medzi triedou Spustenie (view) a met�dami v package model.
 */
public class SpustenieC {
	private Spustenie spustenie;
	private ArrayList<RegistrovanaOsoba> osoby;
	private ArrayList<Zaznam> zoznam;
	private RegistrovanaOsoba admin;
	private Likvidator likvid;

	/**
	 * Kon�truktor triedy SpustenieC
	 * @param spustenie Okno vytvoren� triedou Spustenie.
	 * @param osoby Zoznam registrovan�ch os�b.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach.
	 * @param admin In�tancia triedy RegistrovanaOsoba - pou��vanie prekonanej met�dy.
	 * @param likvid In�tancia triedy Likvidator - pou��vanie prekonanej met�dy.
	 */
	public SpustenieC(Spustenie spustenie, ArrayList<RegistrovanaOsoba> osoby, ArrayList<Zaznam> zoznam, RegistrovanaOsoba admin, Likvidator likvid) {
		this.admin = admin;
		this.likvid = likvid;
		this.zoznam = zoznam;
		this.osoby = osoby;
		this.spustenie = spustenie;
		this.spustenie.addRegistraciaSListener(new RegistraciaSListener());
		this.spustenie.addPrihlasenieSListener(new PrihlasenieSListener());
	}
	
	/**
	 * Vhniezden� trieda RegistraciaSListener reprezentuje situ�ciu po stla�en� tla��tka Registrovanie klienta.
	 */
	class RegistraciaSListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			RegistrovanieKlienta registrovanieK = new RegistrovanieKlienta();
			spustenie.dispose();
			registrovanieK.setVisible(true);
			@SuppressWarnings("unused")
			RegistrovanieKlientaC registrovanieKCont = new RegistrovanieKlientaC(registrovanieK, osoby, zoznam, admin, likvid);
		}
	}
	
	/**
	 * Vhniezden� trieda PrihlasenieSListener reprezentuje situ�ciu po stla�en� tla��tka Prihl�senie.
	 */
	class PrihlasenieSListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (osoby.isEmpty() == true) spustenie.niktoRegError();
			else {
				Prihlasenie prihlasenie = new Prihlasenie();
				spustenie.dispose();
				prihlasenie.setVisible(true);
				@SuppressWarnings("unused")
				PrihlasenieC prihlasenieCont = new PrihlasenieC(prihlasenie, osoby, zoznam, admin, likvid);
			}
		}
	}
}