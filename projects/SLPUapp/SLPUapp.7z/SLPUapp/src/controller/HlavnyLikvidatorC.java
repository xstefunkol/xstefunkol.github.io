package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import model.HlavnyLikvidator;
import model.Likvidator;
import model.RegistrovanaOsoba;
import model.Zaznam;
import view.HlavnyLikvidatorV;
import view.Prihlasenie;

/**
 * Trieda HlavnyLikvidatorC reprezentuje prepojenie medzi triedou HlavnyLikvidatorV (view) a met�dami v package model.
 */
public class HlavnyLikvidatorC {
	private HlavnyLikvidatorV hlavnylikvidatorV;
	private ArrayList<RegistrovanaOsoba> osoby;
	private ArrayList<Zaznam> zoznam;
	private RegistrovanaOsoba admin;
	private Likvidator likvid;

	/**
	 * Kon�truktor triedy HlavnyLikvidatorC
	 * @param hlavnylikvidatorV Okno vytvoren� triedou HlavnyLikvidatorV.
	 * @param osoby Zoznam registrovan�ch os�b.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach.
	 * @param admin In�tancia triedy RegistrovanaOsoba - pou��vanie prekonanej met�dy.
	 * @param likvid In�tancia triedy Likvidator - pou��vanie prekonanej met�dy.
	 */
	public HlavnyLikvidatorC(ArrayList<RegistrovanaOsoba> osoby, ArrayList<Zaznam> zoznam, HlavnyLikvidatorV hlavnylikvidatorV, RegistrovanaOsoba admin, Likvidator likvid) {
		this.admin = admin;
		this.likvid = likvid;
		this.hlavnylikvidatorV = hlavnylikvidatorV;
		this.zoznam = zoznam;
		this.osoby = osoby;
		this.hlavnylikvidatorV.addVypisZaznamovHLListener(new VypisZaznamovHLListener());
		this.hlavnylikvidatorV.addRegistrujLikvidatoraHLListener(new RegistrujLikvidatoraHLListener());
		this.hlavnylikvidatorV.addPrepustiLikvidatoraHLListener(new PrepustiLikvidatoraHLListener());
		this.hlavnylikvidatorV.addNastavSchvalHLListener(new NastavSchvalHLListener());
		this.hlavnylikvidatorV.addNastavenieSumyHLListener(new NastavenieSumyHLListener());
		this.hlavnylikvidatorV.addNastaveniePoistHLListener(new NastaveniePoistHLListener());
		this.hlavnylikvidatorV.addVypisAdminovHLListener(new VypisAdminovHLListener());
		this.hlavnylikvidatorV.addVycistiHLListener(new VycistiHLListener());
		this.hlavnylikvidatorV.addOdhlasitHLListener(new OdhlasitHLListener());
	}

	/**
	 * Vhniezden� trieda VypisZaznamovHLListener reprezentuje situ�ciu po stla�en� tla��tka V�pis z�znamov.
	 */
	class VypisZaznamovHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.HlavnyLikvidator#vypisanieZaznamuHlavnyLikvidator(ArrayList<Zaznam> zoznam)
			 */
			pole = HlavnyLikvidator.vypisanieZaznamuHlavnyLikvidator(zoznam);
			if (pole.get(0).equals("0")) hlavnylikvidatorV.neexistujuciZoznamHLError();
			else for (String i: pole) hlavnylikvidatorV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda RegistrujLikvidatoraHLListener reprezentuje situ�ciu po stla�en� tla��tka Zaregistrovanie likvid�tora.
	 */
	class RegistrujLikvidatoraHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			String heslo;
			int pridaj;
			meno = hlavnylikvidatorV.getMenoHL();
			heslo = hlavnylikvidatorV.getHesloHL();
			/**
			 * @see model.HlavnyLikvidator#pridanieLikvidatora(ArrayList<RegistrovanaOsoba> osoby, String meno, String heslo)
			 */
			pridaj = HlavnyLikvidator.pridanieLikvidatora(osoby, meno, heslo);
			if (pridaj == 0) hlavnylikvidatorV.nezadanyParameterHLError();
			if (pridaj == 1) hlavnylikvidatorV.uspesnaRegHL();
			if (pridaj == 2) hlavnylikvidatorV.zhodneMenaHLError();
		}
	}
	
	/**
	 * Vhniezden� trieda PrepustiLikvidatoraHLListener reprezentuje situ�ciu po stla�en� tla��tka Prepustenie likvid�tora.
	 */
	class PrepustiLikvidatoraHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			int prepustenie;
			meno = hlavnylikvidatorV.getMenoHL();
			/**
			 * @see model.HlavnyLikvidator#prepustenieLikvidatora(ArrayList<RegistrovanaOsoba> osoby, String meno)
			 */
			prepustenie = HlavnyLikvidator.prepustenieLikvidatora(osoby, meno);
			if (prepustenie == 0) hlavnylikvidatorV.nezadanyParameterHLError();
			if (prepustenie == 1) hlavnylikvidatorV.neexistujucaOsobaHLError();
			if (prepustenie == 2) hlavnylikvidatorV.nezhodneMenaHLError();
			if (prepustenie == 3) hlavnylikvidatorV.prepustenyLikvidatorHL();
			if (prepustenie == 4) hlavnylikvidatorV.inyTypOpravneniaHLError();
		}
	}
	
	/**
	 * Vhniezden� trieda NastavSchvalHLListener reprezentuje situ�ciu po stla�en� tla��tka Nastavenie schv�lenosti.
	 */
	class NastavSchvalHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			int q;
			int schvalenost;
			meno = hlavnylikvidatorV.getMenoHL();
			q = hlavnylikvidatorV.getRozhodnutieSCHHL();
			/**
			 * @see model.HlavnyLikvidator#nastavenieSchvalenosti(ArrayList<Zaznam> zoznam, String meno, int q)
			 */
			schvalenost = HlavnyLikvidator.nastavenieSchvalenosti(zoznam, meno, q);
			if (schvalenost == 0) hlavnylikvidatorV.nezadanyParameterHLError();
			if (schvalenost == 1) hlavnylikvidatorV.neexistujuciZoznamHLError();
			if (schvalenost == 2) hlavnylikvidatorV.neexistujuciZaznamHLError();
			if (schvalenost == 3) hlavnylikvidatorV.aktualizovanyZaznamS1HL();
			if (schvalenost == 4) hlavnylikvidatorV.aktualizovanyZaznamS0HL();
		}
	}
	
	/**
	 * Vhniezden� trieda NastavenieSumyHLListener reprezentuje situ�ciu po stla�en� tla��tka Nastavenie v�platnej sumy.
	 * @throws NumberFormatException Ak je do textov�ho po�a, kde zad�vame ��slo vlo�en� string.
	 */
	class NastavenieSumyHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			double suma = 0;
			int nasts;
			meno = hlavnylikvidatorV.getMenoHL();
			try {
				suma = Double.parseDouble(hlavnylikvidatorV.getSumaHL());
			} catch (NumberFormatException r){
				suma = -1;
			}
			/**
			 * @see model.Likvidator#nastavenieSumy(ArrayList<Zaznam> zoznam, String meno, double suma)
			 */
			nasts = Likvidator.nastavenieSumy(zoznam, meno, suma);
			if (nasts == 0) hlavnylikvidatorV.nezadanyParameterHLError();
			if (nasts == 1) hlavnylikvidatorV.neexistujuciZoznamHLError();
			if (nasts == 2) hlavnylikvidatorV.neexistujuciZaznamHLError();
			if (nasts == 3) hlavnylikvidatorV.aktualizovanyZaznamSHL();
			if (nasts == 4) hlavnylikvidatorV.nekorektnaSumaHLError();
			if (nasts == 5) hlavnylikvidatorV.aktualizovanyZaznamSHLError();
		}
	}
	
	/**
	 * Vhniezden� trieda NastaveniePoistHLListener reprezentuje situ�ciu po stla�en� tla��tka Nastavenie typu poistenia.
	 */
	class NastaveniePoistHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			int q;
			int nasttp;
			meno = hlavnylikvidatorV.getMenoHL();
			q = hlavnylikvidatorV.getRozhodnutieTPHL();
			/**
			 * @see model.Likvidator#nastavenieTypuPoistenia(ArrayList<Zaznam> zoznam, String meno, int q)
			 */
			nasttp = Likvidator.nastavenieTypuPoistenia(zoznam, meno, q);
			if (nasttp == 0) hlavnylikvidatorV.nezadanyParameterHLError();
			if (nasttp == 1) hlavnylikvidatorV.neexistujuciZoznamHLError();
			if (nasttp == 2) hlavnylikvidatorV.neexistujuciZaznamHLError();
			if (nasttp == 3) hlavnylikvidatorV.aktualizovanyZaznamTPHL();
		}
	}
	
	/**
	 * Vhniezden� trieda VypisAdminovHLListener reprezentuje situ�ciu po stla�en� tla��tka V�pis administr�torov.
	 */
	class VypisAdminovHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.RegistrovanaOsoba#funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby)
			 */
			pole = admin.funkciaVypisuBossov(osoby);
			if (pole.get(0).equals("0")) hlavnylikvidatorV.neexistujucaOsobaHLError();
			else if (pole.get(0).equals("1")) hlavnylikvidatorV.neexistujuciAdminHLError();
			else for (String i: pole) hlavnylikvidatorV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda VycistiHLListener reprezentuje situ�ciu po stla�en� tla��tka Clear.
	 */
	class VycistiHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			hlavnylikvidatorV.vycisti();
		}
	}
	
	/**
	 * Vhniezden� trieda OdhlasitHLListener reprezentuje situ�ciu po stla�en� tla��tka Odhl�si�.
	 */
	class OdhlasitHLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Prihlasenie prihlasenie = new Prihlasenie();
			hlavnylikvidatorV.dispose();
			prihlasenie.setVisible(true);
			@SuppressWarnings("unused")
			PrihlasenieC prihlasenieCont = new PrihlasenieC(prihlasenie, osoby, zoznam, admin, likvid);
		}
	}
}