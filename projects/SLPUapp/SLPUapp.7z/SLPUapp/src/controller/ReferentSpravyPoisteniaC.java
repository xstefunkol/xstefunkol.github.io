package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import model.Likvidator;
import model.ReferentSpravyPoistenia;
import model.RegistrovanaOsoba;
import model.Zaznam;
import view.Prihlasenie;
import view.ReferentSpravyPoisteniaV;

/**
 * Trieda ReferentSpravyPoisteniaC reprezentuje prepojenie medzi triedou ReferentSpravyPoisteniaV (view) a met�dami v package model.
 */
public class ReferentSpravyPoisteniaC {
	private ReferentSpravyPoisteniaV referentV;
	private ArrayList<RegistrovanaOsoba> osoby;
	private ArrayList<Zaznam> zoznam;
	private RegistrovanaOsoba admin;
	private Likvidator likvid;

	/**
	 * Kon�truktor triedy ReferentSpravyPoisteniaC
	 * @param referentV Okno vytvoren� triedou ReferentSpravyPoisteniaV.
	 * @param osoby Zoznam registrovan�ch os�b.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach.
	 * @param admin In�tancia triedy RegistrovanaOsoba - pou��vanie prekonanej met�dy.
	 * @param likvid In�tancia triedy Likvidator - pou��vanie prekonanej met�dy.
	 */
	public ReferentSpravyPoisteniaC(ArrayList<RegistrovanaOsoba> osoby, ArrayList<Zaznam> zoznam, ReferentSpravyPoisteniaV referentV, RegistrovanaOsoba admin, Likvidator likvid) {
		this.admin = admin;
		this.likvid = likvid;
		this.referentV = referentV;
		this.zoznam = zoznam;
		this.osoby = osoby;
		this.referentV.addVypisZaznamovRListener(new VypisZaznamovRListener());
		this.referentV.addNastaveniePlatnostiRListener(new NastaveniePlatnostiRListener());
		this.referentV.addNastavenieVyplatenostiRListener(new NastavenieVyplatenostiRListener());
		this.referentV.addVypisAdminovRListener(new VypisAdminovRListener());
		this.referentV.addVycistiRListener(new VycistiRListener());
		this.referentV.addOdhlasitRListener(new OdhlasitRListener());
	}
	
	/**
	 * Vhniezden� trieda VypisZaznamovRListener reprezentuje situ�ciu po stla�en� tla��tka V�pis z�znamov.
	 */
	class VypisZaznamovRListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.ReferentSpravyPoistenia#vypisanieZaznamuReferent(ArrayList<Zaznam> zoznam)
			 */
			pole = ReferentSpravyPoistenia.vypisanieZaznamuReferent(zoznam);
			if (pole.get(0).equals("0")) referentV.neexistujuciZoznamRError();
			else for (String i: pole) referentV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda NastaveniePlatnostiRListener reprezentuje situ�ciu po stla�en� tla��tka Nastavenie platnosti z�znamu.
	 */
	class NastaveniePlatnostiRListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			int q;
			int nastp;
			meno = referentV.getMenoR();
			q = referentV.getRozhodnutieR();
			/**
			 * @see model.ReferentSpravyPoistenia#nastaveniePlatnosti(ArrayList<Zaznam> zoznam, String meno, int q)
			 */
			nastp = ReferentSpravyPoistenia.nastaveniePlatnosti(zoznam, meno, q);
			if (nastp == 0) referentV.neexistujuciZoznamRError();
			if (nastp == 1) referentV.neexistujuciZaznamRError();
			if (nastp == 2) referentV.aktualizovanyZaznamRP();
			if (nastp == 3) referentV.aktualizovanyZaznamRN();
			if (nastp == 4) referentV.nezadanyParameterRError();
		}
	}
	
	/**
	 * Vhniezden� trieda NastavenieVyplatenostiRListener reprezentuje situ�ciu po stla�en� tla��tka Nastavenie vyplatenosti z�znamu.
	 */
	class NastavenieVyplatenostiRListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			int q;
			int nastp;
			meno = referentV.getMenoR();
			q = referentV.getRozhodnutieR();
			/**
			 * @see model.ReferentSpravyPoistenia#nastavenieVyplatenosti(ArrayList<Zaznam> zoznam, String meno, int q)
			 */
			nastp = ReferentSpravyPoistenia.nastavenieVyplatenosti(zoznam, meno, q);
			if (nastp == 0) referentV.nezadanyParameterRError();
			if (nastp == 1) referentV.neexistujuciZoznamRError();
			if (nastp == 2) referentV.neexistujuciZaznamRError();
			if (nastp == 3) referentV.aktualizovanyZaznamRV();
			if (nastp == 4) referentV.schvalenieHLRError();
			if (nastp == 5) referentV.neplatnyZaznamRError();
			if (nastp == 6) referentV.aktualizovanyZaznamRVN();
		}
	}
	
	/**
	 * Vhniezden� trieda VypisAdminovRListener reprezentuje situ�ciu po stla�en� tla��tka V�pis administr�torov.
	 */
	class VypisAdminovRListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.RegistrovanaOsoba#funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby)
			 */
			pole = admin.funkciaVypisuBossov(osoby);
			if (pole.get(0).equals("0")) referentV.neexistujucaOsobaRError();
			else if (pole.get(0).equals("1")) referentV.neexistujuciAdminRError();
			else for (String i: pole) referentV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda VycistiRListener reprezentuje situ�ciu po stla�en� tla��tka Clear.
	 */
	class VycistiRListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			referentV.vycisti();
		}
	}
	
	/**
	 * Vhniezden� trieda OdhlasitRListener reprezentuje situ�ciu po stla�en� tla��tka Odhl�si�.
	 */
	class OdhlasitRListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Prihlasenie prihlasenie = new Prihlasenie();
			referentV.dispose();
			prihlasenie.setVisible(true);
			@SuppressWarnings("unused")
			PrihlasenieC prihlasenieCont = new PrihlasenieC(prihlasenie, osoby, zoznam, admin, likvid);
		}
	}
}