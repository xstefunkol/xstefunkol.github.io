package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import model.Likvidator;
import model.RegistrovanaOsoba;
import model.Zaznam;
import view.LikvidatorV;
import view.Prihlasenie;

/**
 * Trieda LikvidatorC reprezentuje prepojenie medzi triedou LikvidatorV (view) a met�dami v package model.
 */
public class LikvidatorC {
	private LikvidatorV likvidatorV;
	private ArrayList<RegistrovanaOsoba> osoby;
	private ArrayList<Zaznam> zoznam;
	private RegistrovanaOsoba admin;
	private Likvidator likvid;

	/**
	 * Kon�truktor triedy LikvidatorC
	 * @param likvidatorV Okno vytvoren� triedou LikvidatorV.
	 * @param osoby Zoznam registrovan�ch os�b.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach.
	 * @param admin In�tancia triedy RegistrovanaOsoba - pou��vanie prekonanej met�dy.
	 * @param likvid In�tancia triedy Likvidator - pou��vanie prekonanej met�dy.
	 */
	public LikvidatorC(ArrayList<RegistrovanaOsoba> osoby, ArrayList<Zaznam> zoznam, LikvidatorV likvidatorV, RegistrovanaOsoba admin, Likvidator likvid) {
		this.admin = admin;
		this.likvid = likvid;
		this.likvidatorV = likvidatorV;
		this.zoznam = zoznam;
		this.osoby = osoby;
		this.likvidatorV.addVypisZaznamovLListener(new VypisZaznamovLListener());
		this.likvidatorV.addNastavenieSumyLListener(new NastavenieSumyLListener());
		this.likvidatorV.addNastaveniePoistLListener(new NastaveniePoistLListener());
		this.likvidatorV.addVypisAdminovHLLListener(new VypisAdminovHLLListener());
		this.likvidatorV.addVycistiLListener(new VycistiLListener());
		this.likvidatorV.addOdhlasitLListener(new OdhlasitLListener());
	}
	
	/**
	 * Vhniezden� trieda VypisZaznamovLListener reprezentuje situ�ciu po stla�en� tla��tka V�pis z�znamov.
	 */
	class VypisZaznamovLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.Likvidator#vypisanieZaznamuLikvidator(ArrayList<Zaznam> zoznam)
			 */
			pole = Likvidator.vypisanieZaznamuLikvidator(zoznam);
			if (pole.get(0).equals("0")) likvidatorV.neexistujucaOsobaLError();
			else for (String i: pole) likvidatorV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda NastavenieSumyLListener reprezentuje situ�ciu po stla�en� tla��tka Nastavenie v�platnej sumy.
	 * @throws NumberFormatException Ak je do textov�ho po�a, kde zad�vame ��slo vlo�en� string.
	 */
	class NastavenieSumyLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			double suma = 0;
			int nasts;
			meno = likvidatorV.getMenoL();
			try {
				suma = Double.parseDouble(likvidatorV.getSumaL());
			} catch (NumberFormatException r){
				suma = -1;
			}
			/**
			 * @see model.Likvidator#nastavenieSumy(ArrayList<Zaznam> zoznam, String meno, double suma)
			 */
			nasts = Likvidator.nastavenieSumy(zoznam, meno, suma);
			if (nasts == 0) likvidatorV.nezadanyParameterMenoLError();
			if (nasts == 1) likvidatorV.neexistujuciZoznamLError();
			if (nasts == 2) likvidatorV.neexistujuciZaznamLError();
			if (nasts == 3) likvidatorV.aktualizovanyZaznamSL();
			if (nasts == 4) likvidatorV.nekorektnaSumaLError();
			if (nasts == 5) likvidatorV.aktualizovanyZaznamSLError();
		}
	}
	
	/**
	 * Vhniezden� trieda NastaveniePoistLListener reprezentuje situ�ciu po stla�en� tla��tka Nastavenie typu poistenia.
	 */
	class NastaveniePoistLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			int q;
			int nasttp;
			meno = likvidatorV.getMenoL();
			q = likvidatorV.getRozhodnutieL();
			/**
			 * @see model.Likvidator#nastavenieTypuPoistenia(ArrayList<Zaznam> zoznam, String meno, int q)
			 */
			nasttp = Likvidator.nastavenieTypuPoistenia(zoznam, meno, q);
			if (nasttp == 0) likvidatorV.nezadanyParameterMenoLError();
			if (nasttp == 1) likvidatorV.neexistujuciZoznamLError();
			if (nasttp == 2) likvidatorV.neexistujuciZaznamLError();
			if (nasttp == 3) likvidatorV.aktualizovanyZaznamTPL();
		}
	}
	
	/**
	 * Vhniezden� trieda VypisAdminovHLLListener reprezentuje situ�ciu po stla�en� tla��tka V�pis nadriaden�ch.
	 */
	class VypisAdminovHLLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> pole = new ArrayList<>();
			/**
			 * @see model.Likvidator#funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby)
			 */
			pole = likvid.funkciaVypisuBossov(osoby);
			if (pole.get(0).equals("0")) likvidatorV.neexistujucaOsobaLError();
			else if (pole.get(0).equals("1")) likvidatorV.neexistujuciAdminHLLError();
			else for (String i: pole) likvidatorV.vypisuj(i);
		}
	}
	
	/**
	 * Vhniezden� trieda VycistiLListener reprezentuje situ�ciu po stla�en� tla��tka Clear.
	 */
	class VycistiLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			likvidatorV.vycisti();
		}
	}
	
	/**
	 * Vhniezden� trieda OdhlasitLListener reprezentuje situ�ciu po stla�en� tla��tka Odhl�si�.
	 */
	class OdhlasitLListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Prihlasenie prihlasenie = new Prihlasenie();
			likvidatorV.dispose();
			prihlasenie.setVisible(true);
			@SuppressWarnings("unused")
			PrihlasenieC prihlasenieCont = new PrihlasenieC(prihlasenie, osoby, zoznam, admin, likvid);
		}
	}
}