package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import model.Likvidator;
import model.RegistrovanaOsoba;
import model.Zaznam;
import view.RegistrovanieKlienta;
import view.Spustenie;

/**
 * Trieda RegistrovanieKlientaC reprezentuje prepojenie medzi triedou RegistrovanieKlienta (view) a met�dami v package model.
 */
public class RegistrovanieKlientaC {
	private ArrayList<RegistrovanaOsoba> osoby;
	private RegistrovanieKlienta registrovanieklienta;
	private ArrayList<Zaznam> zoznam;
	private RegistrovanaOsoba admin;
	private Likvidator likvid;

	/**
	 * Kon�truktor triedy RegistrovanieKlientaC
	 * @param registrovanieklienta Okno vytvoren� triedou RegistrovanieKlienta.
	 * @param osoby Zoznam registrovan�ch os�b.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach.
	 * @param admin In�tancia triedy RegistrovanaOsoba - pou��vanie prekonanej met�dy.
	 * @param likvid In�tancia triedy Likvidator - pou��vanie prekonanej met�dy.
	 */
	public RegistrovanieKlientaC(RegistrovanieKlienta registrovanieklienta, ArrayList<RegistrovanaOsoba> osoby, ArrayList<Zaznam> zoznam, RegistrovanaOsoba admin, Likvidator likvid) {
		this.osoby = osoby;
		this.admin = admin;
		this.likvid = likvid;
		this.zoznam = zoznam;
		this.registrovanieklienta = registrovanieklienta;
		this.registrovanieklienta.addRegistrovatRKListener(new RegistrovatRKListener());
		this.registrovanieklienta.addBackRKListener(new BackRKListener());
	}
	
	/**
	 * Vhniezden� trieda RegistrovatRKListener reprezentuje situ�ciu po stla�en� tla��tka Registrova�.
	 */
	class RegistrovatRKListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String meno;
			String heslo;
			int reg;
			meno = registrovanieklienta.getMenoRK();
			heslo = registrovanieklienta.getHesloRK();
			/**
			 * @see model.RegistrovanaOsoba#registraciaKlient(ArrayList<RegistrovanaOsoba> osoby, String meno, String heslo)
			 */
			reg = RegistrovanaOsoba.registraciaKlient(osoby, meno, heslo);
			if (reg == 1) registrovanieklienta.uspesnaRegistracia();
			if (reg == 0) registrovanieklienta.zhodneMenaError();
			if (reg == 2) registrovanieklienta.nedostatokParametrovRKError();
		}
	}
	
	/**
	 * Vhniezden� trieda BackRKListener reprezentuje situ�ciu po stla�en� tla��tka Sp�.
	 */
	class BackRKListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Spustenie spustenie = new Spustenie();
			registrovanieklienta.dispose();
			spustenie.setVisible(true);
			@SuppressWarnings("unused")
			SpustenieC spustenieCont = new SpustenieC(spustenie, osoby, zoznam, admin, likvid);
		}
	}
}