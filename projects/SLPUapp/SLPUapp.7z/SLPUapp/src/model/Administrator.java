package model;

import java.util.ArrayList; // Import potrebn�ch bal�kov.

/**
 * Trieda Administrator ded� od triedy RegistrovanaOsoba a reprezentuje pou��vate�a s opr�vnen�m Administr�tor s jeho funkciami v aplik�cii.
 */
public class Administrator extends RegistrovanaOsoba {
	
	public Administrator() { // Kon�truktor triedy Administrator.
		
	}

	public Administrator(String meno, String heslo) { // Pre�a�uj�ci kon�truktor triedy Administrator, nastavenie mena, hesla a opr�vnenia nadtriedy, druh polymorfizmu.
		super(meno, heslo, "Administr�tor"); // Volanie prekonan�ho kon�truktora triedy RegistrovanaOsoba.
	}
	
	/* (non-Javadoc)
	 * @see model.RegistrovanaOsoba#funkciaVypisuBossov(java.util.ArrayList)
	 */
	public ArrayList<String> funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby) {
		return super.funkciaVypisuBossov(osoby);
	}

	/**
	 * Met�da, ktor� sl��i na vyh�adanie mien, hesiel a opr�vnen� v�etk�ch registrovan�ch os�b.
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @return ur�it� �daje v�etk�ch os�b alebo string "0" pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static ArrayList<String> vypisRegOsob(ArrayList<RegistrovanaOsoba> osoby) {
		String Stringk = "0";
		ArrayList<String> pole = new ArrayList<>();
		if ((osoby.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			pole.add(Stringk);
			return pole;
		} 
		else {
			for (RegistrovanaOsoba i : osoby) {
				Stringk = ("Meno: " + i.getMeno() + "\nHeslo: " + i.getHeslo() + "\nOpr�vnenie: " + i.getOpravnenie() + "\n");
				pole.add(Stringk);
			}
			return pole;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na registrovanie nov�ho pou��vate�a.
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @param meno Meno novozaregistrovan�ho pou��vate�a.
	 * @param heslo Heslo novozaregistrovan�ho pou��vate�a.
	 * @param q hodnota 1 a� 5 pod�a v�beru opr�vnenia.
	 * @return hodnota 0 a� 2 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int zaregistrovanie(ArrayList<RegistrovanaOsoba> osoby, String meno, String heslo, int q) {
		RegistrovanaOsoba nova = new RegistrovanaOsoba(); // Vytvorenie nov�ho objektu typu RegistrovanaOsoba.
		int x = 0;
		if ((meno.equals("")) || (heslo.equals(""))) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if (osoby.isEmpty() == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			nova.setMeno(meno); // Nastavenie mena.
			nova.setHeslo(heslo); // Nastavenie hesla.
			switch (q) {
			case 1:
				nova.setOpravnenie("Administr�tor");
				break;
			case 2:
				nova.setOpravnenie("Hlavn� likvid�tor");
				break;
			case 3:
				nova.setOpravnenie("Likvid�tor");
				break;
			case 4:
				nova.setOpravnenie("Referent spr�vy poistenia");
				break;
			case 5:
				nova.setOpravnenie("Klient");
				break;
			}
			osoby.add(nova); // Pridanie objektu do zoznamu registrovan�ch os�b.
			return 1;
		}
		else {
			for (RegistrovanaOsoba i : osoby) {
				if (meno.equals(i.getMeno())) {
					x++;
				}
			}
			if (x > 0) { // Ke� je hodnota po��tadla v��ia ako 0 znamen� to, �e tento pou��vate� u� existuje.
				return 2;
				}
			else {
				nova.setMeno(meno); // Nastavenie mena.
				nova.setHeslo(heslo); // Nastavenie hesla.
				switch (q) {
				case 1:
					nova.setOpravnenie("Administr�tor");
					break;
				case 2:
					nova.setOpravnenie("Hlavn� likvid�tor");
					break;
				case 3:
					nova.setOpravnenie("Likvid�tor");
					break;
				case 4:
					nova.setOpravnenie("Referent spr�vy poistenia");
					break;
				case 5:
					nova.setOpravnenie("Klient");
					break;
				}
				osoby.add(nova); // Pridanie objektu do zoznamu registrovan�ch os�b.
				return 1;
			}
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na vymazanie pou��vate�a.
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @param meno Meno pou��vate�a.
	 * @return hodnota 0 a� 3 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int vymazaniePouzivatela(ArrayList<RegistrovanaOsoba> osoby, String meno) {
		if (meno.equals("")) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((osoby.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			return 1;
		} 
		else {
			int x = 0;
			for (RegistrovanaOsoba i : osoby) { // Preh�ad�vanie zoznamu.
				if (!(meno.equals(i.getMeno()))) {
					x++;
					if (x == osoby.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu os�b v zozname znamen� to, �e nikto s tak�m menom nie je registrovan�.
						return 2;
					}
				} 
				else {
					osoby.remove(x); // Vymazanie.
					return 3;
				}
			}
			return 0;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na vyh�adanie z�znamov o poistn�ch udalostiach - v�etky �daje.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @return �daje v�etk�ch z�znamov alebo string "0" pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static ArrayList<String> vypisZoznamu(ArrayList<Zaznam> zoznam) {
		String Stringk = "0";
		ArrayList<String> pole = new ArrayList<>();
		if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			pole.add(Stringk);
			return pole;
		} 
		else {
			String y;
			String z;
			String k;
			for (Zaznam i : zoznam) {
				if (i.isSchvalenost() == false) y = ("neschv�len�"); // Nastavenie v�pisu.
				else y = ("schv�len�");
				if (i.isVyplatenost() == false) z = ("nevyplaten�");
				else z = ("vyplaten�");
				if (i.isPlatnost() == false) k = ("neplatn�");
				else k = ("platn�");
				Stringk = ("Meno: " + i.getMenoZ() + "\nMiesto: " + i.getMiesto() + "\nD�tum: " + i.getDen() + "." + i.getMesiac() + "." + i.getRok() + "\nKontakt:\nEmail: " + i.getEmail() + "@gmail.com\nAdresa: " + i.getAdresa() + "\nTyp poistenia: " + i.getTyppoistenia() + "\nSchv�lenos�: " + y + "\nV�platn� suma: " + i.getSuma() + " eur\nVyplatenos� sumy: " + z + "\nPlatnos� z�znamu o poistnej udalosti: " + k + "\n");
				pole.add(Stringk);
			}
			return pole;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na vymazanie z�znamu o poistnej udalosti ur�it�ho klienta.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @return hodnota 0 a� 3 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int vymazanieZaznamu(ArrayList<Zaznam> zoznam, String meno) {
		if (meno.equals("")) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			return 1;
		} 
		else {
			int x = 0;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu.
				if (!(meno.equals(i.getMenoZ()))) {
					x++;
					if (x == zoznam.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return 2;
					}
				} 
				else {
					zoznam.remove(x); // Vymazanie.
					return 3;
				}
			}
			return 0;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na vytvorenie z�znamu o poistnej udalosti pod�a zadan�ch parametrov.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @param zmiesto Miesto sp�sobenia poistnej udalosti.
	 * @param zrok Rok sp�sobenia poistnej udalosti.
	 * @param zmesiac Mesiac sp�sobenia poistnej udalosti.
	 * @param zden De� sp�sobenia poistnej udalosti.
	 * @param zemail Email ako kontakt na dan�ho klienta.
	 * @param zadresa Adresa trval�ho bydliska klienta.
	 * @return hodnota 0 a� 2 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int vytvorenieZaznamu(ArrayList<Zaznam> zoznam, String meno, String zmiesto, int zrok, int zmesiac, int zden, String zemail, String zadresa) {
		int x = 0;
		if ((meno.equals("")) || (zmiesto.equals("")) || (zrok == 0) || (zmesiac == 0) || (zden == 0) || (zemail.equals("")) || (zadresa.equals(""))) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			Zaznam novy = new Zaznam(); // Vytvorenie nov�ho objektu typu Zaznam.
			novy.setMenoZ(meno);
			novy.setMiesto(zmiesto);
			novy.setRok(zrok); 
			novy.setMesiac(zmesiac);
			novy.setDen(zden);
			novy.setEmail(zemail);
			novy.setAdresa(zadresa);
			novy.setTyppoistenia("Zatia� nenastaven� - kontaktujte likvid�tora!");
			novy.setSchvalenost(false);
			novy.setSuma(0);
			novy.setVyplatenost(false);
			novy.setPlatnost(true);
			zoznam.add(novy);
			return 1;
		} 
		else {
			for (Zaznam i : zoznam) {
				if (!(meno.equals(i.getMenoZ()))) { // Zis�ovanie zhody mena.
					x++;
					if (x == zoznam.size()) {
						Zaznam novy = new Zaznam(); // Vytvorenie nov�ho objektu typu Zaznam.
						novy.setMenoZ(meno);
						novy.setMiesto(zmiesto);
						novy.setRok(zrok); 
						novy.setMesiac(zmesiac);
						novy.setDen(zden);
						novy.setEmail(zemail);
						novy.setAdresa(zadresa);
						novy.setTyppoistenia("Zatia� nenastaven� - kontaktujte likvid�tora!");
						novy.setSchvalenost(false);
						novy.setSuma(0);
						novy.setVyplatenost(false);
						novy.setPlatnost(true);
						zoznam.add(novy);
						return 1;
					}
					else {
						return 2;
					}
				} 
			}
			return 0;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na zmenu �dajov pou��vate�a.
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @param meno Meno novozaregistrovan�ho pou��vate�a.
	 * @param heslo Heslo novozaregistrovan�ho pou��vate�a.
	 * @param q hodnota 1 a� 5 pod�a v�beru opr�vnenia.
	 * @return hodnota 0 a� 3 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int zmenaUdajovVRegOsob(ArrayList<RegistrovanaOsoba> osoby, String meno, String heslo, int q) {
		if ((meno.equals("")) || (heslo.equals(""))) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((osoby.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			return 1;
		}
		else {
			int x = 0;
			for (RegistrovanaOsoba i : osoby) { // Preh�ad�vanie zoznamu.
				if (!(meno.equals(i.getMeno()))) {
					x++;
					if (x == osoby.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu os�b v zozname znamen� to, �e nikto s tak�m menom nie je registrovan�.
						return 2;
					}
				} 
				else {
					i.setHeslo(heslo); // Nastavenie hesla.
					switch (q) {
					case 1:
						i.setOpravnenie("Administr�tor");
						break;
					case 2:
						i.setOpravnenie("Hlavn� likvid�tor");
						break;
					case 3:
						i.setOpravnenie("Likvid�tor");
						break;
					case 4:
						i.setOpravnenie("Referent spr�vy poistenia");
						break;
					case 5:
						i.setOpravnenie("Klient");
						break;
					}
					return 3;
				}
			}
			return 0;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na zmenu �dajov v z�zname o poistnej udalosti pod�a zadan�ch parametrov.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @param zmiesto Miesto sp�sobenia poistnej udalosti.
	 * @param zrok Rok sp�sobenia poistnej udalosti.
	 * @param zmesiac Mesiac sp�sobenia poistnej udalosti.
	 * @param zden De� sp�sobenia poistnej udalosti.
	 * @param zemail Email ako kontakt na dan�ho klienta.
	 * @param zadresa Adresa trval�ho bydliska klienta.
	 * @return hodnota 0 a� 3 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int zmenaUdajovVZoznam(ArrayList<Zaznam> zoznam, String meno, String zmiesto, int zrok, int zmesiac, int zden, String zemail, String zadresa) {
		if ((meno.equals("")) || (zmiesto.equals("")) || (zrok == 0) || (zmesiac == 0) || (zden == 0) || (zemail.equals("")) || (zadresa.equals(""))) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			return 1;
		} 
		else {
			int x = 0;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu.
				if (!(meno.equals(i.getMenoZ()))) {
					x++;
					if (x == zoznam.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return 2;
					}
				} 
				else {
					i.setMiesto(zmiesto);
					i.setRok(zrok);
					i.setMesiac(zmesiac);
					i.setDen(zden);
					i.setEmail(zemail);
					i.setAdresa(zadresa);
					return 3;
				}
			}
			return 0;
		}
	}
}