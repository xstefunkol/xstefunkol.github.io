package model;

import java.util.ArrayList; // Import potrebn�ch bal�kov.

/**
 * Trieda HlavnyLikvidator ded� od triedy RegistrovanaOsoba a reprezentuje pou��vate�a s opr�vnen�m Hlavn� likvid�tor s jeho funkciami v aplik�cii.
 */
public class HlavnyLikvidator extends Likvidator {
	
	public HlavnyLikvidator() { // Kon�truktor triedy HlavnyLikvidator.
		
	}

	public HlavnyLikvidator(String meno, String heslo) { // Pre�a�uj�ci kon�truktor triedy HlavnyLikvidator, nastavenie mena, hesla a opr�vnenia nadtriedy, druh polymorfizmu.
		super(meno, heslo); // Volanie prekonan�ho kon�truktora triedy Likvidator.
		setOpravnenie("Hlavn� likvid�tor");
	}
	
	/* (non-Javadoc)
	 * @see model.Likvidator#funkciaVypisuBossov(java.util.ArrayList)
	 */
	public ArrayList<String> funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby) {
		int x = 0;
		String Stringk = "0";
		ArrayList<String> pole = new ArrayList<>();
		if ((osoby.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			pole.add(Stringk);
			return pole;
		} 
		else {
			for (RegistrovanaOsoba i : osoby) {
				if ((i.getOpravnenie()).equals("Administr�tor")) {
					Stringk = ("Meno: " + i.getMeno() + "\nOpr�vnenie: " + i.getOpravnenie() + "\n");
					pole.add(Stringk);
				}
				
				else {
					x++;
					if (x == osoby.size()) {
						Stringk = "1";
						pole.add(Stringk);
						return pole;
					}
				}
			}
			return pole;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na vyh�adanie z�znamov o poistn�ch udalostiach - meno, typu poistenia, hodnoty poistn�ho plnenia a schv�lenosti tejto hodnoty.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @return ur�it� �daje v�etk�ch z�znamov alebo string "0" pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static ArrayList<String> vypisanieZaznamuHlavnyLikvidator(ArrayList<Zaznam> zoznam) {
		String Stringk = "0";
		ArrayList<String> pole = new ArrayList<>();
		if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			pole.add(Stringk);
			return pole;
		} 
		else {
			String z;
			for (Zaznam i : zoznam) { 
				if (i.isSchvalenost() == false) z = ("neschv�len�"); // Nastavenie v�pisu.
				else z = ("schv�len�");
				Stringk = ("Meno: " + i.getMenoZ() + "\nTyp poistenia: " + i.getTyppoistenia() + "\nV�platn� suma: " + i.getSuma() + "\nSchv�lenos� poistn�ho plnenia: " + z + "\n"); // V�pis �dajov.
				pole.add(Stringk);
			}
			return pole;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na nastavenie schv�lenosti hodnoty poistn�ho plnenia ur�it�ho klienta.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @param q hodnota 0 a� 1 pod�a v�beru.
	 * @return hodnota 0 a� 4 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int nastavenieSchvalenosti(ArrayList<Zaznam> zoznam, String meno, int q) {
		if (meno.equals("")) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			return 1;
		} 
		else {
			int x = 0;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu.
				if (!(meno.equals(i.getMenoZ()))) {
					x++;
					if (x == zoznam.size()) {// Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return 2;
					}
				} 
				else { // Nastavovanie schv�lenosti.
					switch (q) {
					case 1:
						i.setSchvalenost(true);
						return 3;
					case 0:
						i.setSchvalenost(false);
						i.setVyplatenost(false);
						i.setSuma(0);
						return 4;
					}
					break;
				}
			}
			return 0;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na registrovanie nov�ho pou��vate�a opr�vnenia Likvid�tor.
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @param meno Meno novozaregistrovan�ho likvid�tora.
	 * @param heslo Heslo novozaregistrovan�ho likvid�tora.
	 * @return hodnota 0 a� 2 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int pridanieLikvidatora(ArrayList<RegistrovanaOsoba> osoby, String meno, String heslo) {
		RegistrovanaOsoba nova = new Likvidator(); // Vytvorenie novej in�tancie typu Likvidator.
		int x = 0;
		if ((meno.equals("")) || (heslo.equals(""))) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if (osoby.isEmpty() == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			nova.setMeno(meno); // Nastavenie mena.
			nova.setHeslo(heslo); // Nastavenie hesla.
			nova.setOpravnenie("Likvid�tor"); // Nastavenie opr�vnenia.
			osoby.add(nova); // Pridanie tohto objektu do zoznamu registrovan�ch os�b.
			return 1;
		}
		else {
			nova.setMeno(meno); // Nastavenie mena.
			for (RegistrovanaOsoba i : osoby) {
				if ((nova.getMeno()).equals(i.getMeno())) {
					x++;
				}
			}
			if (x > 0) { // Ke� je hodnota po��tadla v��ia ako 0 znamen� to, �e tento pou��vate� u� existuje.
				return 2;
			}
			else {
				nova.setHeslo(heslo); // Nastavenie hesla.
				nova.setOpravnenie("Likvid�tor"); // Nastavenie opr�vnenia.
				osoby.add(nova); // Pridanie tohto objektu do zoznamu registrovan�ch os�b.
				return 1;
			}
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na vymazanie pou��vate�a opr�vnenia Likvid�tor.
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @param meno Meno likvid�tora.
	 * @return hodnota 0 a� 4 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int prepustenieLikvidatora(ArrayList<RegistrovanaOsoba> osoby, String meno) {
		if (meno.equals("")) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((osoby.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			return 1;
		} 
		else {
			int x = 0;
			for (RegistrovanaOsoba i : osoby) { // Preh�ad�vanie zoznamu.
				if (!(meno.equals(i.getMeno()))) {
					x++;
					if (x == osoby.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu os�b v zozname znamen� to, �e nikto s tak�m menom nie je registrovan�.
						return 2;
					}
				} 
				else { // Ak je zaregistrovan�, zis�uje sa jeho opr�vnenie a ak je to likvid�tor tak ho vyma�e zo zoznamu registrovan�ch os�b.
					if ((osoby.get(x).getOpravnenie()).equals("Likvid�tor")) {
						osoby.remove(x);
						return 3;
					}
					else {
						return 4;
					}
				}
			}
			return 0;
		}
	}
}