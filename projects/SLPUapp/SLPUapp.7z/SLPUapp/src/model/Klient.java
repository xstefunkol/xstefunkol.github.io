package model;

import java.util.ArrayList; // Import potrebn�ch bal�kov.

/**
 * Trieda Klient ded� od triedy RegistrovanaOsoba a reprezentuje pou��vate�a s opr�vnen�m Klient s jeho funkciami v aplik�cii.
 */
public class Klient extends RegistrovanaOsoba {

	public Klient() { // Kon�truktor triedy Klient.

	}

	public Klient(String meno, String heslo) { // Pre�a�uj�ci kon�truktor triedy Klient, nastavenie mena, hesla a opr�vnenia nadtriedy, druh polymorfizmu.
		super(meno, heslo, "Klient"); // Volanie prekonan�ho kon�truktora triedy RegistrovanaOsoba.
	}
	
	/* (non-Javadoc)
	 * @see model.RegistrovanaOsoba#funkciaVypisuBossov(java.util.ArrayList)
	 */
	public ArrayList<String> funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby) {
		return super.funkciaVypisuBossov(osoby); // Volanie prekonanej met�dy triedy RegistrovanaOsoba.
	}

	/**
	 * Met�da, ktor� sl��i na vyh�adanie z�znamu o poistnej udalosti pod�a zadan�ho mena.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @return z�znam, ktor� je priraden� zadan�mu menu alebo string "0" pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static String vypisanieZaznamuKlient(ArrayList<Zaznam> zoznam, String meno) {
		if ((zoznam.isEmpty()) == true) { // O�etrenie mo�nosti, �e je zoznam z�znamov pr�zdny.
			return "0";
		} 
		else {
			int x = 0;
			String y;
			String z;
			String k;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu z�znamov.
				if (meno.equals(i.getMenoZ())) {
					if (i.isSchvalenost() == false) y = ("neschv�len�"); // Nastavenie v�pisu.
					else y = ("schv�len�");
					if (i.isVyplatenost() == false) z = ("nevyplaten�");
					else z = ("vyplaten�");
					if (i.isPlatnost() == false) k = ("neplatn�");
					else k = ("platn�");
					// Vr�ti string cel�ho z�znamu pre v�pis.
					return ("Meno: " + i.getMenoZ() + "\nMiesto: " + i.getMiesto() + "\nD�tum: " + i.getDen() + "." + i.getMesiac() + "." + i.getRok() + "\nKontakt:\nEmail: " + i.getEmail() + "@gmail.com\nAdresa: " + i.getAdresa() + "\nTyp poistenia: " + i.getTyppoistenia() + "\nSchv�lenos�: " + y + "\nV�platn� suma: " + i.getSuma() + " eur\nVyplatenos� sumy: " + z + "\nPlatnos� z�znamu o poistnej udalosti: " + k + "\n");
				}
				else {
					x++;
					if (x == zoznam.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return "0";
					}
				}
			}
			return "0";
		}
	}

	/**
	 * Met�da, ktor� sl��i na vymazanie z�znamu o poistnej udalosti pod�a zadan�ho mena.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @return hodnota 0 a� 1 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int zmazanieZaznamuKlient(ArrayList<Zaznam> zoznam, String meno) {
		if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			return 0;
		} 
		else {
			int x = 0;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu z�znamov.
				if (!(meno.equals(i.getMenoZ()))) {
					x++;
					if (x == zoznam.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return 0;
					}
				} 
				else {
					zoznam.remove(x); // Vymazanie z�znamu.
					return 1;
				}
			}
			return 0;
		}
	}

	/**
	 * Met�da, ktor� sl��i na vytvorenie z�znamu o poistnej udalosti pod�a zadan�ch parametrov.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @param zmiesto Miesto sp�sobenia poistnej udalosti.
	 * @param zrok Rok sp�sobenia poistnej udalosti.
	 * @param zmesiac Mesiac sp�sobenia poistnej udalosti.
	 * @param zden De� sp�sobenia poistnej udalosti.
	 * @param zemail Email ako kontakt na dan�ho klienta.
	 * @param zadresa Adresa trval�ho bydliska klienta.
	 * @return hodnota 0 a� 4 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int vytvorenieZaznamuKlient(ArrayList<Zaznam> zoznam, String meno, String zmiesto, int zrok, int zmesiac, int zden, String zemail, String zadresa) {
		int x=0;
		int z;
		if ((zmiesto.equals("")) || (zrok == 0) || (zmesiac == 0) || (zden == 0) || (zemail.equals("")) || (zadresa.equals(""))) return 2; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			Zaznam novy = new Zaznam(); // Vytvorenie novej in�tancie z�znamu.
			novy.setMenoZ(meno); 
			novy.setMiesto(zmiesto);
			novy.setRok(zrok); 
			novy.setMesiac(zmesiac);
			z = novy.setDen(zden);
			novy.setEmail(zemail);
			novy.setAdresa(zadresa);
			novy.setTyppoistenia("Zatia� nenastaven� - kontaktujte likvid�tora!");
			novy.setSchvalenost(false);
			novy.setSuma(0);
			novy.setVyplatenost(false);
			novy.setPlatnost(true);
			zoznam.add(novy);
			if (z == 0) return 4; // O�etrenie v�pisu pod�a spr�vnosti zadania d�a.
			else return 1;
		} 
		else {
			for (Zaznam i : zoznam) {
				if (!(meno.equals(i.getMenoZ()))) { // O�etrenie zadania mena, na ktor� u� je registrovan� z�znam.
					x++;
					if (x == zoznam.size()) {
						Zaznam novy = new Zaznam();
						novy.setMenoZ(meno); 
						novy.setMiesto(zmiesto);
						novy.setRok(zrok); 
						novy.setMesiac(zmesiac);
						z = novy.setDen(zden);
						novy.setEmail(zemail);
						novy.setAdresa(zadresa);
						novy.setTyppoistenia("Zatia� nenastaven� - kontaktujte likvid�tora!");
						novy.setSchvalenost(false);
						novy.setSuma(0);
						novy.setVyplatenost(false);
						novy.setPlatnost(true);
						zoznam.add(novy);
						if (z == 0) return 4;
						else return 1;
					}
				}
				else {
					return 3;
				}
			}
			return 0;
		}
	}
}