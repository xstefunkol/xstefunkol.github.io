package model;

import java.util.ArrayList; // Import potrebn�ch bal�kov.

public interface Rozhranie {
	/**
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @return pole obsahuj�ce v�etky osoby s �dajmi vyhovuj�ce podmienkam.
	 */
	public ArrayList<String> funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby);
}