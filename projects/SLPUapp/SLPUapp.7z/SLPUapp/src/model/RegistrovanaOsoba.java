package model;

import java.util.ArrayList; // Import potrebn�ch bal�kov.

/**
 * Trieda RegistrovanaOsoba reprezentuje pou��vate�ov zaregistrovan�ch v danej aplik�cii.
 */
public class RegistrovanaOsoba implements Rozhranie { // Zadefinovanie atrib�tov triedy RegistrovanaOsoba.
	private String meno;
	private String heslo;
	private String opravnenie;

	public RegistrovanaOsoba() { // Kon�truktor triedy RegistrovanaOsoba

	}

	public RegistrovanaOsoba(String meno, String heslo, String opravnenie) { // Pre�a�uj�ci kon�truktor triedy RegistrovanaOsoba, druh polymorfizmu.
		this.meno = meno;
		this.heslo = heslo;
		this.opravnenie = opravnenie;
	}
	
	/** Z�skavanie a nastavovanie �dajov v z�zname s registrovanou osobou pou�it�m getterov a setterov - pou�it� zapuzdrenie. */
	public String getMeno() {
		return meno;
	}

	public void setMeno(String meno) {
		this.meno = meno;
	}

	public String getHeslo() {
		return heslo;
	}

	public void setHeslo(String heslo) {
		this.heslo = heslo;
	}

	public String getOpravnenie() {
		return opravnenie;
	}

	public void setOpravnenie(String opravnenie) {
		this.opravnenie = opravnenie;
	}

	/**
	 * Met�da, ktor� sl��i na registrovanie nov�ho pou��vate�a opr�vnenia klient.
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @param meno Meno novozaregistrovan�ho klienta.
	 * @param heslo Heslo novozaregistrovan�ho klienta.
	 * @return hodnota 0 a� 2 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int registraciaKlient(ArrayList<RegistrovanaOsoba> osoby, String meno, String heslo) {
		RegistrovanaOsoba nova = new Klient(); // Vytvorenie novej in�tancie.
		int x = 0;
		if ((meno.equals("")) || (heslo.equals(""))) return 2; // O�etrenie mo�nosti nezadan�ho parametra.
		else if (osoby.isEmpty() == true) { // O�etrenie mo�nosti, �e je zoznam registrovan�ch os�b pr�zdny.
			nova.setMeno(meno); // Nastavenie mena.
			nova.setHeslo(heslo); // Nastavenie hesla.
			nova.setOpravnenie("Klient"); // Nastavenie opr�vnenia.
			osoby.add(nova); // Pridanie do po�a registrovan�ch os�b.
			return 1;
		}
		else {
			nova.setMeno(meno);
			for (RegistrovanaOsoba i : osoby) { // Preh�ad�vanie zoznamu pod�a mien.
				if ((nova.meno).equals(i.getMeno())) {
					x++;
				}
			}
			if (x > 0) return 0; // V pr�pade zistenia aspo� jednej zhody v zozname, sa zadan� meno nem��e pou�i�.
			else {
				nova.setHeslo(heslo);
				nova.setOpravnenie("Klient");
				osoby.add(nova);
				return 1;
			}
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na prihl�senie do aplik�cie pod�a zadan�ho mena a hesla.
	 * @param osoby Zoznam registrovan�ch os�b v programe.
	 * @param lmeno Meno pou��vate�a.
	 * @param lheslo Heslo pou��vate�a.
	 * @return opr�vnenie, ktor� je priraden� zadan�mu menu a heslu alebo string "0" a� "2" pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static String prihlasenie(ArrayList<RegistrovanaOsoba> osoby, String lmeno, String lheslo) {
		if ((lmeno.equals("")) || (lheslo.equals(""))) return "3"; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((osoby.isEmpty())==true) return "0"; // O�etrenie mo�nosti, �e je zoznam registrovan�ch os�b pr�zdny.
		else {
			int x = 0;
			for (RegistrovanaOsoba i : osoby) { // Preh�ad�vanie po�a s registrovan�mi osobami.
				if (!(lmeno.equals(i.getMeno()))) { // Pri nezhode mien sa po��tadlo nav��i o 1. Ke� sa hodnota v po��tadle rovn� po�tu objektov v poli, znamen� to, �e objekt s dan�m menom neexistuje.
					x++;
					if (x == osoby.size()) return "1";
				} 
				else { // Ak sa n�jde zhoda pokra�uje sa kontrolou hesla.
					if (lheslo.equals(i.getHeslo())) { // Ak sa hesl� zhoduj�, vr�ti sa opr�vnenie pridelen� k dan�mu menu a heslu.
						return i.getOpravnenie();
					} 
					else {
						return "2";
					}
				}
			}
			return "0";
		}
	}
	
	/* (non-Javadoc)
	 * @see model.Rozhranie#funkciaVypisuBossov(java.util.ArrayList)
	 * Met�da, ktor� sl��i na vyh�adanie v�etk�ch administr�torov zaregistrovan�ch v aplik�cii.
	 */
	public ArrayList<String> funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby) {
		int x = 0;
		String Stringk = "0";
		ArrayList<String> pole = new ArrayList<>();
		if ((osoby.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			pole.add(Stringk);
			return pole;
		} 
		else {
			for (RegistrovanaOsoba i : osoby) { // Preh�ad�vanie po�a s registrovan�mi osobami.
				if ((i.getOpravnenie()).equals("Administr�tor")) { // Ak sa opr�vnenie dan�ho objektu zhoduje s opr�vnen�m Administr�tor ulo�� v�ety �daje do po�a pre neskor�� v�pis.
					Stringk = ("Meno: " + i.getMeno() + "\nOpr�vnenie: " + i.getOpravnenie() + "\n");
					pole.add(Stringk);
				}
				
				else {
					x++;
					if (x == osoby.size()) { // Pri nezhode opr�vnen� sa po��tadlo nav��i o 1. Ke� sa hodnota v po��tadle rovn� po�tu objektov v poli, znamen� to, �e objekt s dan�m opr�vnen�m neexistuje. 
						Stringk = "1";
						pole.add(Stringk);
						return pole;
					}
				}
			}
			return pole;
		}
	}
}