package model;

import java.util.ArrayList; // Import potrebn�ch bal�kov.

/**
 * Trieda Likvidator ded� od triedy RegistrovanaOsoba a reprezentuje pou��vate�a s opr�vnen�m Likvid�tor s jeho funkciami v aplik�cii.
 */
public class Likvidator extends RegistrovanaOsoba {
	
	public Likvidator() { // Kon�truktor triedy Likvidator.
		
	}

	public Likvidator(String meno, String heslo) { // Pre�a�uj�ci kon�truktor triedy Likvidator, nastavenie mena, hesla a opr�vnenia nadtriedy, druh polymorfizmu.
		super(meno, heslo, "Likvid�tor"); // Volanie prekonan�ho kon�truktora triedy RegistrovanaOsoba.
	}
	
	/* (non-Javadoc)
	 * @see model.RegistrovanaOsoba#funkciaVypisuBossov(java.util.ArrayList)
	 * Upraven� met�da pre Likvid�tora - v�pis nielen Administr�torov, ale aj Hlavn�ch likvid�torov - Prekon�vaj�ca met�da.
	 */
	public ArrayList<String> funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby) {
		int x = 0;
		String Stringk = "0";
		ArrayList<String> pole = new ArrayList<>();
		if ((osoby.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu registrovan�ch os�b.
			pole.add(Stringk);
			return pole;
		} 
		else {
			for (RegistrovanaOsoba i : osoby) {
				if (((i.getOpravnenie()).equals("Administr�tor")) || ((i.getOpravnenie()).equals("Hlavn� likvid�tor"))) {
					Stringk = ("Meno: " + i.getMeno() + "\nOpr�vnenie: " + i.getOpravnenie() + "\n");
					pole.add(Stringk);
				}
				
				else {
					x++;
					if (x == osoby.size()) {
						Stringk = "1";
						pole.add(Stringk);
						return pole;
					}
				}
			}
			return pole;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na vyh�adanie z�znamov o poistn�ch udalostiach - meno, typu poistenia a hodnoty poistn�ho plnenia.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @return ur�it� �daje v�etk�ch z�znamov alebo string "0" pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static ArrayList<String> vypisanieZaznamuLikvidator(ArrayList<Zaznam> zoznam) {
		String Stringk = "0";
		ArrayList<String> pole = new ArrayList<>();
		if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			pole.add(Stringk);
			return pole;
		} 
		else {
			for (Zaznam i : zoznam) {
				Stringk = ("Meno: " + i.getMenoZ() + "\nTyp poistenia: " + i.getTyppoistenia() + "\nV�platn� suma: " + i.getSuma() + "\n");
				pole.add(Stringk);
			}
			return pole;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na nastavenie hodnoty poistn�ho plnenia v z�zname o poistnej udalosti ur�it�ho klienta.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @param suma Hodnota poistn�ho plnenia.
	 * @return hodnota 0 a� 5 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int nastavenieSumy(ArrayList<Zaznam> zoznam, String meno, double suma) {
		if (meno.equals("")) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			return 1;
		} 
		else {
			int x = 0;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu z�znamov.
				if (!(meno.equals(i.getMenoZ()))) {
					x++;
					if (x == zoznam.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return 2;
					}
				} 
				else {
					if ((suma < 500) && (suma >= 0)) { // Ak je hodnota poistn�ho plnenia v tomto rozp�t� nastav� sa aj schv�lenos� na "schv�len�".
						i.setSuma(suma);
						i.setSchvalenost(true);
						return 3;
					}
					else if (suma < 0){
						i.setSuma(suma);
						return 4;
					}
					else {
						i.setSuma(suma);
						i.setSchvalenost(false);
						return 5;
					}
				}
			}
			return 0;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na nastavenie typu poistenia ur�it�ho klienta.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @param q hodnota 0 a� 9 pod�a v�beru.
	 * @return hodnota 0 a� 3 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int nastavenieTypuPoistenia(ArrayList<Zaznam> zoznam, String meno, int q) {
		if (meno.equals("")) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			return 1;
		}
		else {
			int x = 0;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu z�znamov.
				if (!(meno.equals(i.getMenoZ()))) {
					x++;
					if (x == zoznam.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return 2;
					}
				} 
				else { // Nastavovanie typu poistenia pod�a prednastaven�ch.
					switch (q) {
					case 0:
						i.setTyppoistenia("poistenie z�ujmu");
						return 3;
					case 1:
						i.setTyppoistenia("poistenie os�b");
						return 3;
					case 2:
						i.setTyppoistenia("poistenie majetku");
						return 3;
					case 3:
						i.setTyppoistenia("�ivotn�");
						return 3;
					case 4:
						i.setTyppoistenia("rizikov�");
						return 3;
					case 5:
						i.setTyppoistenia("z�konn�");
						return 3;
					case 6:
						i.setTyppoistenia("povinn� zmluvn�");
						return 3;
					case 7:
						i.setTyppoistenia("dobrovo�n� zmluvn�");
						return 3;
					case 8:
						i.setTyppoistenia("kr�tkodob�");
						return 3;
					case 9:
						i.setTyppoistenia("dlhodob�");
						return 3;
					}
				break;
				}
			}
			return 0;
		}
	}
}