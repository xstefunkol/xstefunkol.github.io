package model;

import java.util.ArrayList; // Import potrebn�ch bal�kov.

/**
 * Trieda ReferentSpravyPoistenia ded� od triedy RegistrovanaOsoba a reprezentuje pou��vate�a s opr�vnen�m Referent spr�vy poistenia s jeho funkciami v aplik�cii.
 */
public class ReferentSpravyPoistenia extends RegistrovanaOsoba {
	
	public ReferentSpravyPoistenia() { // Kon�truktor triedy ReferentSpravyPoistenia.
		
	}

	public ReferentSpravyPoistenia(String meno, String heslo) { // Pre�a�uj�ci kon�truktor triedy ReferentSpravyPoistenia, nastavenie mena, hesla a opr�vnenia nadtriedy, druh polymorfizmu.
		super(meno, heslo, "Referent spr�vy poistenia"); // Volanie prekonan�ho kon�truktora triedy RegistrovanaOsoba.
	}
	
	/* (non-Javadoc)
	 * @see model.RegistrovanaOsoba#funkciaVypisuBossov(java.util.ArrayList)
	 */
	public ArrayList<String> funkciaVypisuBossov(ArrayList<RegistrovanaOsoba> osoby) {
		return super.funkciaVypisuBossov(osoby); // Volanie prekonanej met�dy triedy RegistrovanaOsoba.
	}
	
	/**
	 * Met�da, ktor� sl��i na vyh�adanie z�znamov o poistn�ch udalostiach - meno, vyplatenos� poistn�ho plnenia a platnosti z�znamu.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @return ur�it� �daje v�etk�ch z�znamov alebo string "0" pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static ArrayList<String> vypisanieZaznamuReferent(ArrayList<Zaznam> zoznam) {
		String Stringk = "0";
		ArrayList<String> pole = new ArrayList<>();
		if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			pole.add(Stringk);
			return pole;
		} 
		else {
			String z;
			String k;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu z�znamov.
				if (i.isVyplatenost() == false) z = ("nevyplaten�"); // Nastavenie v�pisu.
				else z = ("vyplaten�");
				if (i.isPlatnost() == false) k = ("neplatn�");
				else k = ("platn�");
				Stringk = ("Meno: " + i.getMenoZ() + "\nVyplatenos� sumy: " + z + "\nPlatnos� z�znamu o poistnej udalosti: " + k + "\n");
				pole.add(Stringk);
			}
			return pole;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na nastavenie platnosti z�znamu o poistnej udalosti ur�it�ho klienta.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @param q hodnota 0 a� 1 pod�a v�beru platnosti.
	 * @return hodnota 0 a� 4 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int nastaveniePlatnosti(ArrayList<Zaznam> zoznam, String meno, int q) {
		if (meno.equals("")) return 4; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			return 0;
		} 
		else {
			int x = 0;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu z�znamov.
				if (!(meno.equals(i.getMenoZ()))) {
					x++;
					if (x == zoznam.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return 1;
					}
				} 
				else { // Nastavovanie platnosti.
					switch (q) {
					case 1:
						i.setPlatnost(true); // Platnos� z�znamu dan�ho klienta je platn�.
						return 2;
					case 0:
						i.setPlatnost(false); // Platnos� z�znamu dan�ho klienta je neplatn�.
						i.setSchvalenost(false);
						i.setVyplatenost(false);
						i.setSuma(0);
						return 3;
					}
					break;
				}
			}
			return 0;
		}
	}
	
	/**
	 * Met�da, ktor� sl��i na nastavenie vyplatenosti poistn�ho plnenia ur�it�ho klienta.
	 * @param zoznam Zoznam z�znamov o poistn�ch udalostiach v programe.
	 * @param meno Meno klienta.
	 * @param q hodnota 0 a� 1 pod�a v�beru vyplatenosti.
	 * @return hodnota 0 a� 6 pre zabezpe�enie potrebn�ch v�pisov.
	 */
	public static int nastavenieVyplatenosti(ArrayList<Zaznam> zoznam, String meno, int q) {
		if (meno.equals("")) return 0; // O�etrenie mo�nosti nezadan�ho parametra.
		else if ((zoznam.isEmpty()) == true) { // O�etrenie pr�padu pr�zdneho zoznamu z�znamov.
			return 1;
		} 
		else {
			int x = 0;
			for (Zaznam i : zoznam) { // Preh�ad�vanie zoznamu z�znamov.
				if (!(meno.equals(i.getMenoZ()))) {
					x++;
					if (x == zoznam.size()) { // Ke� sa hodnota v po��tadle rovn� po�tu z�znamov v zozname znamen� to, �e z�znam toho klienta neexistuje.
						return 2;
					}
				} 
				else { // Nastavovanie vyplatenosti.
					switch (q) {
					case 1:
						if (i.isPlatnost() == true) {
							if (i.isSchvalenost() == true) { // Ak je z�znam platn� a z�rove� je schv�len� tak sa nastav� vyplatenos� na "vyplaten�".
								i.setVyplatenost(true);
								return 3;
							}
							else { // Ak nie je z�znam schv�len�, mus� sa da� schv�li� najsk�r.
								return 4;
							}
						}
						else { // Ak nie je platn� mus� sa nastavi� na platn� referentom.
							return 5;
						}
					case 0: // Nastavenie nevyplatenosti.
						if (i.isPlatnost() == true) {
							if (i.isSchvalenost() == true) {
								i.setVyplatenost(false);
								return 6;
							}
							else {
								return 4;
							}
						}
						else {
							return 5;
						}
					}
					break;
				}
			}
			return 0;
		}
	}
}