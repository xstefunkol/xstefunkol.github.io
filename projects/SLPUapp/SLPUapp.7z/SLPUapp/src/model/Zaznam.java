package model;

/**
 * Trieda Zaznam reprezentuje z�znam o poistnej udalosti a jeho �daje.
 */
public class Zaznam { // Zadefinovanie atrib�tov triedy Zaznam.
	private String meno;
	private String miesto;
	private int rok;
	private int mesiac;
	private int den;
	private String email;
	private String adresa;
	private String typpoistenia;
	private boolean schvalenost = false;
	private double suma = 0;
	private boolean vyplatenost = false;
	private boolean platnost = true;

	public Zaznam() { // Kon�truktor triedy Zaznam

	}

	public Zaznam(String meno, String miesto, int rok, int mesiac, int den, String typpoistenia, String email, String adresa, boolean schvalenost, double suma, boolean vyplatenost, boolean platnost) { // Pre�a�uj�ci kon�truktor triedy Zaznam, druh polymorfizmu.
		this.meno = meno;
		this.miesto = miesto;
		this.den = den;
		this.mesiac = mesiac;
		this.rok = rok;
		this.typpoistenia = typpoistenia;
		this.email = email;
		this.adresa = adresa;
		this.schvalenost = schvalenost;
		this.suma = suma;
		this.vyplatenost = vyplatenost;
		this.platnost = platnost;
	}
	
	/** Z�skavanie a nastavovanie �dajov v z�zname pou�it�m getterov a setterov - pou�it� zapuzdrenie. */
	public String getMenoZ() {
		return meno;
	}
	
	public void setMenoZ(String meno) {
		this.meno = meno;
	}

	public String getMiesto() {
		return miesto;
	}

	public void setMiesto(String miesto) {
		this.miesto = miesto;
	}

	public String getTyppoistenia() {
		return typpoistenia;
	}

	public void setTyppoistenia(String typpoistenia) {
		this.typpoistenia = typpoistenia;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAdresa() {
		return adresa;
	}

	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}

	public boolean isSchvalenost() {
		return schvalenost;
	}

	public void setSchvalenost(boolean schvalenost) {
		this.schvalenost = schvalenost;
	}

	public double getSuma() {
		return suma;
	}

	public void setSuma(double suma) {
		if (suma < 0) { // Podmienka pre nastavenie kladnej sumy.
			this.suma = 0;
		}
		else {
			this.suma = suma;
		}
	}

	public boolean isVyplatenost() {
		return vyplatenost;
	}

	public void setVyplatenost(boolean vyplatenost) {
		this.vyplatenost = vyplatenost;
	}

	public boolean isPlatnost() {
		return platnost;
	}

	public void setPlatnost(boolean platnost) {
		this.platnost = platnost;
	}
	
	public int getDen() {
		return den;
	}

	public int setDen(int den) { // Podmienky pre nastavenie spr�vneho d�a pod�a mesiaca, roku a o�etrenie z�porn�ho vstupu.
		if (((this.mesiac == 1) || (this.mesiac == 3) || (this.mesiac == 5) || (this.mesiac == 7) || (this.mesiac == 8) || (this.mesiac == 10) || (this.mesiac == 12)) && ((den > 31) || (den < 1))) {
			this.den = 1;
			return 0;
		} 
		else if (((this.mesiac == 4) || (this.mesiac == 6) || (this.mesiac == 9) || (this.mesiac == 11)) && ((den > 30) || (den < 1))) {
			this.den = 1;
			return 0;
		} 
		else if (((this.mesiac == 2) && ((den > 28) || (den < 1))) || ((this.mesiac == 2) && (this.rok % 4 == 0) && ((den > 29) || (den < 1)))) {
			this.den = 1;
			return 0;
		} 
		else {
			this.den = den;
			return 1;
		}
	}

	public int getMesiac() {
		return mesiac;
	}

	public void setMesiac(int mesiac) { // Podmienka pre nastavenie spr�vneho mesiaca a o�etrenie z�porn�ho vstupu.
		if ((mesiac < 1) || (mesiac > 12)) {
			this.mesiac = 1;
		} 
		else
			this.mesiac = mesiac;
	}

	public int getRok() {
		return rok;
	}

	public void setRok(int rok) {
		if ((rok < 2010) || (rok > 2014)) { // Podmienka pre nastavenie spr�vneho roku (max 4 roky star� z�znam)
			this.rok = 2010;
		} 
		else
			this.rok = rok;
	}
}