package view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Trieda HlavnyLikvidatorV reprezentuje okno(view), ktor� sa zobraz� po �spe�nom prihl�sen� sa za Hlavn�ho likvid�tora.
 */
@SuppressWarnings("serial")
public class HlavnyLikvidatorV extends JFrame { // Zadefinovanie komponentov.
	private JLabel LmenoHL = new JLabel("Zadajte meno");
	private JLabel LhesloHL = new JLabel("Zadajte heslo");
	private JLabel LhodnotaHL = new JLabel("Zadajte v�platn� sumu");
	private JLabel LrozhodHL = new JLabel("Vyberte typ poistenia");
	private JLabel LrozhodschvalHL = new JLabel("Vyberte schv�lenos�");
	private JButton vypisHL = new JButton("V�pis z�znamov");
	private JButton regHL = new JButton("Zaregistrovanie likvid�tora");
	private JButton zmazHL = new JButton("Prepustenie likvid�tora");
	private JButton schvalenostHL = new JButton("Nastavenie schv�lenosti");
	private JButton sumaHL = new JButton("Nastavenie v�platnej sumy");
	private JButton typpoisteniaHL = new JButton("Nastavenie typu poistenia");
	private JButton bossHL = new JButton("V�pis administr�torov");
	private JButton odhlasenieHL = new JButton("Odhl�si�");
	private JButton vycistiHL = new JButton("Clear");
	private JTextField menoHL = new JTextField();
	private JPasswordField hesloHL = new JPasswordField();
	private JTextField hodnotaHL = new JTextField();
	private String[] rozhodnutieHL = { "poistenie z�ujmu", "poistenie os�b", "poistenie majetku", "�ivotn�", "rizikov�", "z�konn�", "povinn� zmluvn�", "dobrovo�n� zmluvn�", "kr�tkodob�", "dlhodob�" };
	private JComboBox<String> rozhodHL = new JComboBox<String>(rozhodnutieHL);
	private String[] rozhodschHL = { "neschv�len�", "schv�len�" };
	private JComboBox<String> rozhodschvalHL = new JComboBox<String>(rozhodschHL);
	private JTextArea textaHL = new JTextArea();
	private JScrollPane scrollaHL = new JScrollPane(textaHL);

	public HlavnyLikvidatorV() { // Kon�truktor triedy HlavnyLikvidatorV
		setTitle("SLPUapp - 1.0");
		setSize(1100, 600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		hlavnylikvidatorGUI();
	}
	
	/**
	 * Met�da, ktor� sl��i na pridanie potrebn�ch komponentov do okna.
	 */
	public final void hlavnylikvidatorGUI() {
		JPanel hlavnylikvidatorPanel = new JPanel();
		add(hlavnylikvidatorPanel);
		hlavnylikvidatorPanel.setLayout(new BorderLayout());
		
		Box opravnenieHL = Box.createHorizontalBox(); // Vytvorenie 5 priestorov, do ktor�ch s� ukladan� komponenty.
		Box tlacitkaHL = Box.createVerticalBox();
		Box vlozeniaHL = Box.createVerticalBox();
		Box textHL = Box.createHorizontalBox();
		Box legendaHL = Box.createHorizontalBox();
		
		add(opravnenieHL, BorderLayout.NORTH); // Ich rozdelenie v BorderLayout
		add(tlacitkaHL, BorderLayout.WEST);
		add(vlozeniaHL, BorderLayout.CENTER);
		add(textHL, BorderLayout.EAST);
		add(legendaHL, BorderLayout.SOUTH);

		opravnenieHL.add(Box.createVerticalStrut(10));
		opravnenieHL.add(new JLabel("Hlavn� likvid�tor"));
		opravnenieHL.add(Box.createVerticalStrut(10));
		
		vypisHL.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		regHL.setAlignmentX(CENTER_ALIGNMENT);
		zmazHL.setAlignmentX(CENTER_ALIGNMENT);
		schvalenostHL.setAlignmentX(CENTER_ALIGNMENT);
		sumaHL.setAlignmentX(CENTER_ALIGNMENT);
		typpoisteniaHL.setAlignmentX(CENTER_ALIGNMENT);
		bossHL.setAlignmentX(CENTER_ALIGNMENT);
		vycistiHL.setAlignmentX(CENTER_ALIGNMENT);
		odhlasenieHL.setAlignmentX(CENTER_ALIGNMENT);

		tlacitkaHL.add(Box.createVerticalGlue()); // Prid�vanie komponentov do Boxu.
		tlacitkaHL.add(vypisHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.add(regHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.add(zmazHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.add(schvalenostHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.add(sumaHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.add(typpoisteniaHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.add(bossHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.add(vycistiHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.add(odhlasenieHL);
		tlacitkaHL.add(Box.createVerticalGlue());
		tlacitkaHL.setBorder(BorderFactory.createTitledBorder("Mo�nosti"));
		
		menoHL.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		hesloHL.setAlignmentX(CENTER_ALIGNMENT);
		hodnotaHL.setAlignmentX(CENTER_ALIGNMENT);
		rozhodHL.setAlignmentX(CENTER_ALIGNMENT);
		rozhodschvalHL.setAlignmentX(CENTER_ALIGNMENT);
		LmenoHL.setAlignmentX(CENTER_ALIGNMENT);
		LhesloHL.setAlignmentX(CENTER_ALIGNMENT);
		LhodnotaHL.setAlignmentX(CENTER_ALIGNMENT);
		LrozhodHL.setAlignmentX(CENTER_ALIGNMENT);
		LrozhodschvalHL.setAlignmentX(CENTER_ALIGNMENT);
		
		vlozeniaHL.add(Box.createVerticalStrut(10)); // Prid�vanie komponentov do Boxu.
		vlozeniaHL.add(LmenoHL);
		vlozeniaHL.add(menoHL);
		vlozeniaHL.add(Box.createVerticalStrut(25));
		vlozeniaHL.add(LhesloHL);
		vlozeniaHL.add(hesloHL);
		vlozeniaHL.add(Box.createVerticalStrut(25));
		vlozeniaHL.add(LhodnotaHL);
		vlozeniaHL.add(hodnotaHL);
		vlozeniaHL.add(Box.createVerticalStrut(25));
		vlozeniaHL.add(LrozhodHL);
		vlozeniaHL.add(rozhodHL);
		vlozeniaHL.add(Box.createVerticalStrut(25));
		vlozeniaHL.add(LrozhodschvalHL);
		vlozeniaHL.add(rozhodschvalHL);
		vlozeniaHL.add(Box.createVerticalStrut(280));
		vlozeniaHL.setBorder(BorderFactory.createTitledBorder("Vlo�enie �dajov"));
		
		textaHL.setFont(new Font("Times New Roman", Font.BOLD, 15)); // Nastavenie p�sma v TextArea
		textaHL.setEditable(false);
		scrollaHL.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollaHL.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollaHL.setPreferredSize(new Dimension(650,0));
		textHL.add(scrollaHL);
		textHL.setBorder(BorderFactory.createTitledBorder("V�pis"));
		
		legendaHL.add(new JLabel("Legenda: nast. v�platnej sumy(meno, suma), nast. typu poistenia(meno, typpoistenia), reg. likvid�tora(meno, heslo), nast. schv�lenosti(meno, schvalenos�), prepust. likvid�tora(meno)"));
	}
	
	/**
	 * Met�dy na pridanie funkcie tla�idlu - vyu��van� v controller bal�ku.
	 */
	public void addVypisZaznamovHLListener(ActionListener listenForVypisZaznamovHL) {
		vypisHL.addActionListener(listenForVypisZaznamovHL);
	}
	
	public void addRegistrujLikvidatoraHLListener(ActionListener listenForRegistrujLikvidatoraHL) {
		regHL.addActionListener(listenForRegistrujLikvidatoraHL);
	}
	
	public void addPrepustiLikvidatoraHLListener(ActionListener listenForPrepustiLikvidatoraHL) {
		zmazHL.addActionListener(listenForPrepustiLikvidatoraHL);
	}
	
	public void addNastavSchvalHLListener(ActionListener listenForNastavSchvalHL) {
		schvalenostHL.addActionListener(listenForNastavSchvalHL);
	}
	
	public void addNastavenieSumyHLListener(ActionListener listenForNastavenieSumyHL) {
		sumaHL.addActionListener(listenForNastavenieSumyHL);
	}
	
	public void addNastaveniePoistHLListener(ActionListener listenForNastaveniePoistHL) {
		typpoisteniaHL.addActionListener(listenForNastaveniePoistHL);
	}
	
	public void addVypisAdminovHLListener(ActionListener listenForVypisAdminovHL) {
		bossHL.addActionListener(listenForVypisAdminovHL);
	}
	
	public void addVycistiHLListener(ActionListener listenForVycistiHL) {
		vycistiHL.addActionListener(listenForVycistiHL);
	}
	
	public void addOdhlasitHLListener(ActionListener listenForOdhlasitHL) {
		odhlasenieHL.addActionListener(listenForOdhlasitHL);
	}
	
	/**
	 * Met�dy na vypisovanie v�stra�n�ch alebo informa�n�ch spr�v.
	 */
	public void neexistujucaOsobaHLError() {
		textaHL.append("Zoznam registrovan�ch os�b je pr�zdny!\n\n");
	}
	
	public void nezadanyParameterHLError() {
		textaHL.append("Nezadali ste niektor� z �dajov!\n\n");
	}
	
	public void neexistujuciZoznamHLError() {
		textaHL.append("Zoznam z�znamov o poistn�ch udalostiach je pr�zdny!\n\n");
	}
	
	public void neexistujuciAdminHLError() {
		textaHL.append("Nie je zaregistrovan� �iadny Administr�tor!\n\n");
	}
	
	public void neexistujuciZaznamHLError() {
		textaHL.append("Z�znam o poistnej udalosti tohto klienta nie je vytvoren�!\n\n");
	}
	
	public void aktualizovanyZaznamSHL() {
		textaHL.append("Z�znam bol aktualizovan� a hodnota poistn�ho plnenia bola schv�len�.\n\n");
	}
	
	public void aktualizovanyZaznamSHLError() {
		textaHL.append("Z�znam bol aktualizovan�, ale hodnota poistn�ho plnenia nebola schv�len� - nastavte schv�lenos�!\n\n");
	}
	
	public void aktualizovanyZaznamTPHL() {
		textaHL.append("Z�znam bol aktualizovan� a typ poistenia zmenen�.\n\n");
	}
	
	public void aktualizovanyZaznamS0HL() {
		textaHL.append("Z�znam bol aktualizovan� a schv�lenos� hodnoty poistn�ho plnenia bola nastaven� na \"neschv�len�\" => vyplatenos� bola nastaven� na \"nevyplaten�\" a hodnota poistn�ho plnenia bola nastaven� na 0.\n\n");
	}
	
	public void aktualizovanyZaznamS1HL() {
		textaHL.append("Z�znam bol aktualizovan� a schv�lenos� hodnoty poistn�ho plnenia bola nastaven� na \"schv�len�\".\n\n");
	}
	
	public void nekorektnaSumaHLError() {
		textaHL.append("Z�znam bol aktualizovan�, ale nekorektne ste zadali hodnotu poistn�ho plnenia! - Automatick� nastavenie - 0!\n\n");
	}
	
	public void uspesnaRegHL() {
		textaHL.append("Registr�cia prebehla �spe�ne.\n\n");
	}
	
	public void zhodneMenaHLError() {
		textaHL.append("Pou��vate� s tak�m menom u� existuje!\n\n");
	}
	
	public void nezhodneMenaHLError() {
		textaHL.append("Nikto s tak�m menom nie je registrovan�!\n\n");
	}
	
	public void prepustenyLikvidatorHL() {
		textaHL.append("Likvid�tor bol prepusten�.\n\n");
	}
	
	public void inyTypOpravneniaHLError() {
		textaHL.append("Osoba s tak�m menom je zaregistrovan�, ale m� in� typ opr�vnenia, nem��e by� prepusten�!\n\n");
	}
	
	public void vypisuj(String vypis) {
		textaHL.append(vypis + "\n");
	}
	
	public void vycisti() {
		textaHL.setText("");
	}
	
	/**
	 * Getter met�dy na z�skanie textu z textfieldov a z�skanie indexu z comboboxu.
	 */
	public String getMenoHL() {
		return menoHL.getText();
	}
	
	@SuppressWarnings("deprecation")
	public String getHesloHL() {
		return hesloHL.getText();
	}
	
	public int getRozhodnutieTPHL() {
		return rozhodHL.getSelectedIndex();
	}
	
	public int getRozhodnutieSCHHL() {
		return rozhodschvalHL.getSelectedIndex();
	}
	
	public String getSumaHL() {
		return hodnotaHL.getText();
	}
}