package view;

import java.awt.event.*;

import javax.swing.*;

/**
 * Trieda Prihlasenie reprezentuje okno(view), ktor� sa zobraz� po stla�en� tla�idla Prihl�senie.
 */
@SuppressWarnings("serial")
public class Prihlasenie extends JFrame { // Zadefinovanie komponentov.
	private String[] permissionsP = { "Klient", "Administr�tor", "Likvid�tor", "Hlavn� likvid�tor", "Referent spr�vy poistenia" };
	private JLabel loginlP = new JLabel("Meno: ");
	private JLabel passlP = new JLabel("Heslo: ");
	private JTextField loginP = new JTextField();
	private JPasswordField passP = new JPasswordField();
	private JButton prihlasenieP = new JButton("Prihl�si�");
	private JComboBox<String> permP = new JComboBox<String>(permissionsP);
	private JLabel permlP = new JLabel("Opr�vnenie: ");
	private JButton backP = new JButton("Sp�");
	
	public Prihlasenie() { // Kon�truktor triedy Prihlasenie
		setTitle("SLPUapp - 1.0");
		setSize(450, 250);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		prihlasenieGUI();
	}

	/**
	 * Met�da, ktor� sl��i na pridanie potrebn�ch komponentov do okna.
	 */
	public final void prihlasenieGUI() {
		JPanel panel = new JPanel();
		add(panel);
		panel.setLayout(null);

		loginlP.setBounds(20, 20, 80, 30);  // Pevn� nastavenie rozmiestnenia komponentov.
		passlP.setBounds(20, 60, 80, 30);
		loginP.setBounds(100, 20, 180, 30);
		passP.setBounds(100, 60, 180, 30);
		prihlasenieP.setBounds(320, 40, 100, 30);
		permP.setBounds(100, 100, 180, 30);
		permlP.setBounds(20, 100, 80, 30);
		backP.setBounds(320, 170, 100, 30);
			
		panel.add(prihlasenieP); // Prid�vanie komponentov.
		panel.add(backP);
		panel.add(loginP);
		panel.add(passP);
		panel.add(loginlP);
		panel.add(passlP);
		panel.add(permP);
		panel.add(permlP);
	}
	
	/**
	 * Met�dy na pridanie funkcie tla�idlu - vyu��van� v controller bal�ku.
	 */
	public void addPrihlaseniePListener(ActionListener listenForPrihlasenieP) {
		prihlasenieP.addActionListener(listenForPrihlasenieP);
	}
	
	public void addBackPListener(ActionListener listenForBackP) {
		backP.addActionListener(listenForBackP);
	}
	
	/**
	 * Getter met�dy na z�skanie textu z textfieldu, passwordfieldu a comboboxu.
	 */
	public String getMenoP() {
		return loginP.getText();
	}

	@SuppressWarnings("deprecation")
	public String getHesloP() {
		return passP.getText();
	}
	
	public String getOpravnenieP() {
		return (String) permP.getSelectedItem();
	}
	
	/**
	 * Met�dy na vypisovanie v�stra�n�ch spr�v.
	 */
	public void neplatneMenoPError() {
		JOptionPane.showMessageDialog(this, "Zadali ste neplatn� pou��vate�sk� meno!");
	}
	
	public void neplatneHesloPError() {
		JOptionPane.showMessageDialog(this, "Zadali ste neplatn� pou��vate�sk� heslo!");
	}
	
	public void nedostatokParametrovPError() {
		JOptionPane.showMessageDialog(this, "Nezadali ste meno alebo heslo!");
	}
	
	public void neplatneOpravneniePError() {
		JOptionPane.showMessageDialog(this, "Zadali ste neplatn� pou��vate�sk� opr�vnenie!");
	}
}