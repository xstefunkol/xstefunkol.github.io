package view;

import java.awt.event.*;

import javax.swing.*;

/**
 * Trieda RegistrovanieKlienta reprezentuje okno(view), ktor� sa zobraz� po stla�en� tla�idla Registr�cia klienta.
 */
@SuppressWarnings("serial")
public class RegistrovanieKlienta extends JFrame {
	JLabel loginlRK = new JLabel("Meno: ");  // Zadefinovanie tla��tok, n�zvov a textov�ch pol�.
	JLabel passlRK = new JLabel("Heslo: ");
	JTextField loginRK = new JTextField();
	JPasswordField passRK = new JPasswordField();
	JButton registrovatRK = new JButton("Registrova�");
	JButton backRK = new JButton("Sp�");

	public RegistrovanieKlienta() { // Kon�truktor triedy RegistrovanieKlienta.
		setTitle("SLPUapp - 1.0");
		setSize(450, 200);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		registrovanieGUI();
	}

	/**
	 * Met�da, ktor� sl��i na pridanie potrebn�ch komponentov do okna.
	 */
	public final void registrovanieGUI() {
		JPanel panel = new JPanel();
		add(panel);
		panel.setLayout(null);

		loginlRK.setBounds(20, 20, 80, 30); // Pevn� nastavenie rozmiestnenia komponentov.
		passlRK.setBounds(20, 60, 80, 30);
		loginRK.setBounds(80, 20, 180, 30);
		passRK.setBounds(80, 60, 180, 30);
		registrovatRK.setBounds(300, 40, 120, 30);
		backRK.setBounds(300, 120, 120, 30);

		panel.add(registrovatRK); // Prid�vanie komponentov.
		panel.add(backRK);
		panel.add(loginRK);
		panel.add(passRK);
		panel.add(loginlRK);
		panel.add(passlRK);
	}
	
	/**
	 * Met�dy na pridanie funkcie tla�idlu - vyu��van� v controller bal�ku.
	 */
	public void addRegistrovatRKListener(ActionListener listenForRegistrovatRK) {
		registrovatRK.addActionListener(listenForRegistrovatRK);
	}
	
	public void addBackRKListener(ActionListener listenForBackRK) {
		backRK.addActionListener(listenForBackRK);
	}
	
	/**
	 * Getter met�dy na z�skanie textu z textfieldu a passwordfieldu.
	 */
	public String getMenoRK() {
		return loginRK.getText();
	}

	@SuppressWarnings("deprecation")
	public String getHesloRK() {
		return passRK.getText();
	}
	
	/**
	 * Zobrazenie spr�vy o �spe�nej registr�cii.
	 */
	public void uspesnaRegistracia() {
		JOptionPane.showMessageDialog(this, "Registr�cia prebehla �spe�ne.");
	}
	
	/**
	 * Zobrazenie v�stra�nej spr�vy.
	 */
	public void zhodneMenaError() {
		JOptionPane.showMessageDialog(this, "Pou��vate� s tak�m menom u� existuje!");
	}
	
	/**
	 * Zobrazenie v�stra�nej spr�vy.
	 */
	public void nedostatokParametrovRKError() {
		JOptionPane.showMessageDialog(this, "Nezadali ste meno alebo heslo!");
	}
}