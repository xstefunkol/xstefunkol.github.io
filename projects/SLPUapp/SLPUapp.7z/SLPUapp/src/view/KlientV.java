package view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Trieda KlientV reprezentuje okno(view), ktor� sa zobraz� po �spe�nom prihl�sen� sa za Klienta.
 */
@SuppressWarnings("serial")
public class KlientV extends JFrame { // Zadefinovanie komponentov.
	private JLabel LmiestoK = new JLabel("Zadajte miesto");
	private JLabel LrokK = new JLabel("Vyberte rok");
	private JLabel LmesiacK = new JLabel("Vyberte mesiac");
	private JLabel LdenK = new JLabel("Vyberte de�");
	private JLabel LemailK = new JLabel("Zadajte email");
	private JLabel LadresaK = new JLabel("Zadajte adresu");
	private JButton vypisK = new JButton("V�pis z�znamu");
	private JButton zmazanieK = new JButton("Zmazanie z�znamu");
	private JButton vytvorenieK = new JButton("Vytvorenie z�znamu");
	private JButton bossK = new JButton("V�pis administr�torov");
	private JButton odhlasenieK = new JButton("Odhl�si�");
	private JButton vycistiK = new JButton("Clear");
	private JTextField miestoK = new JTextField();
	private String[] rokyK = { "2010", "2011", "2012", "2013", "2014" };
	private JComboBox<String> rokK = new JComboBox<String>(rokyK);
	private String[] mesiaceK = { "Janu�r", "Febru�r", "Marec", "Apr�l", "M�j", "J�n", "J�l", "August", "September", "Okt�ber", "November", "December" };
	private JComboBox<String> mesiacK = new JComboBox<String>(mesiaceK);
	private String[] dniK = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };
	private JComboBox<String> denK = new JComboBox<String>(dniK);
	private JTextField emailK = new JTextField();
	private JTextField adresaK = new JTextField();
	private JTextArea textaK = new JTextArea();
	private JScrollPane scrollaK = new JScrollPane(textaK);

	public KlientV() { // Kon�truktor triedy KlientV
		setTitle("SLPUapp - 1.0");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		klientGUI();
	}
	
	/**
	 * Met�da, ktor� sl��i na pridanie potrebn�ch komponentov do okna.
	 */
	public final void klientGUI() {
		JPanel klientPanel = new JPanel();
		add(klientPanel);
		klientPanel.setLayout(new BorderLayout());
		
		Box opravnenieK = Box.createHorizontalBox(); // Vytvorenie 5 priestorov, do ktor�ch s� ukladan� komponenty.
		Box tlacitkaK = Box.createVerticalBox();
		Box vlozeniaK = Box.createVerticalBox();
		Box textK = Box.createHorizontalBox();
		Box legendaK = Box.createHorizontalBox();
		
		add(opravnenieK, BorderLayout.NORTH); // Ich rozdelenie v BorderLayout
		add(tlacitkaK, BorderLayout.WEST);
		add(vlozeniaK, BorderLayout.CENTER);
		add(textK, BorderLayout.EAST);
		add(legendaK, BorderLayout.SOUTH);

		opravnenieK.add(Box.createVerticalStrut(10));
		opravnenieK.add(new JLabel("Klient"));
		opravnenieK.add(Box.createVerticalStrut(10));
		
		vypisK.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		zmazanieK.setAlignmentX(CENTER_ALIGNMENT);
		vytvorenieK.setAlignmentX(CENTER_ALIGNMENT);
		bossK.setAlignmentX(CENTER_ALIGNMENT);
		vycistiK.setAlignmentX(CENTER_ALIGNMENT);
		odhlasenieK.setAlignmentX(CENTER_ALIGNMENT);

		tlacitkaK.add(Box.createVerticalGlue()); // Prid�vanie komponentov do Boxu.
		tlacitkaK.add(vypisK);
		tlacitkaK.add(Box.createVerticalGlue());
		tlacitkaK.add(zmazanieK);
		tlacitkaK.add(Box.createVerticalGlue());
		tlacitkaK.add(vytvorenieK);
		tlacitkaK.add(Box.createVerticalGlue());
		tlacitkaK.add(bossK);
		tlacitkaK.add(Box.createVerticalGlue());
		tlacitkaK.add(vycistiK);
		tlacitkaK.add(Box.createVerticalGlue());
		tlacitkaK.add(odhlasenieK);
		tlacitkaK.add(Box.createVerticalGlue());
		tlacitkaK.setBorder(BorderFactory.createTitledBorder("Mo�nosti"));
		
		miestoK.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		rokK.setAlignmentX(CENTER_ALIGNMENT);
		mesiacK.setAlignmentX(CENTER_ALIGNMENT);
		denK.setAlignmentX(CENTER_ALIGNMENT);
		emailK.setAlignmentX(CENTER_ALIGNMENT);
		adresaK.setAlignmentX(CENTER_ALIGNMENT);
		LmiestoK.setAlignmentX(CENTER_ALIGNMENT);
		LrokK.setAlignmentX(CENTER_ALIGNMENT);
		LmesiacK.setAlignmentX(CENTER_ALIGNMENT);
		LdenK.setAlignmentX(CENTER_ALIGNMENT);
		LemailK.setAlignmentX(CENTER_ALIGNMENT);
		LadresaK.setAlignmentX(CENTER_ALIGNMENT);
		
		vlozeniaK.add(Box.createVerticalStrut(10)); // Prid�vanie komponentov do Boxu.
		vlozeniaK.add(LmiestoK);
		vlozeniaK.add(miestoK);
		vlozeniaK.add(Box.createVerticalStrut(20));
		vlozeniaK.add(LrokK);
		vlozeniaK.add(rokK);
		vlozeniaK.add(Box.createVerticalStrut(20));
		vlozeniaK.add(LmesiacK);
		vlozeniaK.add(mesiacK);
		vlozeniaK.add(Box.createVerticalStrut(20));
		vlozeniaK.add(LdenK);
		vlozeniaK.add(denK);
		vlozeniaK.add(Box.createVerticalStrut(20));
		vlozeniaK.add(LemailK);
		vlozeniaK.add(emailK);
		vlozeniaK.add(Box.createVerticalStrut(20));
		vlozeniaK.add(LadresaK);
		vlozeniaK.add(adresaK);
		vlozeniaK.add(Box.createVerticalStrut(160));
		vlozeniaK.setBorder(BorderFactory.createTitledBorder("Vlo�enie �dajov"));
		
		textaK.setFont(new Font("Times New Roman", Font.BOLD, 15)); // Nastavenie p�sma v TextArea
		textaK.setEditable(false);
		scrollaK.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollaK.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollaK.setPreferredSize(new Dimension(600,0));
		textK.add(scrollaK);
		textK.setBorder(BorderFactory.createTitledBorder("V�pis"));
		
		legendaK.add(new JLabel("Legenda: vytv. z�znamu(miesto, rok, mesiac, den, email, adresa)"));
	}
	
	/**
	 * Met�dy na pridanie funkcie tla�idlu - vyu��van� v controller bal�ku.
	 */
	public void addVypisZaznamuKListener(ActionListener listenForVypisZaznamuK) {
		vypisK.addActionListener(listenForVypisZaznamuK);
	}
	
	public void addZmazanieZaznamuKListener(ActionListener listenForZmazanieZaznamuK) {
		zmazanieK.addActionListener(listenForZmazanieZaznamuK);
	}
	
	public void addVytvorenieZaznamuKListener(ActionListener listenForVytvorenieZaznamuK) {
		vytvorenieK.addActionListener(listenForVytvorenieZaznamuK);
	}
	
	public void addVypisAdminovKListener(ActionListener listenForVypisAdminovK) {
		bossK.addActionListener(listenForVypisAdminovK);
	}
	
	public void addVycistiKListener(ActionListener listenForVycistiK) {
		vycistiK.addActionListener(listenForVycistiK);
	}
	
	public void addOdhlasitKListener(ActionListener listenForOdhlasitK) {
		odhlasenieK.addActionListener(listenForOdhlasitK);
	}
	
	/**
	 * Met�dy na vypisovanie v�stra�n�ch alebo informa�n�ch spr�v.
	 */
	public void nezadanyParameterKError() {
		textaK.append("Niektor� z �dajov nebol zadan�!\n\n");
	}
	
	public void neexistujucaOsobaKError() {
		textaK.append("Zoznam registrovan�ch os�b je pr�zdny!\n\n");
	}
	
	public void neexistujuciAdminKError() {
		textaK.append("Nie je zaregistrovan� �iadny Administr�tor!\n\n");
	}
	
	public void neexistujuciZaznamKError() {
		textaK.append("Z�znam o poistnej udalosti nie je vytvoren�!\n\n");
	}
	
	public void vymazanyZaznamK() {
		textaK.append("Z�znam bol vymazan�.\n\n");
	}
	
	public void vytvorenyZaznamK() {
		textaK.append("Vytvorenie z�znamu o poistnej udalosti prebehlo �spe�ne.\n\n");
	}
	
	public void existujeZaznamKError() {
		textaK.append("Z�znam o poistnej udalosti u� existuje!\n\n");
	}
	
	public void nekorektnyDenKError() {
		textaK.append("Nekorektne zadan� de�! - Automatick� nastavenie - de� 1!\n\n");
	}
	
	public void vypisuj(String vypis) {
		textaK.append(vypis + "\n");
	}
	
	public void vycisti() {
		textaK.setText("");
	}
	
	/**
	 * Getter met�dy na z�skanie textu z textfieldov a z�skanie indexu z comboboxu.
	 */
	public String getMiestoK() {
		return miestoK.getText();
	}
	
	public int getRokK() {
		return ((rokK.getSelectedIndex()) + 2010);
	}

	public String getEmailK() {
		return emailK.getText();
	}
	
	public String getAdresaK() {
		return adresaK.getText();
	}
	
	public int getDenK() {
		return ((denK.getSelectedIndex()) + 1);
	}
	
	public int getMesiacK() {
		return ((mesiacK.getSelectedIndex()) + 1);
	}
}