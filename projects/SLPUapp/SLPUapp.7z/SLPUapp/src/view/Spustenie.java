package view;

import java.awt.event.*;

import javax.swing.*;

/**
 * Trieda Spustenie reprezentuje okno(view), ktor� sa zobraz� pri spusten� aplik�cie.
 */
@SuppressWarnings("serial")
public class Spustenie extends JFrame {
	private JLabel vitaj = new JLabel("V�ta V�s aplik�cia pre syst�m likvid�cie poistnej udalosti!"); // Zadefinovanie tla��tok a n�zvov.
	private JButton prihlasenieS = new JButton("Prihl�senie");
	private JButton registraciaS = new JButton("Registr�cia klienta");
	private JButton quit = new JButton("Koniec");

	public Spustenie() { // Kon�truktor triedy Spustenie.
		setTitle("SLPUapp - 1.0");
		setSize(400, 220);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		spustenieGUI();
	}
	
	/**
	 * Met�da, ktor� sl��i na pridanie potrebn�ch komponentov do okna.
	 */
	public final void spustenieGUI() {
		JPanel spusteniePanel = new JPanel();
		add(spusteniePanel);
		spusteniePanel.setLayout(new BoxLayout(spusteniePanel, BoxLayout.Y_AXIS));

		vitaj.setAlignmentX(CENTER_ALIGNMENT); // Vycentrovanie na osi X.
		prihlasenieS.setAlignmentX(CENTER_ALIGNMENT);
		registraciaS.setAlignmentX(CENTER_ALIGNMENT);
		quit.setAlignmentX(CENTER_ALIGNMENT);

		spusteniePanel.add(Box.createVerticalGlue()); // Prid�vanie komponentov.
		spusteniePanel.add(vitaj);
		spusteniePanel.add(Box.createVerticalGlue());
		spusteniePanel.add(registraciaS);
		spusteniePanel.add(Box.createVerticalGlue());
		spusteniePanel.add(prihlasenieS);
		spusteniePanel.add(Box.createVerticalGlue());
		spusteniePanel.add(quit);
		spusteniePanel.add(Box.createVerticalGlue());
		
		quit.addActionListener(new ActionListener() { // Anonymn� trieda, po stla�en� tohto tla��tka sa vypne program.
			@Override
			public void actionPerformed(ActionEvent event) {
				System.exit(0);
			}
		});
	}
	
	/**
	 * Met�dy na pridanie funkcie tla��tku - vyu��van� v controlleroch.
	 */
	public void addRegistraciaSListener(ActionListener listenForRegistraciaS) {
		registraciaS.addActionListener(listenForRegistraciaS);
	}
	
	public void addPrihlasenieSListener(ActionListener listenForPrihlasenieS) {
		prihlasenieS.addActionListener(listenForPrihlasenieS);
	}
	
	/**
	 * Zobrazenie v�stra�nej spr�vy.
	 */
	public void niktoRegError() {
		JOptionPane.showMessageDialog(this, "Nie je zaregistrovan� �iadny pou��vate�!");
	}
}