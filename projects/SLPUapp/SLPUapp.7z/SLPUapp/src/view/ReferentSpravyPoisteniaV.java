package view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Trieda ReferentSpravyPoisteniaV reprezentuje okno(view), ktor� sa zobraz� po �spe�nom prihl�sen� sa za Referenta spr�vy poistenia.
 */
@SuppressWarnings("serial")
public class ReferentSpravyPoisteniaV extends JFrame { // Zadefinovanie komponentov.
	private JLabel LmenoR = new JLabel("Zadajte meno klienta");
	private JLabel LrozhodR = new JLabel("Vyberte platnos�/vyplatenos�");
	private JButton vypisR = new JButton("V�pis z�znamov");
	private JButton platnostR = new JButton("Nastavenie platnosti z�znamu");
	private JButton vyplatenostR = new JButton("Nastavenie vyplatenosti z�znamu");
	private JButton bossR = new JButton("V�pis administr�torov");
	private JButton odhlasenieR = new JButton("Odhl�si�");
	private JButton vycistiR = new JButton("Clear");
	private JTextField menoR = new JTextField();
	private String[] rozhodnutieR = { "neplatn�/nevyplaten�", "platn�/vyplaten�" };
	private JComboBox<String> rozhodR = new JComboBox<String>(rozhodnutieR);
	private JTextArea textaR = new JTextArea();
	private JScrollPane scrollaR = new JScrollPane(textaR);

	public ReferentSpravyPoisteniaV() { // Kon�truktor triedy ReferentSpravyPoisteniaV
		setTitle("SLPUapp - 1.0");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		referentGUI();
	}
	
	/**
	 * Met�da, ktor� sl��i na pridanie potrebn�ch komponentov do okna.
	 */
	public final void referentGUI() {
		JPanel referentPanel = new JPanel();
		add(referentPanel);
		referentPanel.setLayout(new BorderLayout());
		
		Box opravnenieR = Box.createHorizontalBox(); // Vytvorenie 5 priestorov, do ktor�ch s� ukladan� komponenty.
		Box tlacitkaR = Box.createVerticalBox();
		Box vlozeniaR = Box.createVerticalBox();
		Box textR = Box.createHorizontalBox();
		Box legendaR = Box.createHorizontalBox();
		
		add(opravnenieR, BorderLayout.NORTH); // Ich rozdelenie v BorderLayout
		add(tlacitkaR, BorderLayout.WEST);
		add(vlozeniaR, BorderLayout.CENTER);
		add(textR, BorderLayout.EAST);
		add(legendaR, BorderLayout.SOUTH);

		opravnenieR.add(Box.createVerticalStrut(10));
		opravnenieR.add(new JLabel("Referent spr�vy poistenia"));
		opravnenieR.add(Box.createVerticalStrut(10));
		
		vypisR.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		platnostR.setAlignmentX(CENTER_ALIGNMENT);
		vyplatenostR.setAlignmentX(CENTER_ALIGNMENT);
		bossR.setAlignmentX(CENTER_ALIGNMENT);
		vycistiR.setAlignmentX(CENTER_ALIGNMENT);
		odhlasenieR.setAlignmentX(CENTER_ALIGNMENT);

		tlacitkaR.add(Box.createVerticalGlue()); // Prid�vanie komponentov do Boxu.
		tlacitkaR.add(vypisR);
		tlacitkaR.add(Box.createVerticalGlue());
		tlacitkaR.add(platnostR);
		tlacitkaR.add(Box.createVerticalGlue());
		tlacitkaR.add(vyplatenostR);
		tlacitkaR.add(Box.createVerticalGlue());
		tlacitkaR.add(bossR);
		tlacitkaR.add(Box.createVerticalGlue());
		tlacitkaR.add(vycistiR);
		tlacitkaR.add(Box.createVerticalGlue());
		tlacitkaR.add(odhlasenieR);
		tlacitkaR.add(Box.createVerticalGlue());
		tlacitkaR.setBorder(BorderFactory.createTitledBorder("Mo�nosti"));
		
		menoR.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		rozhodR.setAlignmentX(CENTER_ALIGNMENT);
		LmenoR.setAlignmentX(CENTER_ALIGNMENT);
		LrozhodR.setAlignmentX(CENTER_ALIGNMENT);
		
		vlozeniaR.add(Box.createVerticalStrut(10)); // Prid�vanie komponentov do Boxu.
		vlozeniaR.add(LmenoR);
		vlozeniaR.add(menoR);
		vlozeniaR.add(Box.createVerticalStrut(20));
		vlozeniaR.add(LrozhodR);
		vlozeniaR.add(rozhodR);
		vlozeniaR.add(Box.createVerticalStrut(390));
		vlozeniaR.setBorder(BorderFactory.createTitledBorder("Vlo�enie �dajov"));
		
		textaR.setFont(new Font("Times New Roman", Font.BOLD, 15)); // Nastavenie p�sma v TextArea
		textaR.setEditable(false);
		scrollaR.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollaR.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollaR.setPreferredSize(new Dimension(520,0));
		textR.add(scrollaR);
		textR.setBorder(BorderFactory.createTitledBorder("V�pis"));
		
		legendaR.add(new JLabel("Legenda: nast. platnosti/vyplatenosti(meno, platnos�/vyplatenos�)"));
	}
	
	/**
	 * Met�dy na pridanie funkcie tla�idlu - vyu��van� v controller bal�ku.
	 */
	public void addVypisZaznamovRListener(ActionListener listenForVypisZaznamovR) {
		vypisR.addActionListener(listenForVypisZaznamovR);
	}
	
	public void addNastaveniePlatnostiRListener(ActionListener listenForNastaveniePlatnostiR) {
		platnostR.addActionListener(listenForNastaveniePlatnostiR);
	}
	
	public void addNastavenieVyplatenostiRListener(ActionListener listenForNastavenieVyplatenostiR) {
		vyplatenostR.addActionListener(listenForNastavenieVyplatenostiR);
	}
	
	public void addVypisAdminovRListener(ActionListener listenForVypisAdminovR) {
		bossR.addActionListener(listenForVypisAdminovR);
	}
	
	public void addVycistiRListener(ActionListener listenForVycistiR) {
		vycistiR.addActionListener(listenForVycistiR);
	}
	
	public void addOdhlasitRListener(ActionListener listenForOdhlasitR) {
		odhlasenieR.addActionListener(listenForOdhlasitR);
	}
	
	/**
	 * Met�dy na vypisovanie v�stra�n�ch alebo informa�n�ch spr�v.
	 */
	public void neexistujucaOsobaRError() {
		textaR.append("Zoznam registrovan�ch os�b je pr�zdny!\n\n");
	}
	
	public void nezadanyParameterRError() {
		textaR.append("Nezadali ste meno klienta!\n\n");
	}
	
	public void neexistujuciZoznamRError() {
		textaR.append("Zoznam z�znamov o poistn�ch udalostiach je pr�zdny!\n\n");
	}
	
	public void neexistujuciAdminRError() {
		textaR.append("Nie je zaregistrovan� �iadny Administr�tor!\n\n");
	}
	
	public void neexistujuciZaznamRError() {
		textaR.append("Z�znam o poistnej udalosti tohto klienta nie je vytvoren�!\n\n");
	}
	
	public void aktualizovanyZaznamRP() {
		textaR.append("Z�znam bol aktualizovan� - je platn�.\n\n");
	}
	
	public void aktualizovanyZaznamRN() {
		textaR.append("Z�znam bol aktualizovan� - je neplatn�, a t�m sa nastavila aj schv�lenos� na neschv�len�, vyplatenos� na nevyplaten� a v�platn� suma na 0.\n\n");
	}
	
	public void aktualizovanyZaznamRV() {
		textaR.append("Z�znam bol aktualizovan�. - poistn� plnenie je vyplaten�!\n\n");
	}
	
	public void aktualizovanyZaznamRVN() {
		textaR.append("Z�znam bol aktualizovan�. - poistn� plnenie nie je vyplaten�!\n\n");
	}
	
	public void schvalenieHLRError() {
		textaR.append("Z�znam o poistnej udalosti e�te nebol schv�len� hlavn�m likvid�torom!\n\n");
	}
	
	public void neplatnyZaznamRError() {
		textaR.append("Z�znam o poistnej udalosti nie je platn�!\n\n");
	}
	
	public void vypisuj(String vypis) {
		textaR.append(vypis + "\n");
	}
	
	public void vycisti() {
		textaR.setText("");
	}
	
	/**
	 * Getter met�dy na z�skanie textu z textfieldu a z�skanie indexu z comboboxu.
	 */
	public String getMenoR() {
		return menoR.getText();
	}
	
	public int getRozhodnutieR() {
		return rozhodR.getSelectedIndex();
	}
}