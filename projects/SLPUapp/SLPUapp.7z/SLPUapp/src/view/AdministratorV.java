package view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Trieda AdministratorV reprezentuje okno(view), ktor� sa zobraz� po �spe�nom prihl�sen� sa za Administr�tora.
 */
@SuppressWarnings("serial")
public class AdministratorV extends JFrame { // Zadefinovanie komponentov.
	private JLabel LmenoA = new JLabel("Zadajte meno");
	private JLabel LhesloA = new JLabel("Zadajte heslo");
	private JLabel LopravA = new JLabel("Vyberte typ opr�vnenia");
	private JLabel LmiestoA = new JLabel("Zadajte miesto");
	private JLabel LrokA = new JLabel("Vyberte rok");
	private JLabel LmesiacA = new JLabel("Vyberte mesiac");
	private JLabel LdenA = new JLabel("Vyberte de�");
	private JLabel LemailA = new JLabel("Zadajte email");
	private JLabel LadresaA = new JLabel("Zadajte adresu");
	private JButton vypisRegA = new JButton("V�pis registrovan�ch os�b");
	private JButton regA = new JButton("Registr�cia nov�ho pou��vate�a");
	private JButton zmazPouzA = new JButton("Vymazanie pou��vate�a");
	private JButton vypisZoznA = new JButton("V�pis z�znamov");
	private JButton zmazZaznamA = new JButton("Vymazanie z�znamu");
	private JButton vytvorZaznamA = new JButton("Vytvorenie z�znamu");
	private JButton zmenaPouzA = new JButton("Zmena �dajov (Reg. osoba)");
	private JButton zmenaZaznamA = new JButton("Zmena �dajov (Z�znam)");
	private JButton bossA = new JButton("V�pis administr�torov");
	private JButton odhlasenieA = new JButton("Odhl�si�");
	private JButton vycistiA = new JButton("Clear");
	private JTextField menoA = new JTextField();
	private JPasswordField hesloA = new JPasswordField();
	private JTextField miestoA = new JTextField();
	private String[] opravnenieA = { "Administr�tor", "Hlavn� likvid�tor", "Likvid�tor", "Referent spr�vy poistenia", "Klient" };
	private JComboBox<String> opravA = new JComboBox<String>(opravnenieA);
	private String[] rokyA = { "2010", "2011", "2012", "2013", "2014" };
	private JComboBox<String> rokA = new JComboBox<String>(rokyA);
	private String[] mesiaceA = { "Janu�r", "Febru�r", "Marec", "Apr�l", "M�j", "J�n", "J�l", "August", "September", "Okt�ber", "November", "December" };
	private JComboBox<String> mesiacA = new JComboBox<String>(mesiaceA);
	private String[] dniA = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };
	private JComboBox<String> denA = new JComboBox<String>(dniA);
	private JTextField emailA = new JTextField();
	private JTextField adresaA = new JTextField();
	private JTextArea textaA = new JTextArea();
	private JScrollPane scrollaA = new JScrollPane(textaA);

	public AdministratorV() { // Kon�truktor triedy AdministratorV
		setTitle("SLPUapp - 1.0");
		setSize(1300, 800);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		administratorGUI();
	}
	
	/**
	 * Met�da, ktor� sl��i na pridanie potrebn�ch komponentov do okna.
	 */
	public final void administratorGUI() {
		JPanel administratorPanel = new JPanel();
		add(administratorPanel);
		administratorPanel.setLayout(new BorderLayout());
		
		Box opravnenieA = Box.createHorizontalBox(); // Vytvorenie 5 priestorov, do ktor�ch s� ukladan� komponenty.
		Box tlacitkaA = Box.createVerticalBox();
		Box vlozeniaA = Box.createVerticalBox();
		Box textA = Box.createHorizontalBox();
		Box legendaA = Box.createHorizontalBox();
		
		add(opravnenieA, BorderLayout.NORTH); // Ich rozdelenie v BorderLayout
		add(tlacitkaA, BorderLayout.WEST);
		add(vlozeniaA, BorderLayout.CENTER);
		add(textA, BorderLayout.EAST);
		add(legendaA, BorderLayout.SOUTH);

		opravnenieA.add(Box.createVerticalStrut(10));
		opravnenieA.add(new JLabel("Administr�tor"));
		opravnenieA.add(Box.createVerticalStrut(10));
		
		vypisRegA.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		regA.setAlignmentX(CENTER_ALIGNMENT);
		zmazPouzA.setAlignmentX(CENTER_ALIGNMENT);
		vypisZoznA.setAlignmentX(CENTER_ALIGNMENT);
		zmazZaznamA.setAlignmentX(CENTER_ALIGNMENT);
		vytvorZaznamA.setAlignmentX(CENTER_ALIGNMENT);
		zmenaPouzA.setAlignmentX(CENTER_ALIGNMENT);
		zmenaZaznamA.setAlignmentX(CENTER_ALIGNMENT);
		bossA.setAlignmentX(CENTER_ALIGNMENT);
		vycistiA.setAlignmentX(CENTER_ALIGNMENT);
		odhlasenieA.setAlignmentX(CENTER_ALIGNMENT);

		tlacitkaA.add(Box.createVerticalGlue()); // Prid�vanie komponentov do Boxu.
		tlacitkaA.add(vypisRegA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(regA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(zmazPouzA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(vypisZoznA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(zmazZaznamA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(vytvorZaznamA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(zmenaPouzA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(zmenaZaznamA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(bossA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(vycistiA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.add(odhlasenieA);
		tlacitkaA.add(Box.createVerticalGlue());
		tlacitkaA.setBorder(BorderFactory.createTitledBorder("Mo�nosti"));
		
		menoA.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		hesloA.setAlignmentX(CENTER_ALIGNMENT);
		miestoA.setAlignmentX(CENTER_ALIGNMENT);
		opravA.setAlignmentX(CENTER_ALIGNMENT);
		rokA.setAlignmentX(CENTER_ALIGNMENT);
		mesiacA.setAlignmentX(CENTER_ALIGNMENT);
		denA.setAlignmentX(CENTER_ALIGNMENT);
		emailA.setAlignmentX(CENTER_ALIGNMENT);
		adresaA.setAlignmentX(CENTER_ALIGNMENT);
		LmenoA.setAlignmentX(CENTER_ALIGNMENT);
		LhesloA.setAlignmentX(CENTER_ALIGNMENT);
		LopravA.setAlignmentX(CENTER_ALIGNMENT);
		LmiestoA.setAlignmentX(CENTER_ALIGNMENT);
		LrokA.setAlignmentX(CENTER_ALIGNMENT);
		LmesiacA.setAlignmentX(CENTER_ALIGNMENT);
		LdenA.setAlignmentX(CENTER_ALIGNMENT);
		LemailA.setAlignmentX(CENTER_ALIGNMENT);
		LadresaA.setAlignmentX(CENTER_ALIGNMENT);
		
		vlozeniaA.add(Box.createVerticalStrut(10)); // Prid�vanie komponentov do Boxu.
		vlozeniaA.add(LmenoA);
		vlozeniaA.add(menoA);
		vlozeniaA.add(Box.createVerticalStrut(25));
		vlozeniaA.add(LhesloA);
		vlozeniaA.add(hesloA);
		vlozeniaA.add(Box.createVerticalStrut(25));
		vlozeniaA.add(LopravA);
		vlozeniaA.add(opravA);
		vlozeniaA.add(Box.createVerticalStrut(25));
		vlozeniaA.add(LmiestoA);
		vlozeniaA.add(miestoA);
		vlozeniaA.add(Box.createVerticalStrut(25));
		vlozeniaA.add(LrokA);
		vlozeniaA.add(rokA);
		vlozeniaA.add(Box.createVerticalStrut(25));
		vlozeniaA.add(LmesiacA);
		vlozeniaA.add(mesiacA);
		vlozeniaA.add(Box.createVerticalStrut(25));
		vlozeniaA.add(LdenA);
		vlozeniaA.add(denA);
		vlozeniaA.add(Box.createVerticalStrut(25));
		vlozeniaA.add(LemailA);
		vlozeniaA.add(emailA);
		vlozeniaA.add(Box.createVerticalStrut(25));
		vlozeniaA.add(LadresaA);
		vlozeniaA.add(adresaA);
		vlozeniaA.add(Box.createVerticalStrut(280));
		vlozeniaA.setBorder(BorderFactory.createTitledBorder("Vlo�enie �dajov"));
		
		textaA.setFont(new Font("Times New Roman", Font.BOLD, 15)); // Nastavenie p�sma v TextArea
		textaA.setEditable(false);
		scrollaA.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollaA.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollaA.setPreferredSize(new Dimension(800,0));
		textA.add(scrollaA);
		textA.setBorder(BorderFactory.createTitledBorder("V�pis"));
		
		legendaA.add(new JLabel("Legenda: reg. nov�ho pou��vate�a / zmena �.- reg.osoba(meno, heslo, opr�vnenie), vymaz. pou��vate�a / z�znamu(meno), vytvor. z�znamu / zmena �.- z�znam(meno, miesto, rok, mesiac, de�, email, adresa)"));
	}
	
	/**
	 * Met�dy na pridanie funkcie tla�idlu - vyu��van� v controller bal�ku.
	 */
	public void addVypisRegOsobAListener(ActionListener listenForVypisRegOsobA) {
		vypisRegA.addActionListener(listenForVypisRegOsobA);
	}
	
	public void addRegistrujNovehoPouzAListener(ActionListener listenForRegistrujNovehoPouzA) {
		regA.addActionListener(listenForRegistrujNovehoPouzA);
	}
	
	public void addZmazPouzAListener(ActionListener listenForZmazPouzA) {
		zmazPouzA.addActionListener(listenForZmazPouzA);
	}
	
	public void addVypisZoznamuAListener(ActionListener listenForVypisZoznamuA) {
		vypisZoznA.addActionListener(listenForVypisZoznamuA);
	}
	
	public void addZmazZaznamAListener(ActionListener listenForZmazZaznamA) {
		zmazZaznamA.addActionListener(listenForZmazZaznamA);
	}
	
	public void addVytvorZaznamAListener(ActionListener listenForVytvorZaznamA) {
		vytvorZaznamA.addActionListener(listenForVytvorZaznamA);
	}
	
	public void addZmenaUPouzAListener(ActionListener listenForZmenaUPouzA) {
		zmenaPouzA.addActionListener(listenForZmenaUPouzA);
	}
	
	public void addZmenaUZaznamAListener(ActionListener listenForZmenaUZaznamA) {
		zmenaZaznamA.addActionListener(listenForZmenaUZaznamA);
	}
	
	public void addVypisAdminovAListener(ActionListener listenForVypisAdminovA) {
		bossA.addActionListener(listenForVypisAdminovA);
	}
	
	public void addVycistiAListener(ActionListener listenForVycistiA) {
		vycistiA.addActionListener(listenForVycistiA);
	}
	
	public void addOdhlasitAListener(ActionListener listenForOdhlasitA) {
		odhlasenieA.addActionListener(listenForOdhlasitA);
	}
	
	/**
	 * Met�dy na vypisovanie v�stra�n�ch alebo informa�n�ch spr�v.
	 */
	public void neexistujucaOsobaAError() {
		textaA.append("Zoznam registrovan�ch os�b je pr�zdny!\n\n");
	}
	
	public void nezadanyParameterAError() {
		textaA.append("Nezadali ste niektor� z �dajov!\n\n");
	}
	
	public void neexistujuciZoznamAError() {
		textaA.append("Zoznam z�znamov o poistn�ch udalostiach je pr�zdny!\n\n");
	}
	
	public void neexistujuciAdminAError() {
		textaA.append("Nie je zaregistrovan� �iadny Administr�tor!\n\n");
	}
	
	public void neexistujuciZaznamAError() {
		textaA.append("Z�znam o poistnej udalosti tohto klienta nie je vytvoren�!\n\n");
	}
	
	public void uspesnaRegA() {
		textaA.append("Registr�cia prebehla �spe�ne.\n\n");
	}
	
	public void zhodneMenaAError() {
		textaA.append("Pou��vate� s tak�m menom u� existuje!\n\n");
	}
	
	public void nezhodneMenaAError() {
		textaA.append("Nikto s tak�m menom nie je registrovan�!\n\n");
	}
	
	public void vymazanyPouzivatelA() {
		textaA.append("Pou��vate� bol vymazan�.\n\n");
	}
	
	public void vymazanyZaznamA() {
		textaA.append("Z�znam bol vymazan�.\n\n");
	}
	
	public void vytvorenyZaznamA() {
		textaA.append("Z�znam o poistnej udalosti bol vytvoren�.\n\n");
	}
	
	public void uzExistujeZaznamA() {
		textaA.append("Z�znam o poistnej udalosti u� existuje.\n\n");
	}
	
	public void aktualizovanaOsobaA() {
		textaA.append("Pou��vate�sk� �daje boli zmenen�.\n\n");
	}
	
	public void aktualizovanyZaznamA() {
		textaA.append("Z�znam bol aktualizovan�.\n\n");
	}
	
	public void vypisuj(String vypis) {
		textaA.append(vypis + "\n");
	}
	
	public void vycisti() {
		textaA.setText("");
	}
	
	/**
	 * Getter met�dy na z�skanie textu z textfieldov a z�skanie indexu z comboboxu.
	 */
	public String getMenoA() {
		return menoA.getText();
	}
	
	@SuppressWarnings("deprecation")
	public String getHesloA() {
		return hesloA.getText();
	}
	
	public String getMiestoA() {
		return miestoA.getText();
	}
	
	public int getOpravnenieA() {
		return ((opravA.getSelectedIndex()) +1 );
	}
	
	public int getRokA() {
		return ((rokA.getSelectedIndex()) + 2010);
	}

	public String getEmailA() {
		return emailA.getText();
	}
	
	public String getAdresaA() {
		return adresaA.getText();
	}
	
	public int getDenA() {
		return ((denA.getSelectedIndex()) + 1);
	}
	
	public int getMesiacA() {
		return ((mesiacA.getSelectedIndex()) + 1);
	}
}