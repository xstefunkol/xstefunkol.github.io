package view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Trieda LikvidatorV reprezentuje okno(view), ktor� sa zobraz� po �spe�nom prihl�sen� sa za Likvid�tora.
 */
@SuppressWarnings("serial")
public class LikvidatorV extends JFrame { // Zadefinovanie komponentov.
	private JLabel LmenoL = new JLabel("Zadajte meno klienta");
	private JLabel LhodnotaL = new JLabel("Zadajte v�platn� sumu");
	private JLabel LrozhodL = new JLabel("Vyberte typ poistenia");
	private JButton vypisL = new JButton("V�pis z�znamov");
	private JButton sumaL = new JButton("Nastavenie v�platnej sumy");
	private JButton typpoisteniaL = new JButton("Nastavenie typu poistenia");
	private JButton bossL = new JButton("V�pis nadriaden�ch");
	private JButton odhlasenieL = new JButton("Odhl�si�");
	private JButton vycistiL = new JButton("Clear");
	private JTextField menoL = new JTextField();
	private JTextField hodnotaL = new JTextField();
	private String[] rozhodnutieL = { "poistenie z�ujmu", "poistenie os�b", "poistenie majetku", "�ivotn�", "rizikov�", "z�konn�", "povinn� zmluvn�", "dobrovo�n� zmluvn�", "kr�tkodob�", "dlhodob�" };
	private JComboBox<String> rozhodL = new JComboBox<String>(rozhodnutieL);
	private JTextArea textaL = new JTextArea();
	private JScrollPane scrollaL = new JScrollPane(textaL);

	public LikvidatorV() { // Kon�truktor triedy LikvidatorV
		setTitle("SLPUapp - 1.0");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		likvidatorGUI();
	}
	
	/**
	 * Met�da, ktor� sl��i na pridanie potrebn�ch komponentov do okna.
	 */
	public final void likvidatorGUI() {
		JPanel likvidatorPanel = new JPanel();
		add(likvidatorPanel);
		likvidatorPanel.setLayout(new BorderLayout());
		
		Box opravnenieL = Box.createHorizontalBox(); // Vytvorenie 5 priestorov, do ktor�ch s� ukladan� komponenty.
		Box tlacitkaL = Box.createVerticalBox();
		Box vlozeniaL = Box.createVerticalBox();
		Box textL = Box.createHorizontalBox();
		Box legendaL = Box.createHorizontalBox();
		
		add(opravnenieL, BorderLayout.NORTH); // Ich rozdelenie v BorderLayout
		add(tlacitkaL, BorderLayout.WEST);
		add(vlozeniaL, BorderLayout.CENTER);
		add(textL, BorderLayout.EAST);
		add(legendaL, BorderLayout.SOUTH);

		opravnenieL.add(Box.createVerticalStrut(10));
		opravnenieL.add(new JLabel("Likvid�tor"));
		opravnenieL.add(Box.createVerticalStrut(10));
		
		vypisL.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		sumaL.setAlignmentX(CENTER_ALIGNMENT);
		typpoisteniaL.setAlignmentX(CENTER_ALIGNMENT);
		bossL.setAlignmentX(CENTER_ALIGNMENT);
		vycistiL.setAlignmentX(CENTER_ALIGNMENT);
		odhlasenieL.setAlignmentX(CENTER_ALIGNMENT);

		tlacitkaL.add(Box.createVerticalGlue()); // Prid�vanie komponentov do Boxu.
		tlacitkaL.add(vypisL);
		tlacitkaL.add(Box.createVerticalGlue());
		tlacitkaL.add(sumaL);
		tlacitkaL.add(Box.createVerticalGlue());
		tlacitkaL.add(typpoisteniaL);
		tlacitkaL.add(Box.createVerticalGlue());
		tlacitkaL.add(bossL);
		tlacitkaL.add(Box.createVerticalGlue());
		tlacitkaL.add(vycistiL);
		tlacitkaL.add(Box.createVerticalGlue());
		tlacitkaL.add(odhlasenieL);
		tlacitkaL.add(Box.createVerticalGlue());
		tlacitkaL.setBorder(BorderFactory.createTitledBorder("Mo�nosti"));
		
		menoL.setAlignmentX(CENTER_ALIGNMENT); // Centrovanie na osi X.
		hodnotaL.setAlignmentX(CENTER_ALIGNMENT);
		rozhodL.setAlignmentX(CENTER_ALIGNMENT);
		LmenoL.setAlignmentX(CENTER_ALIGNMENT);
		LhodnotaL.setAlignmentX(CENTER_ALIGNMENT);
		LrozhodL.setAlignmentX(CENTER_ALIGNMENT);
		
		vlozeniaL.add(Box.createVerticalStrut(10)); // Prid�vanie komponentov do Boxu.
		vlozeniaL.add(LmenoL);
		vlozeniaL.add(menoL);
		vlozeniaL.add(Box.createVerticalStrut(25));
		vlozeniaL.add(LhodnotaL);
		vlozeniaL.add(hodnotaL);
		vlozeniaL.add(Box.createVerticalStrut(25));
		vlozeniaL.add(LrozhodL);
		vlozeniaL.add(rozhodL);
		vlozeniaL.add(Box.createVerticalStrut(350));
		vlozeniaL.setBorder(BorderFactory.createTitledBorder("Vlo�enie �dajov"));
		
		textaL.setFont(new Font("Times New Roman", Font.BOLD, 15)); // Nastavenie p�sma v TextArea
		textaL.setEditable(false);
		scrollaL.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollaL.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollaL.setPreferredSize(new Dimension(550,0));
		textL.add(scrollaL);
		textL.setBorder(BorderFactory.createTitledBorder("V�pis"));
		
		legendaL.add(new JLabel("Legenda: nast. v�platnej sumy(meno, suma), nast. typu poistenia(meno, typpoistenia)"));
	}
	
	/**
	 * Met�dy na pridanie funkcie tla�idlu - vyu��van� v controller bal�ku.
	 */
	public void addVypisZaznamovLListener(ActionListener listenForVypisZaznamovL) {
		vypisL.addActionListener(listenForVypisZaznamovL);
	}
	
	public void addNastavenieSumyLListener(ActionListener listenForNastavenieSumyL) {
		sumaL.addActionListener(listenForNastavenieSumyL);
	}
	
	public void addNastaveniePoistLListener(ActionListener listenForNastaveniePoistL) {
		typpoisteniaL.addActionListener(listenForNastaveniePoistL);
	}
	
	public void addVypisAdminovHLLListener(ActionListener listenForVypisAdminovHLL) {
		bossL.addActionListener(listenForVypisAdminovHLL);
	}
	
	public void addVycistiLListener(ActionListener listenForVycistiL) {
		vycistiL.addActionListener(listenForVycistiL);
	}
	
	public void addOdhlasitLListener(ActionListener listenForOdhlasitL) {
		odhlasenieL.addActionListener(listenForOdhlasitL);
	}
	
	/**
	 * Met�dy na vypisovanie v�stra�n�ch alebo informa�n�ch spr�v.
	 */
	public void neexistujucaOsobaLError() {
		textaL.append("Zoznam registrovan�ch os�b je pr�zdny!\n\n");
	}
	
	public void nezadanyParameterMenoLError() {
		textaL.append("Nezadali ste meno klienta!\n\n");
	}
	
	public void neexistujuciZoznamLError() {
		textaL.append("Zoznam z�znamov o poistn�ch udalostiach je pr�zdny!\n\n");
	}
	
	public void neexistujuciAdminHLLError() {
		textaL.append("Nie je zaregistrovan� �iadny Administr�tor ani Hlavn� likvid�tor!\n\n");
	}
	
	public void neexistujuciZaznamLError() {
		textaL.append("Z�znam o poistnej udalosti tohto klienta nie je vytvoren�!\n\n");
	}
	
	public void aktualizovanyZaznamSL() {
		textaL.append("Z�znam bol aktualizovan� a hodnota poistn�ho plnenia bola schv�len�.\n\n");
	}
	
	public void aktualizovanyZaznamSLError() {
		textaL.append("Z�znam bol aktualizovan�, ale hodnota poistn�ho plnenia nem��e by� schv�len� - kontaktujte hlavn�ho likvid�tora!\n\n");
	}
	
	public void aktualizovanyZaznamTPL() {
		textaL.append("Z�znam bol aktualizovan� a typ poistenia zmenen�.\n\n");
	}
	
	public void nekorektnaSumaLError() {
		textaL.append("Z�znam bol aktualizovan�, ale nekorektne ste zadali hodnotu poistn�ho plnenia! - Automatick� nastavenie - 0!\n\n");
	}
	
	public void vypisuj(String vypis) {
		textaL.append(vypis + "\n");
	}
	
	public void vycisti() {
		textaL.setText("");
	}
	
	/**
	 * Getter met�dy na z�skanie textu z textfieldov a z�skanie indexu z comboboxu.
	 */
	public String getMenoL() {
		return menoL.getText();
	}
	
	public int getRozhodnutieL() {
		return rozhodL.getSelectedIndex();
	}
	
	public String getSumaL() {
		return hodnotaL.getText();
	}
}