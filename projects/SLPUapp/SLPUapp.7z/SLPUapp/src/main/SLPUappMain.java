package main;

import java.util.ArrayList;

import javax.swing.SwingUtilities; // Import potrebn�ch bal�kov.

import model.Administrator;
import model.HlavnyLikvidator;
import model.Klient;
import model.Likvidator;
import model.ReferentSpravyPoistenia;
import model.RegistrovanaOsoba;
import model.Zaznam;
import controller.SpustenieC;
import view.Spustenie;

/** SLPUApp - Aplik�cia pre syst�m likvid�cie poistn�ch udalost�
 * Spracov�vanie �dajov v z�znamoch o poistn�ch udalostiach.
 * @author �ubo� �tefunko, skupina 59, cvi�enie Piatok 8:00
 * @version 1.0
 */

public class SLPUappMain {

	/** Hlavn� met�da na zabezpe�enie spustenia programu.
	 * @param args Pole stringov
	 */

	public static void main(String[] args) {
		
		final RegistrovanaOsoba admin = new RegistrovanaOsoba(); // Vytvorenie in�tanci� 2 opr�vnen� pre neskor�ie pou�itie prekonan�ch met�d.
		final Likvidator likvid = new Likvidator();
		final ArrayList<RegistrovanaOsoba> osoby = new ArrayList<>(); // Zadefinovanie pol� s registrovan�mi osobami a so z�znamami o poistn�ch udalostiach.
		final ArrayList<Zaznam> zoznam = new ArrayList<>();

		RegistrovanaOsoba lubos = new Administrator("Lubos Stefunko", "123"); // Vytvorenie in�tanci� registrovan�ch os�b a ich pridanie do po�a - pou�it� polymorfizmus.
		osoby.add(lubos);
		RegistrovanaOsoba marek = new HlavnyLikvidator("Marek Schmidt", "456");
		osoby.add(marek);
		RegistrovanaOsoba matej = new Likvidator("Matej Kollar", "789");
		osoby.add(matej);
		RegistrovanaOsoba adam = new ReferentSpravyPoistenia("Adam Bodorik", "159");
		osoby.add(adam);
		RegistrovanaOsoba milos = new Klient("Milos Stefcak", "357");
		osoby.add(milos);

		Zaznam a = new Zaznam("Milos Stefcak", "Bratislava", 2010, 1, 11, "�ivotn�", "milos", "Sv. Jur, 517", false, 0, false, true); // Vytvorenie in�tancie z�znamu a jeho pridanie do po�a.
		zoznam.add(a);
		
		SwingUtilities.invokeLater(new Runnable() { // Anonymn� trieda, ktor� sp���a program v novej niti na opatrenie proti zamrznutiu resp. pre pr�cu s GUI po�as dlh��ch v�po�tov.
			/* (non-Javadoc)
			 * @see java.lang.Runnable#run()
			 */
			@Override
			public void run() {
				Spustenie spustenie = new Spustenie();
				spustenie.setVisible(true);
				@SuppressWarnings("unused")
				SpustenieC spustenieCont = new SpustenieC(spustenie, osoby, zoznam, admin, likvid);
			}
		});
	}
}