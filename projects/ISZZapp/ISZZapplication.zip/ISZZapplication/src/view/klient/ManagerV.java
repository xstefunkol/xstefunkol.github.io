package view.klient;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JButton;
import javax.swing.JTable;

import model.klient.Animal;
import model.klient.Employee;
import controller.klient.ManagerC;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Logger;

import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

/**
 * ManagerV class - GUI pre pr�cu s programom
 * @author �ubo� �tefunko
 */
@SuppressWarnings("serial")
public class ManagerV extends JFrame {

	private static final Logger LOG = Logger.getLogger(Logger.class.getName());
	private JPanel contentPane;
	private JTextField textFieldAnimal;
	private JTextField textFieldAApear;
	private JTextField textFieldEName;
	private JTextField textFieldEType;
	private JTable tableE;
	private JTable tableA;

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ManagerV() {
		setTitle("ISZZapp");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 868, 888);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblAnimals = new JLabel("Animals");
		lblAnimals.setBounds(10, 11, 46, 14);
		contentPane.add(lblAnimals);

		JLabel label = new JLabel(
				"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		label.setBounds(10, 34, 832, 14);
		contentPane.add(label);

		JLabel lblAnimal = new JLabel("Animal");
		lblAnimal.setBounds(10, 59, 46, 14);
		contentPane.add(lblAnimal);

		textFieldAnimal = new JTextField();
		textFieldAnimal.setBounds(10, 84, 135, 20);
		contentPane.add(textFieldAnimal);
		textFieldAnimal.setColumns(25);

		JComboBox comboBoxAType = new JComboBox();
		comboBoxAType.setModel(new DefaultComboBoxModel(new String[] {"cicavec", "plaz", "vt�k", "hmyz", "pav�k", "ryba", "oboj�iveln�k"}));
		comboBoxAType.setMaximumRowCount(6);
		comboBoxAType.setBounds(155, 84, 100, 20);
		contentPane.add(comboBoxAType);

		JLabel lblType = new JLabel("Type");
		lblType.setBounds(155, 59, 51, 14);
		contentPane.add(lblType);

		JComboBox comboBoxAGender = new JComboBox();
		comboBoxAGender
				.setModel(new DefaultComboBoxModel(new String[] { "M", "F" }));
		comboBoxAGender.setMaximumRowCount(2);
		comboBoxAGender.setBounds(265, 84, 60, 20);
		contentPane.add(comboBoxAGender);

		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(265, 59, 60, 14);
		contentPane.add(lblGender);
		
		JLabel lblYearOfBirth = new JLabel("Year of birth");
		lblYearOfBirth.setBounds(335, 59, 91, 14);
		contentPane.add(lblYearOfBirth);
		
		JLabel lblLengthm = new JLabel("Length (m)");
		lblLengthm.setBounds(436, 59, 70, 14);
		contentPane.add(lblLengthm);
		
		JLabel lblWeightkg = new JLabel("Weight (kg)");
		lblWeightkg.setBounds(516, 59, 70, 14);
		contentPane.add(lblWeightkg);
		
		JLabel lblProtection = new JLabel("Protection");
		lblProtection.setBounds(596, 59, 60, 14);
		contentPane.add(lblProtection);
		
		JLabel lblAppearance = new JLabel("Appearance");
		lblAppearance.setBounds(666, 59, 100, 14);
		contentPane.add(lblAppearance);

		JComboBox comboBoxAYear = new JComboBox();
		comboBoxAYear.setModel(new DefaultComboBoxModel(new String[] { "1950",
				"1951", "1952", "1953", "1954", "1955", "1956", "1957", "1958",
				"1959", "1960", "1961", "1962", "1963", "1964", "1965", "1966",
				"1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974",
				"1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982",
				"1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990",
				"1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998",
				"1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006",
				"2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014",
				"2015" }));
		comboBoxAYear.setMaximumRowCount(50);
		comboBoxAYear.setBounds(335, 84, 91, 20);
		contentPane.add(comboBoxAYear);

		JSpinner spinnerALength = new JSpinner();
		spinnerALength.setModel(new SpinnerNumberModel(0.0,0.0,15000.0,0.1));
		spinnerALength.setBounds(436, 84, 70, 20);
		contentPane.add(spinnerALength);

		JSpinner spinnerAWeight = new JSpinner();
		spinnerAWeight.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		spinnerAWeight.setBounds(516, 84, 70, 20);
		contentPane.add(spinnerAWeight);

		JComboBox comboBoxAProt = new JComboBox();
		comboBoxAProt
				.setModel(new DefaultComboBoxModel(new String[] {"A", "N"}));
		comboBoxAProt.setMaximumRowCount(2);
		comboBoxAProt.setBounds(596, 84, 60, 20);
		contentPane.add(comboBoxAProt);

		textFieldAApear = new JTextField();
		textFieldAApear.setBounds(666, 84, 100, 20);
		contentPane.add(textFieldAApear);
		textFieldAApear.setColumns(25);

		JComboBox comboBoxAExhibit = new JComboBox();
		comboBoxAExhibit.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8"}));
		comboBoxAExhibit.setBounds(776, 84, 60, 20);
		contentPane.add(comboBoxAExhibit);

		JLabel lblExhibit = new JLabel("Exhibit");
		lblExhibit.setBounds(776, 59, 46, 14);
		contentPane.add(lblExhibit);

		JButton btnAddAnimal = new JButton("Add animal");
		btnAddAnimal.setBounds(676, 115, 160, 23);
		contentPane.add(btnAddAnimal);

		JLabel lblforFunctionSearch = new JLabel(
				"(Search for animals)");
		lblforFunctionSearch.setBounds(10, 153, 376, 14);
		contentPane.add(lblforFunctionSearch);

		JButton btnEditAnimal = new JButton("Edit animal");
		btnEditAnimal.setBounds(676, 183, 160, 23);
		contentPane.add(btnEditAnimal);

		JLabel lblchooseAnimalFrom = new JLabel(
				"(Choose animal from table which contains id column)");
		lblchooseAnimalFrom.setBounds(10, 221, 336, 14);
		contentPane.add(lblchooseAnimalFrom);

		JButton btnDeleteAnimal = new JButton("Delete animal");
		btnDeleteAnimal.setBounds(676, 217, 160, 23);
		contentPane.add(btnDeleteAnimal);

		JButton btnDetailedListOf = new JButton("Detailed list of animals");
		btnDetailedListOf.setBounds(10, 246, 216, 23);
		contentPane.add(btnDetailedListOf);

		JLabel lblEmployees = new JLabel("Employees");
		lblEmployees.setBounds(10, 427, 231, 14);
		contentPane.add(lblEmployees);

		JLabel label_1 = new JLabel(
				"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		label_1.setBounds(10, 452, 832, 14);
		contentPane.add(label_1);

		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 477, 46, 14);
		contentPane.add(lblName);

		textFieldEName = new JTextField();
		textFieldEName.setColumns(30);
		textFieldEName.setBounds(10, 502, 160, 20);
		contentPane.add(textFieldEName);

		JComboBox comboBoxEGender = new JComboBox();
		comboBoxEGender
				.setModel(new DefaultComboBoxModel(new String[] { "M", "F" }));
		comboBoxEGender.setMaximumRowCount(2);
		comboBoxEGender.setBounds(180, 502, 60, 20);
		contentPane.add(comboBoxEGender);

		JLabel labelEGender = new JLabel("Gender");
		labelEGender.setBounds(180, 477, 61, 14);
		contentPane.add(labelEGender);

		JComboBox comboBoxEYear = new JComboBox();
		comboBoxEYear.setModel(new DefaultComboBoxModel(new String[] { "1950",
				"1951", "1952", "1953", "1954", "1955", "1956", "1957", "1958",
				"1959", "1960", "1961", "1962", "1963", "1964", "1965", "1966",
				"1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974",
				"1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982",
				"1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990",
				"1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998",
				"1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006",
				"2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014",
				"2015" }));
		comboBoxEYear.setMaximumRowCount(50);
		comboBoxEYear.setBounds(250, 502, 91, 20);
		contentPane.add(comboBoxEYear);

		JLabel labelEYear = new JLabel("Year of birth");
		labelEYear.setBounds(251, 477, 90, 14);
		contentPane.add(labelEYear);

		JSpinner spinnerESalary = new JSpinner();
		spinnerESalary.setModel(new SpinnerNumberModel(0.0,0.0,15000.0,0.1));
		spinnerESalary.setBounds(351, 502, 70, 20);
		contentPane.add(spinnerESalary);

		JLabel lblSalary = new JLabel("Salary (\u20AC)");
		lblSalary.setBounds(351, 477, 70, 14);
		contentPane.add(lblSalary);

		textFieldEType = new JTextField();
		textFieldEType.setColumns(25);
		textFieldEType.setBounds(431, 502, 100, 20);
		contentPane.add(textFieldEType);

		JLabel labelEType = new JLabel("Type");
		labelEType.setBounds(431, 477, 46, 14);
		contentPane.add(labelEType);

		JComboBox comboBoxEBuilding = new JComboBox();
		comboBoxEBuilding.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9"}));
		comboBoxEBuilding.setMaximumRowCount(9);
		comboBoxEBuilding.setBounds(541, 502, 60, 20);
		contentPane.add(comboBoxEBuilding);

		JLabel lblBuilding = new JLabel("Building");
		lblBuilding.setBounds(541, 477, 46, 14);
		contentPane.add(lblBuilding);

		JButton btnAddEmployee = new JButton("Add employee");
		btnAddEmployee.setBounds(676, 501, 160, 23);
		contentPane.add(btnAddEmployee);

		JLabel lblforFunctionSearch_1 = new JLabel(
				"(Search for employees)");
		lblforFunctionSearch_1.setBounds(10, 539, 376, 14);
		contentPane.add(lblforFunctionSearch_1);

		JLabel lblforFunctionEdit = new JLabel(
				"(Edit animal - use length, weight, protection and exhibit and choose animal from table which contains id column)");
		lblforFunctionEdit.setBounds(10, 187, 666, 14);
		contentPane.add(lblforFunctionEdit);

		JLabel lblforFunctionEdit_1 = new JLabel(
				"(Edit employee - use salary, type and building and choose employee from table which contains id column)");
		lblforFunctionEdit_1.setBounds(10, 573, 666, 14);
		contentPane.add(lblforFunctionEdit_1);

		JButton btnEditEmployee = new JButton("Edit employee");
		btnEditEmployee.setBounds(676, 569, 160, 23);
		contentPane.add(btnEditEmployee);

		JLabel lblchooseEmployeeFrom = new JLabel(
				"(Choose employee from table which contains id column)");
		lblchooseEmployeeFrom.setBounds(10, 607, 376, 14);
		contentPane.add(lblchooseEmployeeFrom);

		JButton btnDeleteEmployee = new JButton("Delete employee");
		btnDeleteEmployee.setBounds(676, 603, 160, 23);
		contentPane.add(btnDeleteEmployee);

		JButton btnECost = new JButton("View cost of employees");
		btnECost.setBounds(10, 632, 259, 23);
		contentPane.add(btnECost);

		JButton btnDetailedListOf_1 = new JButton("Detailed list of employees");
		btnDetailedListOf_1.setBounds(279, 632, 227, 23);
		contentPane.add(btnDetailedListOf_1);

		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ManagerC.getLogOut();
			}
		});
		
		btnLogout.setBounds(747, 813, 89, 23);
		contentPane.add(btnLogout);
		
		JScrollPane scrollPaneA = new JScrollPane();
		scrollPaneA.setBounds(10, 280, 826, 136);
		contentPane.add(scrollPaneA);
		
		tableA = new JTable();
		tableA.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPaneA.setViewportView(tableA);
		tableA.setBackground(Color.WHITE);
				
		JScrollPane scrollPaneE = new JScrollPane();
		scrollPaneE.setBounds(10, 666, 826, 136);
		contentPane.add(scrollPaneE);
		
		tableE = new JTable();
		tableE.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPaneE.setViewportView(tableE);
		tableE.setBackground(Color.WHITE);
		
		JButton btnVAVG = new JButton("View average salary");
		btnVAVG.setBounds(516, 632, 170, 23);
		contentPane.add(btnVAVG);
		
		JButton btnSearchAName = new JButton("Search by animal");
		btnSearchAName.setBounds(394, 149, 216, 23);
		contentPane.add(btnSearchAName);
		
		JButton btnSearchAExhibit = new JButton("Search by exhibit");
		btnSearchAExhibit.setBounds(620, 149, 216, 23);
		contentPane.add(btnSearchAExhibit);
		
		JButton btnSearchEBuilding = new JButton("Search by building");
		btnSearchEBuilding.setBounds(620, 535, 216, 23);
		contentPane.add(btnSearchEBuilding);
		
		JButton btnSearchEName = new JButton("Search by name");
		btnSearchEName.setBounds(396, 535, 214, 23);
		contentPane.add(btnSearchEName);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale((String) comboBox.getSelectedItem()));
				lblAnimals.setText(rb.getString("animals.VAVA"));
				lblAnimal.setText(rb.getString("animal.VAVA"));
				lblType.setText(rb.getString("type.VAVA"));
				lblGender.setText(rb.getString("gender.VAVA"));
				lblYearOfBirth.setText(rb.getString("year.VAVA"));
				lblLengthm.setText(rb.getString("length.VAVA"));
				lblWeightkg.setText(rb.getString("weight.VAVA"));
				lblProtection.setText(rb.getString("protection.VAVA"));
				lblAppearance.setText(rb.getString("appearance.VAVA"));
				lblExhibit.setText(rb.getString("exhibit.VAVA"));
				btnAddAnimal.setText(rb.getString("addA.VAVA"));
				lblforFunctionSearch.setText(rb.getString("searchFA.VAVA"));
				btnEditAnimal.setText(rb.getString("editA.VAVA"));
				lblchooseAnimalFrom.setText(rb.getString("chooseA.VAVA"));
				btnDeleteAnimal.setText(rb.getString("deleteA.VAVA"));
				btnDetailedListOf.setText(rb.getString("listOA.VAVA"));
				lblEmployees.setText(rb.getString("employees.VAVA"));
				lblName.setText(rb.getString("name.VAVA"));
				labelEGender.setText(rb.getString("gender.VAVA"));
				labelEYear.setText(rb.getString("year.VAVA"));
				lblSalary.setText(rb.getString("salary.VAVA"));
				labelEType.setText(rb.getString("type.VAVA"));
				lblBuilding.setText(rb.getString("building.VAVA"));
				btnAddEmployee.setText(rb.getString("addE.VAVA"));
				lblforFunctionSearch_1.setText(rb.getString("searchFE.VAVA"));
				lblforFunctionEdit.setText(rb.getString("editAL.VAVA"));
				lblforFunctionEdit_1.setText(rb.getString("editEL.VAVA"));
				btnEditEmployee.setText(rb.getString("editE.VAVA"));
				lblchooseEmployeeFrom.setText(rb.getString("chooseE.VAVA"));
				btnDeleteEmployee.setText(rb.getString("deleteE.VAVA"));
				btnECost.setText(rb.getString("costE.VAVA"));
				btnDetailedListOf_1.setText(rb.getString("listOE.VAVA"));
				btnLogout.setText(rb.getString("logout.VAVA"));
				btnVAVG.setText(rb.getString("aSalaryE.VAVA"));
				btnSearchAName.setText(rb.getString("searchBA.VAVA"));
				btnSearchAExhibit.setText(rb.getString("searchBE.VAVA"));
				btnSearchEBuilding.setText(rb.getString("searchBB.VAVA"));
				btnSearchEName.setText(rb.getString("searchBN.VAVA"));
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"eng", "sk"}));
		comboBox.setMaximumRowCount(2);
		comboBox.setBounds(691, 814, 46, 20);
		contentPane.add(comboBox);
		
		JButton btnPdf = new JButton("PDF");
		btnPdf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ManagerC.createDocument();
				LOG.info("PDF created");
			}
		});
		btnPdf.setBounds(10, 813, 89, 23);
		contentPane.add(btnPdf);
		
		btnAddAnimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!(textFieldAnimal.getText().isEmpty()) && (Double) spinnerALength.getValue() != 0 && (Integer) spinnerAWeight.getValue() != 0 && !(textFieldAApear.getText().isEmpty())) {
					int result = ManagerC.addAnimal(textFieldAnimal.getText(), (String) comboBoxAType.getSelectedItem(), (String) comboBoxAGender.getSelectedItem(), Integer.parseInt((String) comboBoxAYear.getSelectedItem()), (Double) spinnerALength.getValue(), (Integer) spinnerAWeight.getValue(), (String) comboBoxAProt.getSelectedItem(), textFieldAApear.getText(), Integer.parseInt((String) comboBoxAExhibit.getSelectedItem()));
					if (result == 0) {
						chybaUdaje((String) comboBox.getSelectedItem());
					}
					else {
						aktualizovaneZaznamy((String) comboBox.getSelectedItem());
					}
				}
				else {
					chybaV((String) comboBox.getSelectedItem());
				}
			}
		});
		
		btnEditAnimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (tableA.getColumnCount() > 5) {
					if (tableA.getSelectedRow() != -1) {
						if ((Double) spinnerALength.getValue() != 0 && (Integer) spinnerAWeight.getValue() != 0) {
							int result = ManagerC.editA((Double) spinnerALength.getValue(), (Integer) spinnerAWeight.getValue(), (String) comboBoxAProt.getSelectedItem(), Integer.parseInt((String) comboBoxAExhibit.getSelectedItem()), (int) tableA.getValueAt(tableA.getSelectedRow(), 0), (String) tableA.getValueAt(tableA.getSelectedRow(), 1), (int) tableA.getValueAt(tableA.getSelectedRow(), 9));
							if (result == 0) {
								chybaUdaje((String) comboBox.getSelectedItem());
							}
							else {
								aktualizovaneZaznamy((String) comboBox.getSelectedItem());
							}
						}
						else {
							chybaV((String) comboBox.getSelectedItem());
						}
					}
					else {
						chybaSelect((String) comboBox.getSelectedItem());
					}
				}
				else {
					chybaTabulka((String) comboBox.getSelectedItem());
				}
			}
		});
		
		btnDeleteAnimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (tableA.getColumnCount() > 5) {
					if (tableA.getSelectedRow() != -1) {
						ManagerC.deleteA((int) tableA.getValueAt(tableA.getSelectedRow(), 0), (int) tableA.getValueAt(tableA.getSelectedRow(), 9));
						aktualizovaneZaznamy((String) comboBox.getSelectedItem());
					}
					else {
						chybaSelect((String) comboBox.getSelectedItem());
					}
				}
				else {
					chybaTabulka((String) comboBox.getSelectedItem());
				}
			}
		});
		
		btnDetailedListOf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setTableDAnimals(tableA, (String) comboBox.getSelectedItem());
			}
		});
		
		btnAddEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!(textFieldEName.getText().isEmpty()) && (Double) spinnerESalary.getValue() != 0 && !(textFieldEType.getText().isEmpty())) {
					ManagerC.addEmployee(textFieldEName.getText(), (String) comboBoxEGender.getSelectedItem(), Integer.parseInt((String) comboBoxEYear.getSelectedItem()), (Double) spinnerESalary.getValue(), textFieldEType.getText(), Integer.parseInt((String) comboBoxEBuilding.getSelectedItem()));
					aktualizovaneZaznamy((String) comboBox.getSelectedItem());
				}
				else {
					chybaV((String) comboBox.getSelectedItem());
				}
			}
		});
		
		btnEditEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (tableE.getColumnCount() > 1) {
					if (tableE.getSelectedRow() != -1) {
						if ((Double) spinnerESalary.getValue() != 0 && !(textFieldEType.getText().isEmpty())) {
							ManagerC.editE((Double) spinnerESalary.getValue(), textFieldEType.getText(), Integer.parseInt((String) comboBoxEBuilding.getSelectedItem()), (int) tableE.getValueAt(tableE.getSelectedRow(), 0));
							aktualizovaneZaznamy((String) comboBox.getSelectedItem());
						}
						else {
							chybaV((String) comboBox.getSelectedItem());
						}
					}
					else {
						chybaSelect((String) comboBox.getSelectedItem());
					}
				}
				else {
					chybaTabulka((String) comboBox.getSelectedItem());
				}
			}
		});
		
		btnDeleteEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (tableE.getColumnCount() > 1) {
					if (tableE.getSelectedRow() != -1) {
						ManagerC.deleteE((int) tableE.getValueAt(tableE.getSelectedRow(), 0));
						aktualizovaneZaznamy((String) comboBox.getSelectedItem());
					}
					else {
						chybaSelect((String) comboBox.getSelectedItem());
					}
				}
				else {
					chybaTabulka((String) comboBox.getSelectedItem());
				}
			}
		});
		
		btnECost.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setTableSE(tableE, (String) comboBox.getSelectedItem());
			}
		});
		
		btnDetailedListOf_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setTableDEmployees(tableE, (String) comboBox.getSelectedItem());
			}
		});
		
		btnVAVG.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setTableAVGEmployees(tableE, (String) comboBox.getSelectedItem());
			}
		});
		
		btnSearchAName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!(textFieldAnimal.getText().isEmpty())) {
					setTableANames(tableA, textFieldAnimal.getText(), (String) comboBox.getSelectedItem());
				}
				else {
					chybaV((String) comboBox.getSelectedItem());
				}
			}
		});
		
		btnSearchAExhibit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setTableAExhibits(tableA, Integer.parseInt((String) comboBoxAExhibit.getSelectedItem()), (String) comboBox.getSelectedItem());
			}
		});
		
		btnSearchEBuilding.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setTableEBuildings(tableE, Integer.parseInt((String) comboBoxEBuilding.getSelectedItem()), (String) comboBox.getSelectedItem());
			}
		});
		
		btnSearchEName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!(textFieldEName.getText().isEmpty())) {
					setTableENames(tableE, textFieldEName.getText(), (String) comboBox.getSelectedItem());
				}
				else {
					chybaV((String) comboBox.getSelectedItem());
				}
			}
		});
		
	}
	
	// Funkcia na nastavenie tabu�ky pre v�etky zvierat�
	public void setTableDAnimals(JTable table, String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		int i = 0, j = 0;
		List<Animal> animals = new ArrayList<Animal>();
		animals = ManagerC.getAllAnimals();
		String[] columnNames = {"Id", rb.getString("animal.VAVA"), rb.getString("type.VAVA"), rb.getString("gender.VAVA"), rb.getString("year.VAVA"), rb.getString("length.VAVA"), rb.getString("weight.VAVA"), rb.getString("protection.VAVA"), rb.getString("appearance.VAVA"), rb.getString("exhibit.VAVA")};
		Object[][] data = new Object[animals.size()][10];
		for (Animal a : animals) {
			data[i][j] = a.getId();
			data[i][j+1] = a.getName();
			data[i][j+2] = a.getType();
			data[i][j+3] = a.getGender();
			data[i][j+4] = a.getYear();
			data[i][j+5] = a.getLength();
			data[i][j+6] = a.getWeight();
			data[i][j+7] = a.getProtection();
			data[i][j+8] = a.getAppearance();
			data[i][j+9] = a.getExhibit().getId();
			i++;
		}
		JTable newTable = new JTable(data, columnNames);
		table.setModel(newTable.getModel());
		LOG.info("Table created");
	}
	
	// Funkcia na nastavenie tabu�ky pre v�etk�ch zamestnancov
	public void setTableDEmployees(JTable table, String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		int i = 0, j = 0;
		List<Employee> employees = new ArrayList<Employee>();
		employees = ManagerC.getAllEmployees();
		String[] columnNames = {"Id", rb.getString("name.VAVA"), rb.getString("gender.VAVA"), rb.getString("year.VAVA"), rb.getString("salary.VAVA"), rb.getString("type.VAVA"), rb.getString("building.VAVA")};
		Object[][] data = new Object[employees.size()][7];
		for (Employee e : employees) {
			data[i][j] = e.getId();
			data[i][j+1] = e.getName();
			data[i][j+2] = e.getGender();
			data[i][j+3] = e.getYear();
			data[i][j+4] = e.getSalary();
			data[i][j+5] = e.getType();
			data[i][j+6] = e.getBuilding().getId();
			i++;
		}
		JTable newTable = new JTable(data, columnNames);
		table.setModel(newTable.getModel());
		LOG.info("Table created");
	}
	
	// Funkcia na nastavenie tabu�ky pre celkov� hodnotu v�davkov zamestnancom
	public void setTableSE(JTable table, String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		double suma = ManagerC.getSumE();
		String[] columnNames = {rb.getString("cost.VAVA")};
		Object[][] data = new Object[1][1];
		data[0][0] = suma;
		JTable newTable = new JTable(data, columnNames);
		table.setModel(newTable.getModel());
		LOG.info("Table created");
	}
	
	// Funkcia na nastavenie tabu�ky pre priemern� plat zamestnancov
	public void setTableAVGEmployees(JTable table, String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		double suma = ManagerC.getAVGE();
		String[] columnNames = {rb.getString("averageSalary.VAVA")};
		Object[][] data = new Object[1][1];
		data[0][0] = suma;
		JTable newTable = new JTable(data, columnNames);
		table.setModel(newTable.getModel());
		LOG.info("Table created");
	}
	
	// Funkcia na nastavenie tabu�ky pre v�etky zvierat�, ktor� obsahuj� v mene zadan� �daj
	public void setTableANames(JTable table, String name, String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		int i = 0, j = 0;
		List<Animal> animals = new ArrayList<Animal>();
		animals = ManagerC.getAnimalsNames(name);
		String[] columnNames = {"Id", rb.getString("animal.VAVA"), rb.getString("type.VAVA"), rb.getString("gender.VAVA"), rb.getString("year.VAVA"), rb.getString("length.VAVA"), rb.getString("weight.VAVA"), rb.getString("protection.VAVA"), rb.getString("appearance.VAVA"), rb.getString("exhibit.VAVA")};
		Object[][] data = new Object[animals.size()][10];
		for (Animal a : animals) {
			data[i][j] = a.getId();
			data[i][j+1] = a.getName();
			data[i][j+2] = a.getType();
			data[i][j+3] = a.getGender();
			data[i][j+4] = a.getYear();
			data[i][j+5] = a.getLength();
			data[i][j+6] = a.getWeight();
			data[i][j+7] = a.getProtection();
			data[i][j+8] = a.getAppearance();
			data[i][j+9] = a.getExhibit().getId();
			i++;
		}
		JTable newTable = new JTable(data, columnNames);
		table.setModel(newTable.getModel());
		LOG.info("Table created");
	}
	
	// Funkcia na nastavenie tabu�ky pre v�etky zvierat�, ktor� �ij� v danom v�behu
	public void setTableAExhibits(JTable table, int idEx, String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		int i = 0, j = 0;
		List<Animal> animals = new ArrayList<Animal>();
		animals = ManagerC.getAnimalsExhibits(idEx);
		String[] columnNames = {"Id", rb.getString("animal.VAVA"), rb.getString("type.VAVA"), rb.getString("gender.VAVA"), rb.getString("year.VAVA"), rb.getString("length.VAVA"), rb.getString("weight.VAVA"), rb.getString("protection.VAVA"), rb.getString("appearance.VAVA"), rb.getString("exhibit.VAVA")};
		Object[][] data = new Object[animals.size()][10];
		for (Animal a : animals) {
			data[i][j] = a.getId();
			data[i][j+1] = a.getName();
			data[i][j+2] = a.getType();
			data[i][j+3] = a.getGender();
			data[i][j+4] = a.getYear();
			data[i][j+5] = a.getLength();
			data[i][j+6] = a.getWeight();
			data[i][j+7] = a.getProtection();
			data[i][j+8] = a.getAppearance();
			data[i][j+9] = a.getExhibit().getId();
			i++;
		}
		JTable newTable = new JTable(data, columnNames);
		table.setModel(newTable.getModel());
		LOG.info("Table created");
	}
	
	// Funkcia na nastavenie tabu�ky pre v�etk�ch zamestnancov, ktor�ch men� obsahuj� zadan� �daj
	public void setTableENames(JTable table, String name, String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		int i = 0, j = 0;
		List<Employee> employees = new ArrayList<Employee>();
		employees = ManagerC.getEmployeesNames(name);
		String[] columnNames = {"Id", rb.getString("name.VAVA"), rb.getString("gender.VAVA"), rb.getString("year.VAVA"), rb.getString("salary.VAVA"), rb.getString("type.VAVA"), rb.getString("building.VAVA")};
		Object[][] data = new Object[employees.size()][7];
		for (Employee e : employees) {
			data[i][j] = e.getId();
			data[i][j+1] = e.getName();
			data[i][j+2] = e.getGender();
			data[i][j+3] = e.getYear();
			data[i][j+4] = e.getSalary();
			data[i][j+5] = e.getType();
			data[i][j+6] = e.getBuilding().getId();
			i++;
		}
		JTable newTable = new JTable(data, columnNames);
		table.setModel(newTable.getModel());
		LOG.info("Table created");
	}
	
	// Funkcia na nastavenie tabu�ky pre v�etk�ch zamestnancov, ktor� pracuj� v zadanej budove
	public void setTableEBuildings(JTable table, int idB, String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		int i = 0, j = 0;
		List<Employee> employees = new ArrayList<Employee>();
		employees = ManagerC.getEmployeesBuildings(idB);
		String[] columnNames = {"Id", rb.getString("name.VAVA"), rb.getString("gender.VAVA"), rb.getString("year.VAVA"), rb.getString("salary.VAVA"), rb.getString("type.VAVA"), rb.getString("building.VAVA")};
		Object[][] data = new Object[employees.size()][7];
		for (Employee e : employees) {
			data[i][j] = e.getId();
			data[i][j+1] = e.getName();
			data[i][j+2] = e.getGender();
			data[i][j+3] = e.getYear();
			data[i][j+4] = e.getSalary();
			data[i][j+5] = e.getType();
			data[i][j+6] = e.getBuilding().getId();
			i++;
		}
		JTable newTable = new JTable(data, columnNames);
		table.setModel(newTable.getModel());
		LOG.info("Table created");
	}
	
	public void chybaSelect(String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		JOptionPane.showMessageDialog(this, rb.getString("wrongSelect.VAVA"));
		LOG.warning("Wrong select");
	}
	
	public void chybaUdaje(String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		JOptionPane.showMessageDialog(this, rb.getString("wrongInformation.VAVA"));
		LOG.warning("Wrong information");
	}
	
	public void aktualizovaneZaznamy(String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		JOptionPane.showMessageDialog(this, rb.getString("aktualization.VAVA"));
		LOG.info("Aktualization successful");
	}
	
	public void chybaV(String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		JOptionPane.showMessageDialog(this, rb.getString("wrongInsert.VAVA"));
		LOG.warning("Wrong information");
	}
	
	public void chybaTabulka(String jazyk) {
		ResourceBundle rb = ResourceBundle.getBundle("Manager", new Locale(jazyk));
		JOptionPane.showMessageDialog(this, rb.getString("wrongTable.VAVA"));
		LOG.warning("Used wrong table");
	}
}
