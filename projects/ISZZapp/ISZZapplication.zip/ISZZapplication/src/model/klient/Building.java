package model.klient;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Building class - zobrazuje tabu�ku budovy
 * @author �ubo� �tefunko
 */
@Entity
@Table(name = "budovy")
public class Building {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id_bud")
 	private Integer id;

	@Column(name = "nazov_bud")
	private String name;
	
	@Column(name = "typ_bud")
	private String type;
	
	@Column(name = "pocet_miestnosti")
	private Integer count;
	
	@Column(name = "plocha_a_bud")
	private Double area;
	
	@ManyToOne
	@JoinColumn(name = "blok_id_bud")
	private Block block;
	
	public Building() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Double getArea() {
		return area;
	}

	public void setArea(Double area) {
		this.area = area;
	}

	public Block getBlock() {
		return block;
	}

	public void setBlock(Block block) {
		this.block = block;
	}
	
}
