package model.klient;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Exhibit class - zobrazuje tabu�ku vybeh
 * @author �ubo� �tefunko
 */
@Entity
@Table(name = "vybeh")
public class Exhibit {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id_v")
 	private Integer id;

	@Column(name = "nazov_v")
	private String name;
	
	@Column(name = "typ_zvierat")
	private String type;
	
	@Column(name = "pocet_zvierat")
	private Integer count;
	
	@Column(name = "kapacita")
	private Integer capacity;
	
	@Column(name = "plocha_a_v")
	private Double area;
	
	@ManyToOne
	@JoinColumn(name = "blok_id_v")
	private Block block;
	
	public Exhibit() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public Double getArea() {
		return area;
	}

	public void setArea(Double area) {
		this.area = area;
	}

	public Block getBlock() {
		return block;
	}

	public void setBlock(Block block) {
		this.block = block;
	}
	
}
