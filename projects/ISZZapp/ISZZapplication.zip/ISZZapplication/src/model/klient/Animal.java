package model.klient;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Animal class - zobrazuje tabu�ku zviera
 * @author �ubo� �tefunko
 */
@Entity
@Table(name = "zviera")
public class Animal {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id_z")
 	private Integer id;

	@Column(name = "nazov_z")
	private String name;
	
	@Column(name = "typ_z")
	private String type;
	
	@Column(name = "pohlavie_z")
	private String gender;
	
	@Column(name = "rok_narodenia_z")
	private Integer year;
	
	@Column(name = "dlzka_m")
	private Double length;
	
	@Column(name = "hmotnost_kg")
	private Integer weight;
	
	@Column(name = "chraneny")
	private String protection;
	
	@Column(name = "vyskyt")
	private String appearance;
	
	@ManyToOne
	@JoinColumn(name = "vybeh_id")
	private Exhibit exhibit;
	
	public Animal() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Double getLength() {
		return length;
	}

	public void setLength(Double length) {
		this.length = length;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public String getProtection() {
		return protection;
	}

	public void setProtection(String protection) {
		this.protection = protection;
	}

	public String getAppearance() {
		return appearance;
	}

	public void setAppearance(String appearance) {
		this.appearance = appearance;
	}

	public Exhibit getExhibit() {
		return exhibit;
	}

	public void setExhibit(Exhibit exhibit) {
		this.exhibit = exhibit;
	}
	
}
