package model.klient;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Block class - zobrazuje tabu�ku blokZOO
 * @author �ubo� �tefunko
 */
@Entity
@Table(name = "blokZOO")
public class Block {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id_bz")
 	private Integer id;

	@Column(name = "nazov_bz")
	private String name;
	
	@Column(name = "typ_bz")
	private String type;
	
	@Column(name = "toaleta")
	private String toilet;
	
	@Column(name = "obcerstvenie")
	private String meal;
	
	@Column(name = "vybehy")
	private String exhibit;
	
	@Column(name = "suveniry")
	private String shops;
	
	public Block() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getToilet() {
		return toilet;
	}

	public void setToilet(String toilet) {
		this.toilet = toilet;
	}

	public String getMeal() {
		return meal;
	}

	public void setMeal(String meal) {
		this.meal = meal;
	}

	public String getExhibit() {
		return exhibit;
	}

	public void setExhibit(String exhibit) {
		this.exhibit = exhibit;
	}

	public String getShops() {
		return shops;
	}

	public void setShops(String shops) {
		this.shops = shops;
	}
	
}
