package main.klient;

import java.util.logging.Logger;

import org.hibernate.SessionFactory;

import controller.klient.LoginC;
import util.klient.HibernateU;
import view.klient.LoginV;

/**
 * Main class - spustenie programu
 * @author �ubo� �tefunko
 */
public class ISZZappMain {
	
	private static final Logger LOG = Logger.getLogger(Logger.class.getName());

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateU.getSessionFactory();
		LoginV loginV = new LoginV();
		loginV.setVisible(true);
		LoginC loginC = new LoginC(loginV, sessionFactory);
		LOG.info("Aplication start");
	}

}