package controller.klient;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import model.klient.Animal;
import model.klient.Building;
import model.klient.Employee;
import model.klient.Exhibit;
import view.klient.LoginV;
import view.klient.ManagerV;

/**
 * Manager controller
 * @author �ubo� �tefunko
 */
public class ManagerC {
	static ManagerV managerV;
	static SessionFactory sessionFactory;
	private static final Logger LOG = Logger.getLogger(Logger.class.getName());
	
	public ManagerC(ManagerV managerV, SessionFactory sessionFactory) {
		ManagerC.managerV = managerV;
		ManagerC.sessionFactory = sessionFactory;
	}
	
	// Funkcia na odhl�senie
	@SuppressWarnings("unused")
	public static void getLogOut() {
		LoginV loginV = new LoginV();
		loginV.setVisible(true);
		managerV.dispose();
		LoginC loginC = new LoginC(loginV, sessionFactory);
		LOG.info("Successful log out");
	}
	
	// Funkcia na z�skanie v�etk�ch zvierat
	@SuppressWarnings("unchecked")
	public static List<Animal> getAllAnimals() {
		Session session = sessionFactory.openSession();
		List<Animal> animals = new ArrayList<Animal>();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Criteria cr = session.createCriteria(Animal.class)
	    			.addOrder(Order.asc("id"));
	    	animals = cr.list();
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
	    return animals;
	}
	
	// Funkcia na z�skanie v�etk�ch zamestnancov
	@SuppressWarnings("unchecked")
	public static List<Employee> getAllEmployees() {
		Session session = sessionFactory.openSession();
		List<Employee> employees = new ArrayList<Employee>();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Criteria cr = session.createCriteria(Employee.class)
	    			.addOrder(Order.asc("id"));
	    	employees = cr.list();
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
	    return employees;
	}
	
	// Funckia na z�skanie celkovej hodnoty v�davkov zamestnancom
	public static Double getSumE() {
		Session session = sessionFactory.openSession();
		double listAC = 0;
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Criteria cr = session.createCriteria(Employee.class, "e")
	    			.setProjection(Projections.sum("e.salary"));
	    	listAC = (double) cr.list().get(0);
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
		return listAC;
	}
	
	// Funkcia na z�skanie priemern�ho platu
	public static Double getAVGE() {
		Session session = sessionFactory.openSession();
		double listAC = 0;
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Criteria cr = session.createCriteria(Employee.class, "e")
	    			.setProjection(Projections.avg("e.salary"));
	    	listAC = (double) cr.list().get(0);
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
		return listAC;
	}
	
	// Funkcia na vymazanie zviera�a
	public static void deleteA(int idA, int idEx) {
		Session session = sessionFactory.openSession();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Animal animal = (Animal) session.get(Animal.class, idA);
	    	session.delete(animal);
	    	Exhibit exhibit = (Exhibit) session.get(Exhibit.class, idEx);
	    	exhibit.setCount((exhibit.getCount() - 1));
	    	if (exhibit.getCount() == 0) {
	    		exhibit.setType(null);
	    	}
	    	session.update(exhibit);
	    	tx.commit();
	    }catch (HibernateException e) {
	    	if (tx!=null) {
	    		tx.rollback();
	    	}
	    	e.printStackTrace(); 
	    }finally {
	    	session.close(); 
	    }
	}
	
	// Funkcia na vymazanie zamestnanca
	public static void deleteE(int idE) {
		Session session = sessionFactory.openSession();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Employee employee = (Employee) session.get(Employee.class, idE);
	    	session.delete(employee);
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
	}
	
	// Funkcia na pridanie zviera�a
	public static int addAnimal(String name, String type, String gender, int year, double length, int weight, String protection, String appearance, int exhibitId) {
		int result = 0;
		Session session = sessionFactory.openSession();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Exhibit exhibit = (Exhibit) session.get(Exhibit.class, exhibitId);
	    	// Kontrola preplnenosti v�behu a pr�padn� nastavenie typu v�behu
	    	if (exhibit.getType().equals(name) || exhibit.getType().equals("null")) {
	    		if ((exhibit.getCapacity() - exhibit.getCount()) > 0) {
	    			Animal animal = new Animal();
	    			animal.setAppearance(appearance);
	    			animal.setExhibit(exhibit);
	    			animal.setGender(gender);
	    			animal.setLength(length);
	    			animal.setName(name);
	    			animal.setProtection(protection);
	    			animal.setType(type);
	    			animal.setWeight(weight);
	    			animal.setYear(year);
	    			exhibit.setCount((exhibit.getCount() + 1));
	    			if (exhibit.getType().equals("null")) {
	    				exhibit.setType(name);
	    			}
	    			session.update(exhibit);
	    			session.save(animal);
	    			result = 1;
	    		}
	    	}
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
	    return result;
	}
	
	// Funkcia na pridanie zamestnanca
	public static void addEmployee(String name, String gender, int year, double salary, String type, int buildingId) {
		Session session = sessionFactory.openSession();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Building building = (Building) session.get(Building.class, buildingId);
	    	Employee employee = new Employee();
	    	employee.setBuilding(building);
	    	employee.setGender(gender);
	    	employee.setSalary(salary);
	    	employee.setName(name);
	    	employee.setType(type);
	    	employee.setYear(year);
	    	session.save(employee);
	    	tx.commit();
	    }catch (HibernateException e) {
	    	if (tx!=null) {
	    		tx.rollback();
	    	}
	    	e.printStackTrace(); 
	    }finally {
	    	session.close(); 
	    }
	}
	
	// Funkcia na editovanie zamestnanca
	public static void editE(double salary, String type, int buildingId, int idE) {
		Session session = sessionFactory.openSession();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Employee employee = (Employee) session.get(Employee.class, idE);
	    	Building building = (Building) session.get(Building.class, buildingId);
	    	employee.setSalary(salary);
	    	employee.setType(type);
	    	employee.setBuilding(building);
	    	session.update(employee);
	    	tx.commit();
	    }catch (HibernateException e) {
	    	if (tx!=null) {
	    		tx.rollback();
	    	}
	    	e.printStackTrace(); 
	    }finally {
	    	session.close(); 
	    }
	}
	
	// Funkcia na editovanie zviera�a
	public static int editA(double length, int weight, String protection, int idEx, int idA, String nameA, int idExA) {
		int result = 0;
		Session session = sessionFactory.openSession();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Animal animal = (Animal) session.get(Animal.class, idA);
	    	Exhibit exhibit = (Exhibit) session.get(Exhibit.class, idEx);
	    	Exhibit exhibitA = (Exhibit) session.get(Exhibit.class, idExA);
	    	if (exhibit.getType().equals(nameA) || exhibit.getType().equals("null")) {
	    		if ((exhibit.getCapacity() - exhibit.getCount()) > 0) {
	    			animal.setLength(length);
	    			animal.setWeight(weight);
	    			animal.setProtection(protection);
	    			animal.setExhibit(exhibit);
	    			session.update(animal);
	    			exhibit.setCount((exhibit.getCount() + 1));
	    			if (exhibit.getType().equals("null")) {
	    				exhibit.setType(nameA);
	    			}
	    			session.update(exhibit);
	    			exhibitA.setCount((exhibitA.getCount() - 1));
	    			if (exhibitA.getCount() == 0) {
	    				exhibitA.setType("null");
	    			}
	    			session.update(exhibitA);
	    			result = 1;
	    		}
	    	}
	    	tx.commit();
	    }catch (HibernateException e) {
	    	if (tx!=null) {
	    		tx.rollback();
	    	}
	    	e.printStackTrace(); 
	    }finally {
	    	session.close(); 
	    }
	    return result;
	}
	
	// Funkcia na z�skanie zvierat, ktor� obsahuj� v mene zadan� �daj
	@SuppressWarnings("unchecked")
	public static List<Animal> getAnimalsNames(String name) {
		Session session = sessionFactory.openSession();
		List<Animal> animals = new ArrayList<Animal>();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Criteria cr = session.createCriteria(Animal.class)
	    			.add(Restrictions.like("name", name + "%"));
	    	animals = cr.list();
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
	    return animals;
	}
	
	// Funkcia na z�skanie zvierat, ktor� s� vo v�behu so zadan�m ��slom
	@SuppressWarnings("unchecked")
	public static List<Animal> getAnimalsExhibits(int idEx) {
		Session session = sessionFactory.openSession();
		List<Animal> animals = new ArrayList<Animal>();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Criteria cr = session.createCriteria(Animal.class, "a")
	    			.createAlias("a.exhibit", "ex")
	    			.add(Restrictions.eq("ex.id", idEx));
	    	animals = cr.list();
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
	    return animals;
	}
	
	// Funkcia na z�skanie zamestnancov, ktor� obsahuj� v mene zadan� �daj
	@SuppressWarnings("unchecked")
	public static List<Employee> getEmployeesNames(String name) {
		Session session = sessionFactory.openSession();
		List<Employee> employees = new ArrayList<Employee>();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Criteria cr = session.createCriteria(Employee.class)
	    			.add(Restrictions.like("name", name + "%"));
	    	employees = cr.list();
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
	    return employees;
	}
	
	// Funkcia na z�skanie zamestnancov, ktor� pracuj� v budove so zadan�m ��slom
	@SuppressWarnings("unchecked")
	public static List<Employee> getEmployeesBuildings(int idEx) {
		Session session = sessionFactory.openSession();
		List<Employee> employees = new ArrayList<Employee>();
	    Transaction tx = null;
	    try{
	    	tx = session.beginTransaction();
	    	Criteria cr = session.createCriteria(Employee.class, "a")
	    			.createAlias("a.building", "ex")
	    			.add(Restrictions.eq("ex.id", idEx));
	    	employees = cr.list();
	    	tx.commit();
	    	}catch (HibernateException e) {
	    		if (tx!=null) {
	    			tx.rollback();
	    		}
	    		e.printStackTrace(); 
	    	}finally {
	    		session.close(); 
	    	}
	    return employees;
	}
	
	// Funkcia, ktor� sl��i na vygenerovanie PDF dokumentu.
	public static void createDocument() {
		try {
			List<Animal> animals = new ArrayList<Animal>();
			animals = ManagerC.getAllAnimals();
			List<Employee> employees = new ArrayList<Employee>();
			employees = ManagerC.getAllEmployees();
			
			Document document = new Document(PageSize.A4, 20, 20, 20, 20);
			PdfWriter.getInstance(document, new FileOutputStream("D:\\ISZZapp.pdf"));
			document.open();
			
			document.addTitle("ISZZapp");
		    document.addAuthor("Lubo� �tefunko");
		    document.addCreator("Lubo� �tefunko");
		    
		    Paragraph paragraph = new Paragraph();
		    paragraph.add(new Paragraph(" "));
		    paragraph.add(new Paragraph("ISZZapp - List of animals and employees", new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD)));
		    paragraph.add(new Paragraph(" "));
		    paragraph.add(new Paragraph("Lubo� �tefunko, " + new Date(), new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD)));
		    paragraph.add(new Paragraph(" "));
		    paragraph.add(new Paragraph("Animals in ZOO: ", new Font(Font.FontFamily.TIMES_ROMAN, 12)));
		    paragraph.add(new Paragraph(" "));
		    
		    PdfPTable tableA = new PdfPTable(10);
		    PdfPCell c1 = new PdfPCell(new Phrase("Id"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);

		    c1 = new PdfPCell(new Phrase("Animal"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);

		    c1 = new PdfPCell(new Phrase("Type"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);
		    
		    c1 = new PdfPCell(new Phrase("Gender"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);

		    c1 = new PdfPCell(new Phrase("Year(oB)"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);
		    
		    c1 = new PdfPCell(new Phrase("Length (m)"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);

		    c1 = new PdfPCell(new Phrase("Weight (kg)"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);
		    
		    c1 = new PdfPCell(new Phrase("Protection"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);
		    
		    c1 = new PdfPCell(new Phrase("Appearance"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);

		    c1 = new PdfPCell(new Phrase("Exhibit"));
		    c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableA.addCell(c1);
		    tableA.setHeaderRows(1);
		    
		    for (Animal a : animals) {
		    	tableA.addCell(a.getId().toString());
		    	tableA.addCell(a.getName());
		    	tableA.addCell(a.getType());
		    	tableA.addCell(a.getGender());
		    	tableA.addCell(a.getYear().toString());
		    	tableA.addCell(a.getLength().toString());
		    	tableA.addCell(a.getWeight().toString());
		    	tableA.addCell(a.getProtection());
		    	tableA.addCell(a.getAppearance());
		    	tableA.addCell(a.getExhibit().getId().toString());
		    }
		    
		    paragraph.add(tableA);
		    paragraph.add(new Paragraph(" "));
		    paragraph.add(new Paragraph("Employees in ZOO: ", new Font(Font.FontFamily.TIMES_ROMAN, 12)));
		    paragraph.add(new Paragraph(" "));
		    
		    PdfPTable tableE = new PdfPTable(7);
		    PdfPCell c2 = new PdfPCell(new Phrase("Id"));
		    c2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableE.addCell(c2);

		    c2 = new PdfPCell(new Phrase("Name"));
		    c2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableE.addCell(c2);

		    c2 = new PdfPCell(new Phrase("Gender"));
		    c2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableE.addCell(c2);

		    c2 = new PdfPCell(new Phrase("Year(oB)"));
		    c2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableE.addCell(c2);
		    
		    c2 = new PdfPCell(new Phrase("Salary (e)"));
		    c2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableE.addCell(c2);

		    c2 = new PdfPCell(new Phrase("Type"));
		    c2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableE.addCell(c2);
		    
		    c2 = new PdfPCell(new Phrase("Building"));
		    c2.setHorizontalAlignment(Element.ALIGN_CENTER);
		    tableE.addCell(c2);
		    tableE.setHeaderRows(1);
		    
		    for (Employee e : employees) {
		    	tableE.addCell(e.getId().toString());
		    	tableE.addCell(e.getName());
		    	tableE.addCell(e.getGender());
		    	tableE.addCell(e.getYear().toString());
		    	tableE.addCell(e.getSalary().toString());
		    	tableE.addCell(e.getType());
		    	tableE.addCell(e.getBuilding().getId().toString());
		    }
		    
		    paragraph.add(tableE);
		    document.add(paragraph);
			document.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
