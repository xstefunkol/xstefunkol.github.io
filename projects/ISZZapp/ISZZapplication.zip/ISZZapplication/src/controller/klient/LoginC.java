package controller.klient;

import java.util.logging.Logger;

import org.hibernate.SessionFactory;

import view.klient.LoginV;
import view.klient.ManagerV;

/**
 * Login controller
 * @author �ubo� �tefunko
 */
public class LoginC {
	static LoginV loginV;
	static SessionFactory sessionFactory;
	private static final Logger LOG = Logger.getLogger(Logger.class.getName());
	
	public LoginC(LoginV loginV, SessionFactory sessionFactory) {
		LoginC.loginV = loginV;
		LoginC.sessionFactory = sessionFactory;
	}
	
	// Funkcia na prihl�senie do syst�mu
	@SuppressWarnings("unused")
	public static void getLogIn(String loginName, String loginPassword) {
		if (loginName.equals("�ubo� �tefunko")) {
			if (loginPassword.equals("123")) {  
				ManagerV managerV = new ManagerV();
				managerV.setVisible(true);
				loginV.dispose();
				ManagerC managerC = new ManagerC(managerV, sessionFactory);
				LOG.info("Successful log in");
			}
			else {
				loginV.neplatnePError((String) loginV.getComboBox().getSelectedItem());
				LOG.warning("Unsuccessful log in");
			}
		}
		else {
			loginV.neplatnePError((String) loginV.getComboBox().getSelectedItem());
			LOG.warning("Unsuccessful log in");
		}
	}
}
