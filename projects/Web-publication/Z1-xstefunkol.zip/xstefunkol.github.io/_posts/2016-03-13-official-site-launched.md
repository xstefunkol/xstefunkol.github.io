---
layout: post
title: "Official start"
date: 2016-03-13
---

Official start of using these sites and blog for tracking my work and projects.
