package uiz2package;

// Umel� inteligencia - Zadanie 2, �ubo� �tefunko

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// postupnost - pole obsahuj�ce stavy, ktor� je potrebn� prejs�
		// spracovanych - pole obsahuj�ce v�etky spracovan� stavy
		ArrayList<Stav> postupnost = new ArrayList<>();
		ArrayList<Stav> spracovanych = new ArrayList<>();
		Scanner scan = new Scanner(System.in);
		Stav zaciatok = new Stav();
		int vystup[][], heuristika, m, n;
		
		System.out.println("Zadajte po�et riadkov: ");
		m = scan.nextInt();
		
		System.out.println("Zadajte po�et st�pcov: ");
		n = scan.nextInt();
		
		vystup = Stav.zadaj(zaciatok, m, n);
		
		System.out.println("Zadajte heuristiku: ");
		heuristika = scan.nextInt();
		
		// Algoritmus la�n�ho preh�ad�vania stavov�ho priestoru
		Stav.algoritmus(zaciatok, vystup, heuristika, postupnost, spracovanych, m, n);
		
		// V�pis postupnosti krokov
		System.out.println("Pre z�skanie v�stupn�ho stavu bolo potrebn� spracova�: " + spracovanych.size() + " stavov, postupnos� sa sklad� z " + (postupnost.size()-1) + " pohybov a je nasledovn�: ");
		Stav.vypisPostupnosti(postupnost);
		
		scan.close();
	}
}