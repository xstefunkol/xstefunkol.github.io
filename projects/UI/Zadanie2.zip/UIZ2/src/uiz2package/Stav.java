package uiz2package;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Stav {
	private Stav predStav;
	private int[][] matica;
	private String predOperator;
	private int heuristikaC;
	
	// Kompar�tor pou�it� v priorityqueue na ur�enie priority pod�a hodnoty z�skanej z heuristiky
	public static Comparator<Stav> heurComparator = new Comparator<Stav>(){
		@Override
		public int compare(Stav s1, Stav s2) {
			return (int) (s1.getHeuristikaC() - s2.getHeuristikaC());
		}
	};
	
	// Getters and Setters
	public int getIndexMatice(int x, int y) {
		return matica[x][y];
	}

	public int getHeuristikaC() {
		return heuristikaC;
	}

	public void setHeuristikaC(int heuristikaC) {
		this.heuristikaC = heuristikaC;
	}

	public void setIndexMatice(int x, int y, int hodnota) {
		this.matica[x][y] = hodnota;
	}
	
	public Stav getPredStav() {
		return predStav;
	}
	
	public void setPredStav(Stav predStav) {
		this.predStav = predStav;
	}
	
	public int[][] getMatica() {
		return matica;
	}
	
	public void setMatica(int[][] matica) {
		this.matica = matica;
	}
	
	public String getPredOperator() {
		return predOperator;
	}
	
	public void setPredOperator(String predOperator) {
		this.predOperator = predOperator;
	}
	
	// Met�da pre v�menu hodn�t v matici - posun do�ava
	public static void VLAVO(int i, int j, Stav novy, Stav stav, int m, int n) {
		int docasne, k, l, matica[][] = new int[m][n];
		novy.setMatica(matica);
		for (k = 0; k < m; k++) {
			for (l = 0; l < n; l++) {
				novy.setIndexMatice(k, l, stav.getIndexMatice(k, l));
			}
		}
		docasne = novy.getIndexMatice(i,j+1);
		novy.setIndexMatice(i,j,docasne);
		novy.setIndexMatice(i,j+1,0);
		novy.setPredStav(stav);
		novy.setPredOperator("VLAVO");
	}
	
	// Met�da pre v�menu hodn�t v matici - posun doprava
	public static void VPRAVO(int i, int j, Stav novy, Stav stav, int m, int n) {
		int docasne, k, l, matica[][] = new int[m][n];
		novy.setMatica(matica);
		for (k = 0; k < m; k++) {
			for (l = 0; l < n; l++) {
				novy.setIndexMatice(k, l, stav.getIndexMatice(k, l));
			}
		}
		docasne = novy.getIndexMatice(i,j-1);
		novy.setIndexMatice(i,j,docasne);
		novy.setIndexMatice(i,j-1,0);
		novy.setPredStav(stav);
		novy.setPredOperator("VPRAVO");
	}
	
	// Met�da pre v�menu hodn�t v matici - posun dole
	public static void DOLE(int i, int j, Stav novy, Stav stav, int m, int n) {
		int docasne, k, l, matica[][] = new int[m][n];
		novy.setMatica(matica);
		for (k = 0; k < m; k++) {
			for (l = 0; l < n; l++) {
				novy.setIndexMatice(k, l, stav.getIndexMatice(k, l));
			}
		}
		docasne = novy.getIndexMatice(i-1,j);
		novy.setIndexMatice(i,j,docasne);
		novy.setIndexMatice(i-1,j,0);
		novy.setPredStav(stav);
		novy.setPredOperator("DOLE");
	}
	
	// Met�da pre v�menu hodn�t v matici - posun hore
	public static void HORE(int i, int j, Stav novy, Stav stav, int m, int n) {
		int docasne, k, l, matica[][] = new int[m][n];
		novy.setMatica(matica);
		for (k = 0; k < m; k++) {
			for (l = 0; l < n; l++) {
				novy.setIndexMatice(k, l, stav.getIndexMatice(k, l));
			}
		}
		docasne = novy.getIndexMatice(i+1,j);
		novy.setIndexMatice(i,j,docasne);
		novy.setIndexMatice(i+1,j,0);
		novy.setPredStav(stav);
		novy.setPredOperator("HORE");
	}
	
	// Met�da pre z�skanie vstupn�ch �dajov
	public static int[][] zadaj(Stav stav, int m, int n) {
		int i, j, matica[][] = new int[m][n], vystup[][] = new int[m][n];
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Zadajte za�iato�n� stav: (po riadkoch vkladaj ��sla)");
		for (i = 0; i < m; i++) {
			for (j = 0; j < n; j++) {
				matica[i][j] = scan.nextInt();
			}
		}
		stav.setPredOperator("1");
		stav.setPredStav(null);
		stav.setMatica(matica);
		
		System.out.println("Zadajte koncov� stav: (po riadkoch vkladaj ��sla)");
		for (i = 0; i < m; i++) {
			for (j = 0; j < n; j++) {
				vystup[i][j] = scan.nextInt();
			}
		}
		return vystup;
	}
	
	// Met�da na ur�enie hodnoty pod�a heuristiky 1
	public static int heuristika1(int[][] vstup, int[][] vystup, int m, int n) {
		int x = 0, i, j;
		for (i = 0; i < m; i++) {
			for (j = 0; j < n; j++) {
				if (vstup[i][j] != vystup[i][j]) {
					x++;
				}
			}
		}
		return x;
	}
	
	// Met�da na ur�enie hodnoty pod�a heuristiky 2
	public static int heuristika2(int[][] vstup, int[][] vystup, int m, int n) {
		int x = 0, i, j, k, l, y = 0;
		for (i = 0; i < m; i++) {
			for (j = 0; j < n; j++) {
				for (k = 0; k < m; k++) {
					for (l = 0; l < n; l++) {
						if (vstup[i][j] == vystup[k][l]) {
							x = x + Math.abs(k - i) + Math.abs(l - j);
							y = 1;
							break;
						}
					}
					if (y == 1) {
						break;
					}
				}
				if (y == 1) {
					y = 0;
					continue;
				}
			}
		}
		return x;
	}
	
	// Met�da samotn�ho algoritmu programu
	public static void algoritmus(Stav stav, int[][] vystup, int heuristika, ArrayList<Stav> postupnost, ArrayList<Stav> spracovanych, int m, int n) {
		PriorityQueue<Stav> queue = new PriorityQueue<>(10, heurComparator);
		int i, j, y = 0, x, k, z = 0;
		
		// Ur�enie typu heuristiky pod�a vstupn�ho parametra
		if (heuristika == 1) {
			stav.setHeuristikaC(heuristika1(stav.getMatica(), vystup, m, n));
		}
		else {
			stav.setHeuristikaC(heuristika2(stav.getMatica(), vystup, m, n));
		}
		queue.add(stav);
		
		// Postupn� vyberanie stavov z prioritn�ho radu a n�sledn� spracovanie
		while (true) {
			Stav aktualny = queue.poll();
			x = 0;
			
			// Zistenie nespracovanosti aktu�lneho stavu prejden�m v�etk�ch spracovan�ch
			for (k = 0; k < spracovanych.size(); k++) {
				for (i = 0; i < m; i++) {
					for (j = 0; j < n; j++) {
						if (aktualny.getMatica()[i][j] == spracovanych.get(k).getMatica()[i][j]) {
							z++;
						}
					}
				}
				if (z == (m*n)) {
					break;
				}
				else {
					z = 0;
				}
			}
			if (z == (m*n)) {}
			else {
				// Ak tento stav e�te nebol spracovan�
				for (i = 0; i < m; i++) {
					for (j = 0; j < n; j++) {
						if (aktualny.getMatica()[i][j] == vystup[i][j]) {
							x++;
						}
					}
				}
				if (x == (m*n)) {
					// Ak algoritmus na�iel cie�ov� maticu uklad� stavy do po�a postupnost�
					while (aktualny.getPredStav() != null) {
						postupnost.add(aktualny);
						aktualny = aktualny.getPredStav();
					}
					postupnost.add(aktualny);
					return;
				}
				else {
					// Inak n�jde v aktu�lnej matici dan�ho stavu ��slo 0 a pod�a jeho poz�cie a predch�dzaj�ceho oper�tora ur�� povolen� met�dy
					for (i = 0; i < m; i++) {
						for (j = 0; j < n; j++) {
							if (aktualny.getMatica()[i][j] == 0) {
								if (j != (n-1)) {
									if (aktualny.getPredOperator().equals("VPRAVO")) {}
									else {
										Stav novy1 = new Stav();
										VLAVO(i, j, novy1, aktualny, m, n);
										if (heuristika == 1) {
											novy1.setHeuristikaC(heuristika1(novy1.getMatica(), vystup, m, n));
										}
										else {
											novy1.setHeuristikaC(heuristika2(novy1.getMatica(), vystup, m, n));
										}
										queue.add(novy1);
									}
								}
								if (j != 0) {
									if (aktualny.getPredOperator().equals("VLAVO")) {}
									else {
										Stav novy2 = new Stav();
										VPRAVO(i, j, novy2, aktualny, m, n);
										if (heuristika == 1) {
											novy2.setHeuristikaC(heuristika1(novy2.getMatica(), vystup, m, n));
										}
										else {
											novy2.setHeuristikaC(heuristika2(novy2.getMatica(), vystup, m, n));
										}
										queue.add(novy2);
									}
								}
								if (i != 0) {
									if (aktualny.getPredOperator().equals("HORE")) {}
									else {
										Stav novy3 = new Stav();
										DOLE(i, j, novy3, aktualny, m, n);
										if (heuristika == 1) {
											novy3.setHeuristikaC(heuristika1(novy3.getMatica(), vystup, m, n));
										}
										else {
											novy3.setHeuristikaC(heuristika2(novy3.getMatica(), vystup, m, n));
										}
										queue.add(novy3);
									}
								}
								if (i != (m-1)) {
									if (aktualny.getPredOperator().equals("DOLE")) {}
									else {
										Stav novy4 = new Stav();
										HORE(i, j, novy4, aktualny, m, n);
										if (heuristika == 1) {
											novy4.setHeuristikaC(heuristika1(novy4.getMatica(), vystup, m, n));
										}
										else {
											novy4.setHeuristikaC(heuristika2(novy4.getMatica(), vystup, m, n));
										}
										queue.add(novy4);
									}
								}
								y = 1;
								break;
							}
						}
						if (y == 1) {
							y = 0;
							break;
						}
					}
				}
				spracovanych.add(aktualny);
			}
		}
	}
	
	// Met�da na v�pis postupnosti krokov
	public static void vypisPostupnosti(ArrayList<Stav> postupnost) {
		int i;
		for (i = postupnost.size() - 2; i >= 0; i--) {
			System.out.println(postupnost.get(i).getPredOperator() + "    ");
		}
	}
}